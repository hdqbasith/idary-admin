<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
    function __construct(){
        parent::__construct();
        $this->load->model('fstudent');
        if($this->session->userdata('username')==null) redirect(base_url('login'));
    }
    
    
    
    //=======================================
    //              HALAMAN DASAR
    //=======================================
	public function getnisn()
	{
        $data['nisn']=$this->session->userdata('username');
        $data['nama_lengkap']=$this->session->userdata('user_fullname');
        return $data;
	}
	public function index()
	{
		$data=null;
	    // $data['cek']=$this->fstudent->cekver();
	    // $ceklengkap=$this->ceklengkap(1);
	    // if($data['cek']['kelas']==null || $data['cek']['jurusan']==null || $data['cek']['absen']==null) redirect(base_url('student/verifikasi'));
	    // if($ceklengkap['i']<50) redirect(base_url('student/formulir_full'));
	    $this->pakaitemplate('student/home',$data);
	}
	public function perbaikan()
	{
	    $data=$this->getnisn();
	    $this->pakaitemplate('student/perbaikan',$data);
	}
	public function pakaitemplate($content,$data)
	{
	    $level=$this->session->userdata('user_level');
	    $data['sidemenus']=$this->fungsi->sidemenu($level);
	    $this->load->view('template/header');
	    $this->load->view('template/topmenu');
	    $this->load->view('template/sidemenu',$data);
	    $this->load->view($content,$data);
	    $this->load->view('template/footer');
	}
	public function pakaiblank($content,$data)
	{
	    $data['contents']=$this->load->view($content,$data,TRUE);
	    $this->load->view('blank',$data);
	}
	
	
	
	//==========================================
	//          DATABASE
	//==========================================
	public function verifikasi()
	{
	    if($this->input->post('nisn')!=null){
    	    $data=null;
    	    foreach($_POST as $k=>$l){
    	        $data[$k]=$l;
    	    }
    	    $this->fstudent->verifikasi($data);
	    }else{
    	    $data=$this->getnisn();
    	    $data=$this->fstudent->verifikasi();
    	    $this->pakaitemplate('student/verifikasi',$data);
	    }
	}
	public function listprov($parent)
	{
	    return $this->fstudent->listprov($parent);
	}
	public function listpondok()
	{
	    $id=$this->input->get('id');
	    echo json_encode($this->fstudent->listpondok($id));
	}
	public function ceklengkap($a=null)
	{
	    $nisn=$this->getnisn();
	    $lengkap=$this->fstudent->ceklengkap($nisn);
	    $data['i']=0;
	    $data['j']=0;
	    foreach($lengkap as $l){
	        $data['j']++;
	        if($l!=null) $data['i']++;
	    }
	    if($a==null)echo json_encode($data);
	    else return $data;
	}
	public function formulir_full()
	{
	    $nisn=$this->input->get('nisn');
	    if($nisn==null) $nisn=$this->session->userdata('username');
	    $data=$this->fstudent->formulir_full($nisn);
        // if($this->input->get('nisn')==null) $this->pakaitemplate('student/formulir_full',$data);
        // else 
        $this->pakaitemplate('student/biodata',$data);
	}
	public function simpanfull()
	{
	    $data=null;
	    foreach ($_POST as $key => $value) {
            $data[$key]=$value;
        }
        if(isset($data['tanggal_lahir'])) $data['tanggal_lahir']=date('Y-m-d',strtotime($data['tanggal_lahir']));
        if(isset($data['tahun_lahir_ayah_kandung'])) $data['tahun_lahir_ayah_kandung']=date('Y-m-d',strtotime($data['tahun_lahir_ayah_kandung']));
        if(isset($data['tahun_lahir_ibu_kandung'])) $data['tahun_lahir_ibu_kandung']=date('Y-m-d',strtotime($data['tahun_lahir_ibu_kandung']));
        if(isset($data['tahun_lahir_wali'])) $data['tahun_lahir_wali']=date('Y-m-d',strtotime($data['tahun_lahir_wali']));
        $result=$this->fstudent->simpanfull($data);
	    echo $result;
	}
	
	//==========================================
	//          PEMILIHAN KETUA PP/OSIS
	//==========================================
	
	public function pemilu()
	{
	    $data=$this->getnisn();
	    $data['pilihan']=$this->input->get('pilihan');
	    $data['sudah_pilih']=$this->fstudent->pemilu($data);
	    if($data['pilihan']==null){
	    	$data['hasilpemilu']=$this->fstudent->hasilpemilu();
			$data['calon'][1]=$data['calon'][2]=$data['calon'][3]='0';
			foreach($data['hasilpemilu'] as $hasil){
				$data['calon'][$hasil['pilihan']]=$hasil['jumlah'];
			}
			$data['pemilih']=$this->fstudent->pemilih();
		    $this->pakaitemplate('student/pemilu',$data);
	    } else{
		    echo $data['sudah_pilih'];
	    }
	}
	
	//==========================================
	//          PEMBELAJARAN DARING
	//==========================================
	
	public function daftarmapel()
	{
	    $data=$this->getnisn();
	    $data['mapel']=$this->fstudent->daftar_mapel('video');
	    $data['mapel2']=$this->fstudent->daftar_mapel('audio');
	    $data['dokumen']=$this->fstudent->daftar_mapel('dokumen');
	    $data['soal']=$this->fstudent->daftar_mapel('soal');
	    $this->pakaitemplate('student/daftar_mapel',$data);
	}
	public function videoyt()
	{
	    if($this->input->post('materi')==null){
    	    $data['id']=$this->input->get('id');
    	    $data['videoyt']=$this->fstudent->videoyt($data);
    	    $this->pakaitemplate('student/videoyt',$data);
	    }else{
	        $data['notif_title']=$this->input->post('materi');
	        $data['notif_status']=$this->input->post('persen');
	        $data['notif_date']=date('Y-m-d H:i:s');
	        $data['notif_for']=$this->session->userdata('username');
	        $data['notif_content']=$this->input->post('notif_content');
	        $this->fstudent->videoyt($data);
	    }
	}
	public function audio()
	{
	    if($this->input->post('materi')==null){
    	    $data['id']=$this->input->get('id');
    	    $data['audio']=$this->fstudent->audio($data);
    	    $this->pakaitemplate('student/audio',$data);
	    }else{
	        $data['notif_title']=$this->input->post('materi');
	        $data['notif_status']=$this->input->post('persen');
	        $data['notif_date']=date('Y-m-d H:i:s');
	        $data['notif_for']=$this->session->userdata('username');
	        $data['notif_content']=$this->input->post('notif_content');
	        $this->fstudent->audio($data);
	    }
	}
	public function dokumen()
	{
	    if($this->input->post('materi')==null){
    	    $data['id']=$this->input->get('id');
    	    $data['dokumen']=$this->fstudent->audio($data);
    	    $this->pakaitemplate('student/dokumen',$data);
	    }else{
	        $data['notif_title']=$this->input->post('materi');
	        $data['notif_status']=$this->input->post('persen');
	        $data['notif_date']=date('Y-m-d H:i:s');
	        $data['notif_for']=$this->session->userdata('username');
	        $data['notif_content']=$this->input->post('notif_content');
	        $this->fstudent->audio($data);
	    }
	}
	public function pasgasal2020()
	{
		$data=$this->getnisn();
	    $data['mapel']=$this->fstudent->mapelpas2020();
	    $data['sudahpas']=$this->fstudent->sudahpas($data);
        $this->pakaitemplate('student/pasgasal2020',$data);
	}
	public function ulangan()
	{
	    $data['mapel']=$this->input->get('mapel');
	    $data['mapelpas']=$this->fstudent->mapelpas2020($data['mapel']);
	    $data['ikut_tes']=$this->fstudent->ikut_tes($data['mapel']);
        $this->pakaitemplate('student/ulangan',$data);
	}
	public function cekmapel()
	{
	    $mapel=$this->input->get('mapel');
	    $query=$this->fstudent->ikut_tes($mapel);
	    echo $query['mapel'];
	}
	public function presensi()
	{
	    $data['nisn']=$this->input->get('nisn');
	    if($data['nisn']==null || $this->session->userdata('user_level')>=7) $data['nisn']=$this->session->userdata('username');
	    $data['presensi']=$this->fstudent->presensi($data);
	    $this->pakaitemplate('student/presensi',$data);
	}
	public function soal_tes()
	{
	    $mapel=$this->input->get('mapel');
	    echo json_encode($this->fstudent->soal_tes($mapel));
	}
	public function jawaban_tes()
	{
	    $aksi=$this->input->get('aksi');
	    $data['nisn']=$this->session->userdata('username');
	    $data['waktu_selesai']=null;
	    if($aksi=='mulai') $data['waktu_mulai']=date('Y-m-d H:i:s');
	    else if($aksi=='selesai') $data['waktu_selesai']=date('Y-m-d H:i:s');
	    $data['mapel']=$this->input->get('mapel');
	    $data['jawaban']=$this->input->get('jawaban');
	    $data['nilai']=$this->input->get('nilai');
	    $data['pelanggaran']=$this->input->get('pelanggaran');
	    $data2=array(
	        'notif_for'=>$data['nisn'],
	        'notif_title'=>$data['mapel'],
	        'notif_status'=>'Jawaban Benar: '.$data['nilai'].' Pelanggaran: '.$data['pelanggaran'],
	        'notif_date'=>$data['waktu_selesai']
	        );
		$durasi=$this->fstudent->durasipas($data['mapel']);
	    $result=$this->fstudent->jawaban_tes($data,$aksi,$data2);
	    if($result=='selesai') echo 'selesai';
	    else{
	        if((strtotime($result)+($durasi*60))<=strtotime('now')){
	            echo 'gagal';
	        } else{
    	        $w=gmdate('H:i:s',strtotime($result)+($durasi*60)-strtotime('now'));
    	        $r=null;
	            $r['j']=substr($w,0,2);
    	        $r['m']=substr($w,3,2);
    	        $r['d']=substr($w,6,2);
    	        echo json_encode($r);
	        }
	    }
	}
	public function susulan()
	{
		$data=$this->getnisn();
	    $data['mapel']=$this->fstudent->mapelsusulan2020();
	    $data['sudahpas']=$this->fstudent->sudahpas($data);
		$data['kode']=$this->fstudent->sudahajukan($data['nisn']);
	    $this->pakaitemplate('student/susulan',$data);
	}
	public function remedi()
	{
		$data=$this->getnisn();
	    $data['mapel']=$this->fstudent->listmapelpas2020();
	    $data['sudahpas']=$this->fstudent->sudahpas($data);
	    $this->pakaitemplate('student/remedi',$data);
	}
	public function ajukan()
	{
		$data=$this->getnisn();
		$data['mapel']=$this->input->get('mapel');
		$data['ajukan']=$this->fstudent->ajukansusulan($data);
		echo $data['ajukan'];
	}
	public function batalkan()
	{
		$data=$this->getnisn();
		$data['mapel']=$this->input->get('mapel');
		$data['batalkan']=$this->fstudent->batalkansusulan($data);
		echo $data['batalkan'];
	}
//===============================================================
//							A R D
//===============================================================
	public function ard()
	{
		$data['statuswali']=$this->fstudent->statuswali();
	    echo 'sukses. silakan refresh jika ingin mengulangi.<a href="'.base_url('logout').'"><button>Logout</button></a>';
	}
	public function dataard()
	{
		$data['biodata']=$this->fstudent->dataard('biodata');
		$data['provinsi']=$this->fstudent->dataard('province');
		$data['kabupaten']=$this->fstudent->dataard(array('db'=>'regency','key'=>'master_province_id','val'=>$data['biodata']['master_province_id']));
		$data['kecamatan']=$this->fstudent->dataard(array('db'=>'district','key'=>'master_regency_id','val'=>$data['biodata']['master_regency_id']));
		$data['desa']=$this->fstudent->dataard(array('db'=>'village','key'=>'master_district_id','val'=>$data['biodata']['master_district_id']));
		$this->pakaitemplate('student/dataard',$data);
	}
	
}
