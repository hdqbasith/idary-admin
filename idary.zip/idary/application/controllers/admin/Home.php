<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//##############################################################
//  #     ###    ## ##   #   ##  #
// ###    #  #   # # #   #   # # #
//#   #   ###    #   #   #   #  ##
//##############################################################

class Home extends CI_Controller {
    function __construct(){
        parent::__construct();
		$this->load->model('fadmin');
		$this->user_level=$this->session->userdata('user_level');
		if($this->user_level>2 || $this->user_level==null){
		    redirect(base_url());
		}
    }
    //=======================================
    //              HALAMAN DASAR
    //=======================================
    // 1
	public function index()
	{
	    $data=array();
	    $this->pakaitemplate('admin/home',$data);
	}
	// 2
	public function pakaitemplate($content,$data)
	{
	    $level=$this->session->userdata('user_level');
	    $data['sidemenus']=$this->fungsi->sidemenu($level);
	    $this->load->view('template/header');
	    $this->load->view('template/topmenu');
	    $this->load->view('template/sidemenu',$data);
	    $this->load->view($content,$data);
	    $this->load->view('template/footer');
	}
	
	//#######################################
	//#             A D M I N               #
	//#######################################
	// 1
	public function edit_sidemenu()
	{
	    $data['fieldmenu']=$this->fadmin->getfield('template__menu');
	    $data['listmenu']=$this->fadmin->fulldata('template__menu','user_level asc, menu_order asc');
	    $this->pakaitemplate('admin/edit_sidemenu',$data);
	}
	
	
	//#######################################
	//#             P P D B                 #
	//#######################################
	// 1
	public function ppdb_administrasi()
	{
	    $data['fullfield']=$this->fadmin->getfield('student__ppdb');
	    $data['listpendaftar']=$this->fadmin->fulldata('student__ppdb');
	    $this->pakaitemplate('admin/ppdb_administrasi',$data);
	}
	// 2
	public function listpendaftar()
	{
	    $data['fullfield']=$this->fadmin->getfield('student__ppdb');
	    $data['fullsiswa']=$this->fadmin->fulldata('student__ppdb');
	    $this->pakaitemplate('admin/listpendaftar',$data);
	}
	// 3
	public function fullsiswa()
	{
	    $data['fullfield']=$this->fadmin->getfield('student__biodata');
	    $data['fullsiswa']=$this->fadmin->fulldata2('student__biodata');
	    $this->pakaitemplate('admin/fullsiswa',$data);
	}
	// 4
	public function fullsiswa2()
	{
	    $data['fullfield']=$this->fadmin->getfield('student__biodata');
	    $data['fullsiswa']=$this->fadmin->fulldata('student__biodata');
	    $this->pakaitemplate('admin/fullsiswa',$data);
	}
	// 5
	public function operasi()
	{
	    $data['fullfield']=$this->fadmin->getfield('student__ppdb');
	    $data['listpendaftar']=$this->fadmin->fulldata('student__ppdb');
	    $this->pakaitemplate('admin/operasi',$data);
	}
	// 6
	// 7
	public function ppdb_edit()
	{
	    $data['fullfield']=$this->fadmin->getfield('student__ppdb');
	    $data['listpendaftar']=$this->fadmin->fulldata('student__ppdb');
	    $this->pakaitemplate('admin/ppdb_edit',$data);
	}
	// 8
	public function siswa_list()
	{
	    $data['listsiswa']=$this->fadmin->listsiswa();
	    $this->pakaitemplate('admin/siswa_list',$data);
	}
	// 9
	public function reset_pass()
	{
	    $data['username']=$this->input->post('nisn');
	    if($data['username']==null){
    	    $this->pakaitemplate('admin/reset',$data);
	    } else{
    	    $hasil=$this->fadmin->reset_pass($data);
    	    echo $hasil;
	    }
	}
	// 10
	public function edit_kelas()
	{
	    $data['nisn']=$this->input->post('nisn');
	    if($data['nisn']==null){
	        $data['nisn']=$this->input->get('nisn');
    	    $data['detail']=$this->fadmin->edit_kelas($data);
    	    $this->pakaitemplate('admin/edit_kelas',$data);
	    } else{
	        $data['kelas']=$this->input->post('kelas');
	        $data['nama_lengkap']=$this->input->post('nama_lengkap');
	        $data['jurusan']=$this->input->post('jurusan');
	        $data['absen']=$this->input->post('absen');
    	    $hasil=$this->fadmin->edit_kelas($data);
    	    echo $hasil;
	    }
	}
	// 11
	public function presensi_daring()
	{
	    $data['kelas']=$this->input->get('kelas');
	    $data['bulan']=sprintf('%02d',$this->input->get('bulan'));
	    $data['presensi']=$this->fadmin->presensi_daring($data);
	    $this->pakaitemplate('admin/presensi_daring',$data);
	}
	// 12
	public function ver_susulan()
	{
		$data['siswa']=null;
		$data['mapel']=$this->input->get('mapel');
		if($data['mapel']==null) {
			$data['siswa']=$this->fadmin->ver_susulan();
			$this->pakaitemplate('admin/ver_susulan',$data);
		}
		else{
			unset($data['siswa']);
			$data['nisn']=$this->input->get('nisn');
			$approve['approve']=$this->input->get('approve');
			$data['approved']=$this->fadmin->ver_susulan($data,$approve);
		}
	}
	// 13
	public function hasilppdb()
	{
		$data['level']=$this->input->get('level');
		if($data['level']==null) {
			$data['siswa']=$this->fadmin->hasilppdb();
			$this->pakaitemplate('admin/hasilppdb',$data);
		}
		else{
		    unset($data['level']);
			$data['username']=$this->input->get('nisn');
			$approve['level']=$this->input->get('level');
			$data['approved']=$this->fadmin->hasilppdb($data,$approve);
			print_r($data);
		}
	}
	// 14
	public function ppdb_kartu()
	{
	    $data=null;
		$this->pakaitemplate('admin/kosong',$data);
	}
	public function ppdb_hasiltes()
	{
	    $data=null;
		$this->pakaitemplate('admin/kosong',$data);
	}
	public function ppdb_her()
	{
	    $data=null;
		$this->pakaitemplate('admin/kosong',$data);
	}
	public function ppdb_penjurusan()
	{
	    $data=null;
		$this->pakaitemplate('admin/kosong',$data);
	}
	
	//#######################################
	//#            S I S W A                #
	//#######################################
	
	
	//#######################################
	//#              G U R U                #
	//#######################################
	
	
	
//###############################################
//#                  A J A X                    #
//###############################################
//###################
//##    P P D B    ##
//###################
    // 1
	public function ppdb_bayar_reg()
	{
	    $data['nisn']=$this->input->get('nisn');
	    $data['bayar']=$this->input->get('bayar');
	    echo $this->fadmin->ppdb_bayar_reg($data);
	}
	// 2
	public function detailpendaftar()
	{
	    $nisn=$this->input->get('nisn');
	    echo json_encode($this->fadmin->detailpendaftar($nisn));
	}
	// 3
	public function simpanppdb()
	{
	    $data=null;
	    foreach ($_POST as $key => $value) {
            $data[$key]=$value;
        }
        $data['password']=md5('ungguliptek');
        $data['jrssiswa'].=$data['jrssiswa2'].$data['jrssiswa3'].$data['jrssiswa4'];
        unset($data['jrssiswa2'],$data['jrssiswa3'],$data['jrssiswa4'],$data['simpan']);
        if($data['daritbs']==0) unset($data['daritbs'],$data['kelasmts']);
        else {
            unset($data['daritbs']);
            $data['aslsb']='MTs NU TBS';
        }
        $result=$this->fadmin->simpanppdb($data);
	    echo $result;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public function simpan_sidemenu()
	{
        $data=array('menu_id'=>$this->input->post('menu_id'), 'menu_parent'=>$this->input->post('menu_parent'), 'menu_order'=>$this->input->post('menu_order'), 'menu_name'=>$this->input->post('menu_name'), 'menu_link'=>$this->input->post('menu_link'), 'user_level'=>$this->input->post('user_level'), 'menu_active'=>$this->input->post('menu_active'), 'menu_icon'=>$this->input->post('menu_icon'));
        $action='update';
        if($data['menu_id']==null) $action='insert';
        $this->fadmin->simpan_sidemenu($data,$action);
	}
	public function del_sidemenu()
	{
	    $menu_id=$this->input->post('menu_id');
	    $this->fadmin->del_sidemenu($menu_id);
	}
	public function aksipendaftar()
	{
	    $id=$this->input->get('id');
	    $aksi=$this->input->get('aksi');
	    $nilai=$this->input->get('nilai');
	    echo $this->fadmin->aksipendaftar($id,$aksi,$nilai);
	}
	
//==============================================================
//                  UMPTS
//==============================================================
	public function um()
	{
	    $this->load->view('umpts/um');
	}
	public function pts()
	{
	    $this->load->view('umpts/pts');
	}
	public function ujian_lokal()
	{
	    $this->load->view('umpts/ujian_lokal');
	}
	public function jawab()
	{
	    $this->load->view('umpts/jawab');
	}
	public function sukses()
	{
	    $this->load->view('umpts/sukses');
	}
	public function jawaban()
	{
        $data['nama']=$this->input->post('nama');
        $data['kelas']=$this->input->post('kelas');
        $data['absen']=$this->input->post('absen');
        $data['mapel']=$this->input->post('mapel');
        $data['pg']=null;
        for($n=1;$n<=50;$n++){
            $m=$this->input->post($n);
            if($m==null){
                $m=' ';
            };
            $data['pg'].=$m;
        }
        $data['essay1']=$this->input->post('51');
        $data['essay2']=$this->input->post('52');
        $data['essay3']=$this->input->post('53');
        $data['essay4']=$this->input->post('54');
        $data['essay5']=$this->input->post('55');
        $this->fadmin->kirim($data);
	}
	
	public function listterkirim()
	{
        $data['kelas']=$this->input->post('kelas');
        $data['mapel']=$this->input->post('mapel');
        $data['lihat']=$this->fadmin->lihat($data);
        $this->load->view('umpts/listterkirim',$data);
	}
	// public function gantijawaban()
	// {
	// 	$jsiswa=$this->fadmin->gantijawaban();
	// 	$ganti=null;
	// 	$nilai=null;
	// 	foreach ($jsiswa as $js) {
	// 		$ganti[$js['nisn']]=str_split($js['jawaban']);
	// 		$nilai[$js['nisn']]=0;
	// 	}
 //        $jawaban=str_split('becadebcacadeacbecadabcaecaecabeacedddbe');
 //        foreach ($ganti as $m=>$n) {
 //        	for ($i=0; $i <40 ; $i++) { 
	//         	if($jawaban[$i]==$n[$i]){
	//         		$nilai[$m]++;
	//         	}
 //        	}
 //        }
 //        $this->fadmin->gantijawaban($nilai);
 //        foreach ($nilai as $key => $value) {
 //        	echo $value.' ';
 //        }
	// }
//================================================================
//				ARD
//================================================================
	public function ardnaikkelas()
	{
        $data['kelas_asal']=$this->input->post('kelas_asal');
        $data['kelas_tujuan']=$this->input->post('kelas_tujuan');
        if($data['kelas_asal']!=null && $data['kelas_tujuan']!=null){
	        $data['ardnaikkelas']=$this->fadmin->ardnaikkelas($data);
        }
        $data['list_asal']=$this->fadmin->ardnaikkelas('a');
        $data['list_tujuan']=$this->fadmin->ardnaikkelas('t');
        $this->pakaitemplate('ard/naikkelas',$data);
	}
	public function ardmd5()
	{
		for($i=0;$i<100;$i++){
			echo md5(date("Y-m-d H:i:s").microtime())."<br/>";
		}
	}
	public function ardcopyngajar()
	{
		$this->fadmin->ardcopyngajar();
		echo 'ok';
	}
}
