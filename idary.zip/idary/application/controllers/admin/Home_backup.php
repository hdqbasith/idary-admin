<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
    function __construct(){
        parent::__construct();
		$this->load->model('fungsiadmin');
		/*if($this->session->userdata('user_level')!=1){
		    redirect(base_url());
		}*/
    }
	public function index()
	{
	    $data=array();
	    $this->pakaitemplate('admin/home',$data);
	}
	public function pakaitemplate($content,$data)
	{
	    $level=$this->session->userdata('user_level');
	    $data['sidemenus']=$this->fungsi->sidemenu($level);
	    $this->load->view('template/header');
	    $this->load->view('template/topmenu');
	    $this->load->view('template/sidemenu',$data);
	    $this->load->view($content,$data);
	    $this->load->view('template/footer');
	}
	public function edit_sidemenu()
	{
	    $data['listmenu']=$this->fungsiadmin->listmenu();
	    $data['fieldmenu']=$this->fungsiadmin->fieldmenu();
	    $this->pakaitemplate('admin/edit_sidemenu',$data);
	}
	public function simpan_sidemenu()
	{
        $data=array('menu_id'=>$this->input->post('menu_id'), 'menu_parent'=>$this->input->post('menu_parent'), 'menu_order'=>$this->input->post('menu_order'), 'menu_name'=>$this->input->post('menu_name'), 'menu_link'=>$this->input->post('menu_link'), 'user_level'=>$this->input->post('user_level'), 'menu_active'=>$this->input->post('menu_active'), 'menu_icon'=>$this->input->post('menu_icon'));
        $action='update';
        if($data['menu_id']==null) $action='insert';
        $this->fungsiadmin->simpan_sidemenu($data,$action);
	}
	public function del_sidemenu()
	{
	    $menu_id=$this->input->post('menu_id');
	    $this->fungsiadmin->del_sidemenu($menu_id);
	}
	//-------------------------UMPTS----------------------------
	public function jawab()
	{
	    $this->load->view('umpts/jawab');
	}
	public function um()
	{
	    $this->load->view('umpts/um');
	}
}
