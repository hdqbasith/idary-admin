<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
    function __construct(){
        parent::__construct();
		if($this->session->userdata('user_level')>6){
		    redirect(base_url());
		}
        $this->dbrevo = $this->load->database('revo', TRUE);
    }
//==============================================================
//                  HALAMAN
//==============================================================
	public function index()
	{
	    $data=array();
	    $this->pakaitemplate('pondok/home',$data);
	}
	public function getusername()
	{
	    $data['nama_pondok']=substr($this->session->userdata('username'),9);
	    return $data;
	}
	public function pakaitemplate($content,$data)
	{
	    $level=$this->session->userdata('user_level');
	    $data['sidemenus']=$this->fungsi->sidemenu($level);
	    $this->load->view('template/header');
	    $this->load->view('template/topmenu');
	    $this->load->view('template/sidemenu',$data);
	    $this->load->view($content,$data);
	    $this->load->view('template/footer');
	}
	public function pakaiblank($content,$data)
	{
	    $data['contents']=$this->load->view($content,$data,TRUE);
	    $this->load->view('blank',$data);
	}
	public function listsantri()
	{
	    $pondok=$this->getusername();
	    $data['listsantri']=$this->_listsantri($pondok);
	    $this->pakaitemplate('pondok/listsantri',$data);
	}
	public function presensi()
	{
	    if($this->input->get('bulan')==null){
    	    $pondok=$this->getusername();
    	    $data['listsantri']=$this->_listsantri($pondok);
    	    $w['date_start']=date('Y-m-d');
    	    $data['listmapel']=$this->dbrevo->select('*')->from('student__mapel')->like($w)->get()->result_array();
    	    $this->pakaitemplate('pondok/presensi',$data);
	    } else{
	        $data=$this->getusername();
	        $data['bulan']=sprintf('%02d',$this->input->get('bulan'));
            $data['presensi']=$this->dbrevo->select('nisn,nama_lengkap,kelas,DAY(notif_date) as notif_date')->from('pondok__santri')->join('student__biodata','nisnsantri=nisn')->join('user__notification','nisnsantri=notif_for','both')->where('kodepondok',$data['nama_pondok'])->like('notif_date','-'.$data['bulan'].'-')->get()->result_array();
            $this->pakaitemplate('pondok/rekap_presensi',$data);
	    }
	}
	public function detailsantri()
	{
	    $pondok=$this->getusername();
	    $pondok['nisn']=$this->input->get('nisn');
	    $data['detailsantri']=$this->_detailsantri($pondok);
	    $this->pakaitemplate('pondok/detailsantri',$data);
	}
	public function _listsantri($pondok)
	{
	    return $this->dbrevo->select('nisn,nama_lengkap,kelas,statussantri')->from('student__biodata')->join('pondok__santri','student__biodata.nisn=pondok__santri.nisnsantri','left')->where($pondok)->get()->result();
	}
	public function _detailsantri($pondok)
	{
	    return $this->dbrevo->select('*')->from('student__biodata')->join('pondok__santri','student__biodata.nisn=pondok__santri.nisnsantri','left')->where($pondok)->get()->result();
	}
	public function status_santri()
	{
	    $data['kodepondok']=$this->getusername()['nama_pondok'];
	    $data['nisnsantri']=$this->input->get('nisn');
	    $data['statussantri']=$this->input->get('status');
	    $q=$this->dbrevo->select('*')->from('pondok__santri')->where('nisnsantri',$data['nisnsantri'])->get()->row_array();
	    if($q==null) $this->dbrevo->insert('pondok__santri',$data);
	    elseif($data['statussantri']=='0') $this->dbrevo->delete('pondok__santri',array('nisnsantri'=>$data['nisnsantri']));
	    else $this->dbrevo->where('nisnsantri',$data['nisnsantri'])->update('pondok__santri',$data);
	}
	public function present()
	{
	    $data['notif_title']=$this->input->get('materi');
	    $data['notif_status']='mondok';
	    $pondok=$this->getusername();
	    $q=$this->dbrevo->select('nisnsantri')->from('pondok__santri')->where('kodepondok',$pondok['nama_pondok'])->where('statussantri','1')->get()->result_array();
	    foreach($q as $s){
	        $data['notif_for']=$s['nisnsantri'];
    	    $db2='user__notification';
            $w=array('notif_for'=>$data['notif_for'],'notif_title'=>$data['notif_title']);
            $r=$this->dbrevo->select('*')->from($db2)->where($w)->get()->row_array();
            if($r==null){
                $this->dbrevo->insert($db2,$data);
            }else{
                $this->dbrevo->where($w)->update($db2,$data);
            }
	    }
	}
	
}
