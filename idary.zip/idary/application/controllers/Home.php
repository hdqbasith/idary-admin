<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {


/*
||==========================================================================||
||                 DASAR                                                    ||
||==========================================================================||
*/
	public function index()
	{
        $level=$this->session->userdata('user_level');
        $link=$this->switch_link($level);
		redirect(base_url($link));
	}
	public function switch_link($level)
	{
	    $link='login';
        switch ($level) {
        	case 10:
                $link='student/ard';
        		break;
        	case 9:
                $link='applicant/index';
        		break;
        	case 8:
                $link='student/index';
        		break;
        	case 7:
                $link='alumni';
        		break;
        	case 6:
                $link='pondok/index';
        		break;
        	case 5:
                $link='student/penjurusan';
        		break;
        	case 4:
                $link='panitia/index';
        		break;
        	case 3:
                $link='teacher/index';
        		break;
        	case 2:
                $link='admin/index';
        		break;
        	case 1:
                $link='admin/index';
        		break;
        }
        return $link;
	}
	public function cekjs()
	{
	    echo 'Mohon aktifkan javascript di browser Anda!';
	}
	public function ceksesi()
	{
	    if($this->session->userdata('level')==null && $this->session->userdata('user')==null){
	        redirect(base_url('login'));
	    }
	}
	public function logout()
	{
		$this->session->sess_destroy();
		redirect(site_url('login'));
	}
	
	
	
	public function listprov()
	{
	    $parent=$this->input->get('parent');
	    echo json_encode($this->fungsi->listprov($parent));
	}
// 	public function listpondok()
// 	{
// 	    $id=$this->input->get('id');
// 	    echo json_encode($this->fungsi->listpondok($id));
// 	}
// 	public function nisn()
// 	{
// 	    $data['nisn']=json_encode($this->db->select('nisn,nama')->from('student__profilpat2020')->get()->result_array());
// 	    $this->pakaiblank('nisn',$data);
// 	}


// /*
// ||==========================================================================||
// ||                 LOGIN & SIGNUP                                           ||
// ||==========================================================================||
// */

    public function telat()
	{
		$username=$this->input->get('nisn');
		$this->session->set_userdata('username',$username);
        $this->session->set_userdata('user_level',9);
	    redirect(base_url('student/formulir_ppdb?action=new&nisn=').$username);
	}
    public function login()
	{
		$data = array(
		    'hrefmasuk'=>'cekuser',
		    'hrefdaftar'=>'ceknisn'
		    );
		//$this->template->set('title', 'Home');
		$this->template->load('blank', 'contents' , 'login', $data);
	}
	public function ceknisn()
	{
		$username=$this->input->post('nisn');
		$result = $this->fungsi->ceknisn($username);
		if(empty($result)){
    		$this->session->set_userdata('username',$username);
            $this->session->unset_userdata('user_fullname');
            $this->session->set_userdata('user_level',9);
		    echo $username;
		} else{
		    echo '';
		}
	}
	public function cekuser()
	{
	    $link='';
		$username=$this->input->post('username');
		$password=$this->input->post('password');
	    $result = $this->fungsi->cekuser($username);
	    if(!empty($result)){
	        foreach ($result as $value){
	            $pass=$value['password'];
	            if(md5($password)==$pass){
	                $this->session->set_userdata('username', $value['username']);
	                $this->session->set_userdata('user_fullname', $value['nama']);
	                $this->session->set_userdata('user_level', $value['level']);
	                $link=$this->switch_link($value['level']);
	            }
	        }
	    }
		echo $link;
	}



/*
||==========================================================================||
||                 TEMPLATE                                                 ||
||==========================================================================||
*/
	public function pakaitemplate($content,$data)
	{
	    $level=$this->session->userdata('user_level');
	    $data['sidemenus']=$this->fungsi->sidemenu($level);
	    $this->load->view('template/header');
	    $this->load->view('template/topmenu');
	    $this->load->view('template/sidemenu',$data);
	    $this->load->view($content,$data);
	    $this->load->view('template/footer');
	}
	public function pakaiblank($content,$data)
	{
	    $data['contents']=$this->load->view($content,$data,TRUE);
	    $this->load->view('blank',$data);
	}
	public function header()
	{
	    $data=array();
	    $this->load->view('template/header',$data);
	}
	public function footer()
	{
	    $data=array();
	    $this->load->view('template/footer',$data);
	}
	public function topmenu()
	{
	    $data=array();
	    $this->load->view('template/topmenu',$data);
	}
	public function sidemenu()
	{
	    $data=array();
	    $level=$this->session->userdata('user_level');
	    $data['sidemenus']=$this->fungsi->sidemenu($level);
	    $this->load->view('template/sidemenu',$data);
	}
	public function icons()
	{
	    $data=array();
	    $this->pakaitemplate('icons',$data);
	}
    
// 	public function cekuuid()
// 	{
// 	    $this->fungsi->cekuuid();
// 	}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
