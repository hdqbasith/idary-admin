<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
    function __construct(){
        parent::__construct();
		$this->load->model('fpanitia');
		if($this->session->userdata('user_level')!=4){
		    redirect(base_url());
		}
    }
//==============================================================
//                  HALAMAN
//==============================================================
	public function index()
	{
	    $data=array();
	    $this->pakaitemplate('panitia/home',$data);
	}
	public function pakaitemplate($content,$data)
	{
	    $level=$this->session->userdata('user_level');
	    $data['sidemenus']=$this->fungsi->sidemenu($level);
	    $this->load->view('template/header');
	    $this->load->view('template/topmenu');
	    $this->load->view('template/sidemenu',$data);
	    $this->load->view($content,$data);
	    $this->load->view('template/footer');
	}
	public function pakaiblank($content,$data)
	{
	    $data['contents']=$this->load->view($content,$data,TRUE);
	    $this->load->view('blank',$data);
	}
	public function listpendaftar()
	{
	    $data['listpendaftar']=$this->fpanitia->listpendaftar();
	    $this->pakaitemplate('panitia/listpendaftar',$data);
	}
	public function formulir_full()
	{
	    $data['detail']=$this->fstudent->detail_student($this->session->userdata('username'));
	    $data['ppdb']=$this->fstudent->detail_ppdb($this->session->userdata('username'));
	    $data['provs']=$this->listprov(0);
	    if($data['detail']['propinsi_siswa']>0) $data['kabs']=$this->listprov($data['detail']['propinsi_siswa']);
	    if($data['detail']['kabupaten_siswa']>0) $data['kecs']=$this->listprov($data['detail']['kabupaten_siswa']);
	    if($data['detail']['kecamatan_siswa']>0) $data['kels']=$this->listprov($data['detail']['kecamatan_siswa']);
	    if($data['detail']['propinsi_ortu']>0) $data['kabo']=$this->listprov($data['detail']['propinsi_ortu']);
	    if($data['detail']['kabupaten_ortu']>0) $data['keco']=$this->listprov($data['detail']['kabupaten_ortu']);
	    if($data['detail']['kecamatan_ortu']>0) $data['kelo']=$this->listprov($data['detail']['kecamatan_ortu']);
        $this->pakaitemplate('student/formulir_full',$data);
	}
	public function matsama_presensi()
	{
	    $materi=array(
	        ''=>null,
            '1'=>'Sambutan Kepala MA NU TBS Kudus',
            '2'=>'Profil MA NU TBS Kudus',
            '3'=>'Kesiswaan dan Ekstra Kurikuler MA NU TBS Kudus',
            '4'=>'Do`a Awal dan Akhir Pembelajaran MA NU TBS Kudus',
            '5'=>'Tata tertib MA NU TBS Kudus',
            '6'=>'Lembaga Pengembangan Bakat MA NU TBS Kudus',
            '7'=>'Seputar Persatuan Pelajar MA NU TBS Kudus',
            '8'=>'Ke-Aswajaan',
            '9'=>'Kurikulum MA NU TBS Kudus'
        );
	    $data['kelompok']=$this->input->get('kelompok');
	    $mat=$this->input->get('materi');
	    $data['materi']=$materi[$mat];
	    $data['peserta']=null;
	    $data['presensi']=null;
	    if($data['materi']!=null){
    	    $data['peserta']=$this->fpanitia->matsama_peserta($data['kelompok']);
    	    $data['presensi']=$this->fpanitia->matsama_presensi($data);
	    }
	    $data['mat']=$mat;
        $this->pakaitemplate('panitia/presensi',$data);
	}
	public function matsama()
	{
	    $m=$this->input->get('nomor');
	    if($m!=null) $this->matsama_login($m);
	    $data=null;
        $this->pakaitemplate('panitia/matsama',$data);
	}
	public function matsama_kel()
	{
	    $data['nisn']=$this->input->post('nisn');
	    $data['var']='kelompok';
	    $data['val']=$this->input->post('kelompok');
	    $data['mentor']=$this->session->userdata('username');
	    $data['date']=date('Y-m-d H:i:s');
	    
        $this->fpanitia->matsama_kel($data);
	}
	public function matsama_login($m)
	{
	    $materi=array(
	        ''=>null,
            '1'=>'Sambutan Kepala MA NU TBS Kudus',
            '2'=>'Profil MA NU TBS Kudus',
            '3'=>'Kesiswaan dan Ekstra Kurikuler MA NU TBS Kudus',
            '4'=>'Do`a Awal dan Akhir Pembelajaran MA NU TBS Kudus',
            '5'=>'Tata tertib MA NU TBS Kudus',
            '6'=>'Lembaga Pengembangan Bakat MA NU TBS Kudus',
            '7'=>'Seputar Persatuan Pelajar MA NU TBS Kudus',
            '8'=>'Ke-Aswajaan',
            '9'=>'Kurikulum MA NU TBS Kudus'
        );
	    $data['nisn']=$this->session->userdata('username');
	    $data['var']=$materi[$m];
	    $data['catatan']='sudah login';
	    $data['date']=date('Y-m-d H:i:s');
	    
        $this->fpanitia->matsama_login($data);
	}
	public function matsama_jawab()
	{
	    $data['nisn']=$this->session->userdata('username');
	    $data['var']=$this->input->post('materi');
	    $data['val']=$this->input->post('jawaban');
	    $data['date']=date('Y-m-d H:i:s');
	    $data['catatan']=$this->input->post('persen');
        $this->fpanitia->matsama_jawab($data);
	}
	public function penjurusan()
	{
	    $data['hasil']['TPA']=$this->db->select('namasiswa as nama_lengkap,jrssiswa AS pil_jurusan,student__jawaban_ppdb.*')->from('student__ppdb')->join('student__jawaban_ppdb','student__jawaban_ppdb.nisn=student__ppdb.nisn','both')->where('mapel','TPA')->get()->result_array();
	    $data['hasil']['MIA']=$this->db->select('namasiswa as nama_lengkap,jrssiswa AS pil_jurusan,student__jawaban_ppdb.*')->from('student__ppdb')->join('student__jawaban_ppdb','student__jawaban_ppdb.nisn=student__ppdb.nisn','both')->where('mapel','MIA')->get()->result_array();
	    $data['hasil']['IIS']=$this->db->select('namasiswa as nama_lengkap,jrssiswa AS pil_jurusan,student__jawaban_ppdb.*')->from('student__ppdb')->join('student__jawaban_ppdb','student__jawaban_ppdb.nisn=student__ppdb.nisn','both')->where('mapel','IIS')->get()->result_array();
	    $data['hasil']['IIB']=$this->db->select('namasiswa as nama_lengkap,jrssiswa AS pil_jurusan,student__jawaban_ppdb.*')->from('student__ppdb')->join('student__jawaban_ppdb','student__jawaban_ppdb.nisn=student__ppdb.nisn','both')->where('mapel','IIB')->get()->result_array();
	    $data['hasil']['IIK']=$this->db->select('namasiswa as nama_lengkap,jrssiswa AS pil_jurusan,student__jawaban_ppdb.*')->from('student__ppdb')->join('student__jawaban_ppdb','student__jawaban_ppdb.nisn=student__ppdb.nisn','both')->where('mapel','IIK')->get()->result_array();
	   // $data['hasil']['TPA']=$this->db->select('student__jawaban_ppdb.*,nama_lengkap,pil_jurusan')->from('student__jawaban_ppdb')->where('mapel','TPA')->where('waktu_mulai>=','2020-07-15 06:00:00')->join('biodata__student','student__jawaban_ppdb.nisn=biodata__student.nisn','both')->get()->result_array();
	   // $data['hasil']['MIA']=$this->db->select('student__jawaban_ppdb.*,nama_lengkap,pil_jurusan')->from('student__jawaban_ppdb')->where('mapel','MIA')->where('waktu_mulai>=','2020-07-15 06:00:00')->join('biodata__student','student__jawaban_ppdb.nisn=biodata__student.nisn','both')->get()->result_array();
	   // $data['hasil']['IIS']=$this->db->select('student__jawaban_ppdb.*,nama_lengkap,pil_jurusan')->from('student__jawaban_ppdb')->where('mapel','IIS')->where('waktu_mulai>=','2020-07-15 06:00:00')->join('biodata__student','student__jawaban_ppdb.nisn=biodata__student.nisn','both')->get()->result_array();
	   // $data['hasil']['IIB']=$this->db->select('student__jawaban_ppdb.*,nama_lengkap,pil_jurusan')->from('student__jawaban_ppdb')->where('mapel','IIB')->where('waktu_mulai>=','2020-07-15 06:00:00')->join('biodata__student','student__jawaban_ppdb.nisn=biodata__student.nisn','both')->get()->result_array();
	   // $data['hasil']['IIK']=$this->db->select('student__jawaban_ppdb.*,nama_lengkap,pil_jurusan')->from('student__jawaban_ppdb')->where('mapel','IIK')->where('waktu_mulai>=','2020-07-15 06:00:00')->join('biodata__student','student__jawaban_ppdb.nisn=biodata__student.nisn','both')->get()->result_array();
        $this->pakaitemplate('panitia/penjurusan',$data);
	}
}
