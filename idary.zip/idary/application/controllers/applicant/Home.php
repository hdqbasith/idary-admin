<?php
defined('BASEPATH') OR exit('No direct script access allowed');


//  ++++     +     +       ++++  +   +
// +        + +    +      +    + ++  +
// +       +++++   +      +    + + + +
// +      +     +  +      +    + +  ++
//  ++++ +       + ++++++  ++++  +   +


class Home extends CI_Controller {
    //=======================================
    //              PENDAHULUAN             
    //=======================================
    function __construct(){
        parent::__construct();
        $this->load->model('fapplicant');
        $this->load->model('fstudent');
        $this->dbrevo = $this->load->database('revo', TRUE);
        // $this->ceksesi();
    }
	public function ceksesi()
	{
	    if($this->session->userdata('level')==null && $this->session->userdata('username')==null){
	        redirect(base_url('login'));
	    }
	}
	public function pakaitemplate($content,$data)
	{
	    $level=$this->session->userdata('user_level');
	    $data['sidemenus']=$this->fungsi->sidemenu($level);
	    $this->load->view('template/header');
	    $this->load->view('template/topmenu');
	    $this->load->view('template/sidemenu',$data);
	    $this->load->view($content,$data);
	    $this->load->view('template/footer');
	}
	public function pakaiblank($content,$data)
	{
	    $data['contents']=$this->load->view($content,$data,TRUE);
	    $this->load->view('blank',$data);
	}
	
    //=======================================
    //              HALAMAN             
    //=======================================
	
	// 1
	public function index()
	{
	    $data['tbs']=$this->dbrevo->select('kelasmts')->from('student__ppdb')->where('nisn',$this->session->userdata('username'))->get()->row_array();
	    $data['banned']=$this->dbrevo->select('ket')->from('student__ppdb')->where('nisn',$this->session->userdata('username'))->get()->row_array();
	    $this->pakaitemplate('applicant/home',$data);
	}
	// 2
	public function perbaikan()
	{
	    $this->pakaitemplate('applicant/perbaikan',null);
	}
	// 3
	public function formulir_ppdb()
	{
	    $data['nisn']=$this->input->get('nisn');
	    $data['action']=$this->input->get('action');
	    if($data['action']=='new'){
	        $this->pakaiblank('applicant/formulir_ppdb',$data);
	    } else $this->pakaitemplate('applicant/formulir_ppdb',$data);
	}
	// 4
	public function suksesdaftar()
	{
	    $data['nama_madrasah']=$this->fapplicant->get_detail('user__setting',array('setting_key'=>'nama_madrasah'));
	    $data['ta']=$this->fapplicant->get_detail('user__setting',array('setting_key'=>'tahun_ajaran'));
        $this->pakaiblank('applicant/suksesdaftar',$data);
	}
	// 5
	public function formulir_full()
	{
	    $data=$this->fstudent->formulir_full(0);
        $this->pakaitemplate('student/biodata',$data);
	}
	// 6
	public function cetak_kartu()
	{
	    $data=$this->fapplicant->kartu_tes_ppdb();
	    $data['ppdb']=$this->fapplicant->detail_ppdb($this->session->userdata('username'));
        $this->pakaitemplate('applicant/kartu',$data);
	}
	// 7
	public function tes()
	{
	   // $query=$this->dbrevo->select('id')->from('biodata__student')->where('nisn',$this->session->userdata('username'));
	   // echo $this->dbrevo->get_compiled_select($query);
	   // $data=null;
        // $this->pakaitemplate('applicant/tes',$data);
	}
	// 8
	public function sim_cbtppdb()
	{
	    $data=$this->fapplicant->sim_cbtppdb();
        $this->pakaitemplate('applicant/ulangan',$data);
	}
	// 9
	public function seleksippdb()
	{
	    $data=$this->fapplicant->seleksippdb();
        $this->pakaitemplate('applicant/ulangan',$data);
	}
	// 10
	public function rekap()
	{
	    $data['nilai']=json_encode($this->dbrevo->select('student__jawaban_ppdb.nisn,nilai,namasiswa,aslsb')->from('student__jawaban_ppdb')->join('student__ppdb', 'student__jawaban_ppdb.nisn = student__ppdb.nisn', 'left')->get()->result_array());
        $this->pakaitemplate('applicant/rekap',$data);
	}
	// 11
	public function hasiltes()
	{
	    
	    $data['diterima']=$this->dbrevo->select('kelasmts,mpa')->from('student__ppdb')->where('nisn',$this->session->userdata('username'))->get()->row_array();
        $this->pakaitemplate('applicant/hasiltes',$data);
	}
	// 12
	public function matsama()
	{
	    $data=null;
        $this->pakaitemplate('applicant/matsama',$data);
	}
	// 13
	public function matsama2()
	{
	    $m=$this->input->get('nomor');
	    if($m!=null) $this->matsama_login($m);
	    $data['log']=$this->dbrevo->select('*')->from('student__matsama')->where('nisn',$this->session->userdata('username'))->get()->result_array();
        $this->pakaitemplate('applicant/matsama2',$data);
	}
	// 14
	public function penjurusan()
	{
	    $data['lengkap']=$this->cekdatalengkap();
	    $data['sudahtes']=$this->dbrevo->select('mapel')->from('student__jawaban_ppdb')->where('nisn',$this->session->userdata('username'))->get()->result_array();
	    $data['pil_jur']=$this->dbrevo->select('pil_jurusan as jrssiswa')->from('student__biodata')->where('nisn',$this->session->userdata('username'))->get()->row_array();
        $this->pakaitemplate('applicant/penjurusan',$data);
	}
	// 15
	public function hasilpenjurusan()
	{
	    $data['nisn']=$this->session->userdata('username');
	    $data['lengkap']=$this->cekdatalengkap();
        $this->pakaitemplate('applicant/hasilpenjurusan',$data);
	}
	//16
	public function khataman()
	{
	    $data['jumlah']=$this->dbrevo->select('SUM(khatam) as jumlah')->from('student__khataman')->get()->row_array();
	    $data['listsiswa']=$this->fapplicant->listsiswa();
        $this->pakaiblank('applicant/khataman',$data);
	}
	// 17
	public function gantinisn()
	{
	    $data['nisn_lama']=$this->input->post('nisn_lama');
	    $data['nisn_baru']=$this->input->post('nisn_baru');
	    $data['password_lama']=$this->input->post('password_lama');
	    if($data['nisn_baru']!=null) {
	        $q=$this->dbrevo->select('*')->from('user')->where('username',$data['nisn_lama'])->where('password',md5($data['password_lama']))->get()->row_array();
	        if($q==null) echo 'gagal';
	        else $data['sukses']=$this->fapplicant->gantinisn($data);
	    } else $this->pakaitemplate('applicant/gantinisn',$data);
	}
	
//========================================================
//
//                        A J A X
//
//========================================================
	// 1
	public function simpanppdb()
	{
	    $data=null;
	    foreach ($_POST as $key => $value) {
            $data[$key]=$value;
        }
        $data['password']=md5('ungguliptek');
        $data['jrssiswa'].=$data['jrssiswa2'].$data['jrssiswa3'].$data['jrssiswa4'];
        unset($data['jrssiswa2'],$data['jrssiswa3'],$data['jrssiswa4'],$data['simpan']);
        if($data['daritbs']==0) unset($data['daritbs'],$data['kelasmts']);
        else {
            unset($data['daritbs']);
            $data['aslsb']='MTs NU TBS';
        }
        $result=$this->fapplicant->simpanppdb($data);
	    echo $result;
	}
	//=========================================
	//                    PAT 2020
	//=========================================
	public function home()
	{
	    $data['nilai']=json_encode($this->dbrevo->select('nama,student__profilpat2020.kelas,student__mapelpat2020.kelas as class,absen,pelajaran,nilai')->from('student__profilpat2020')->distinct()->where('student__profilpat2020.nisn',$this->session->userdata('username'))->order_by('pelajaran')->join('student__jawabanpat2020', 'student__profilpat2020.nisn = student__jawabanpat2020.nisn', 'inner')->join('student__mapelpat2020', 'student__jawabanpat2020.mapel = kode', 'inner')->get()->result_array());
        $data['pass']=$this->fapplicant->cekpass();
        $data['profil']=$this->dbrevo->select('*')->from('student__profilpat2020')->where('nisn',$this->session->userdata('username'))->get()->row_array();
		$this->pakaitemplate('applicant/home2',$data);
	}
// 	public function simpan_profilpat()
// 	{
// 	    $data=null;
// 	    foreach ($_POST as $key => $value) {
//             $data[$key]=$value;
//         }
//         $data['password']=md5($data['password']);
//         unset($data['password2']);
// 	    $this->fapplicant->simpan_profilpat($data);
// 	}
// 	public function pat2020()
// 	{
// 	    $data['mapel']=$this->input->get('mapel');
//         $this->pakaitemplate('applicant/pat2020',$data);
// 	}
// 	public function soal_pat2020()
// 	{
// 	    $mapel=$this->input->get('mapel');
// 	    echo json_encode($this->fapplicant->pat2020($mapel));
// 	}
	public function jawaban_pat2020()
	{
	    $aksi=$this->input->get('aksi');
	    $data['nisn']=$this->session->userdata('username');
	    if($aksi=='mulai') $data['mulai']=date('Y-m-d H:i:s');
	    else if($aksi=='selesai') $data['selesai']=date('Y-m-d H:i:s');
	    $data['mapel']=$this->input->get('mapel');
	    $data['jawaban']=$this->input->get('jawaban');
	    $data['nilai']=$this->input->get('nilai');
	    $result=$this->fapplicant->jawaban_pat2020($data,$aksi);
	    if($result=='selesai') echo 'selesai';
	    else{
	        if((strtotime($result)+(90*60))<=strtotime('now')){
	            echo 'gagal';
	        } else{
	            $j=strtotime($result)+(90*60)-strtotime('now');
    	        $w=date('H:i:s',strtotime($result)+(90*60)-strtotime('now'));
    	        $r=null;
    	        if($j>3600 && $j<7200) $r['j']='01';
    	        else $r['j']='00';
    	        $r['m']=substr($w,3,2);
    	        $r['d']=substr($w,6,2);
    	        echo json_encode($r);
	        }
	    }
	}
// 	public function matwaxi()
// 	{
// 	    $a=null;
// 	    $b=null;
// 	    $nilai=null;
// 	    $jawaban=$this->dbrevo->select('nomor,jawaban')->from('student__soal_ppdb')->where('mapel','matwaxi')->order_by('nomor')->get()->result_array();
// 	    foreach($jawaban as $j){
// 	        $a[$j['nomor']]=$j['jawaban'];
// 	    }
// 	    $mat=$this->dbrevo->select('nisn,jawaban')->from('student__jawabanpat2020')->where('mapel','matwaxi')->get()->result_array();
// 	    foreach($mat as $m){
// 	        $b[$m['nisn']]=$m['jawaban'];
// 	        $k=0;
//     	    $i=1;
//     	    $nilai[$m['nisn']]=0;
// 	        foreach(str_split($b[$m['nisn']]) as $k=>$n){
// 	            if($n==$a[$k+1]){    
// 	                $nilai[$m['nisn']]+=1;
// 	            }
//                 // else if($i>=20 && $i<=30){
// 	               // $nilai[$m['nisn']]+=1;
//                 // }
//                 // $i++;
// 	        }
// 	    }
// 	    $i=0;
// 	    foreach($nilai as $m=>$n){
// 	        $data['nilai']=$n;
//             $this->dbrevo->where('nisn',$m)->where('mapel','matwaxi')->update('student__jawabanpat2020',$data);
// 	        echo $n.' sukses <br/>';
// 	    }
// 	}
	public function leger()
	{
	    $data['kelas']=$this->input->get('kelas');
        if($data['kelas']==null) $data['kelas']="X A";
        $kel=substr($data['kelas'],0,2);
	    $data['listmapel']=$this->dbrevo->select('kode,pelajaran,kelas, COUNT(mapel) AS jum')->from('student__mapelpat2020')->order_by('pelajaran')->like('kelas',$kel)->join('student__soal_ppdb', 'student__mapelpat2020.kode = student__soal_ppdb.mapel', 'inner')->group_by('mapel')->get()->result_array();
	    $mentah=$this->dbrevo->select('nama,kelas,absen,mapel,jawaban,nilai')->from('student__profilpat2020')->where('kelas',$data['kelas'])->order_by('absen')->join('student__jawabanpat2020', 'student__profilpat2020.nisn = student__jawabanpat2020.nisn', 'left')->get()->result_array();
	    foreach($mentah as $m){
	        $mateng[$m['nama']]['absen']=$m['absen'];
	        $mateng[$m['nama']]['kelas']=$m['kelas'];
	        $mateng[$m['nama']]['nama']=$m['nama'];
	        $mateng[$m['nama']][$m['mapel']]=$m['nilai'];
	    }
	    $data['nilai']=json_encode($mateng);
		$this->pakaitemplate('applicant/leger',$data);
	}
	public function cek()
	{
	   // foreach($this->dbrevo->select("nisn")->from("student__jawabanpat2020")->order_by("nisn","asc")->group_by("jawaban,mapel,nisn")->having('count(*) > 1')->get()->result_array() as $r){
	   //     echo $r['nisn'].', ';
	   // };
	   
	}
	//=========================================
	//                    FUNGSI
	//=========================================
	public function jawaban_ppdb()
	{
	    $aksi=$this->input->get('aksi');
	    $data['nisn']=$this->session->userdata('username');
	    if($aksi=='mulai') $data['waktu_mulai']=date('Y-m-d H:i:s');
	    else if($aksi=='selesai') $data['waktu_selesai']=date('Y-m-d H:i:s');
	    $data['jawaban']=$this->input->get('jawaban');
	    $data['nilai']=$this->input->get('nilai');
	    $data['pelanggaran']=$this->input->get('pelanggaran');
	    $result=$this->fapplicant->jawaban_ppdb($data,$aksi);
	    if($result=='selesai') echo 'selesai';
	    else{
	        if((strtotime($result)+(120*60))<=strtotime('now')){
	            echo 'gagal';
	        } else{
	            $j=strtotime($result)+(120*60)-strtotime('now')-1;
    	        $w=date('H:i:s',strtotime($result)+(120*60)-strtotime('now')-1);
    	        $r=null;
    	        if($j>3600 && $j<7200) $r['j']='01';
    	        else $r['j']='00';
    	        $r['m']=substr($w,3,2);
    	        $r['d']=substr($w,6,2);
    	        echo json_encode($r);
	        }
	    }
	}
	public function get_soal()
	{
	    echo json_encode($this->fapplicant->get_soal());
	}
	public function banned()
	{
	    $data['nisn']=$this->input->get('nisn');
	    $data['banned']=$this->input->get('banned');
	    $this->fapplicant->banned($data);
	}
	public function listprov($parent)
	{
	    return $this->fungsi->listprov($parent);
	}
	public function simpanfull()
	{
	    $data=null;
	    foreach ($_POST as $key => $value) {
            $data[$key]=$value;
        }
        if(isset($data['tanggal_lahir'])) $data['tanggal_lahir']=date('Y-m-d',strtotime($data['tanggal_lahir']));
        if(isset($data['tahun_lahir_ayah_kandung'])) $data['tahun_lahir_ayah_kandung']=date('Y-m-d',strtotime($data['tahun_lahir_ayah_kandung']));
        if(isset($data['tahun_lahir_ibu_kandung'])) $data['tahun_lahir_ibu_kandung']=date('Y-m-d',strtotime($data['tahun_lahir_ibu_kandung']));
        if(isset($data['tahun_lahir_wali'])) $data['tahun_lahir_wali']=date('Y-m-d',strtotime($data['tahun_lahir_wali']));
        $result=$this->fapplicant->simpanfull($data);
	    echo $result;
	}
	public function hasiltespdf()
	{
	    $hasiltes=$this->dbrevo->select('namasiswa,nisn,id,aslsb,mpa')->from('student__ppdb')->where('nisn',$this->session->userdata('username'))->get()->row_array();
	    if($hasiltes['mpa']==1) $hasiltes['mpa']='Madrasah Persiapan Aliyah (MPA)';
	    else $hasiltes['mpa']='Madrasah Aliyah (MA)';
	    $this->load->library('Tcpdf');
	    $pdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
	    $pdf->SetFont('times', '', 14, '', false);
        $pdf->SetTitle('My Title');
        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);
        $pdf->SetTopMargin(10);
        $pdf->SetAutoPageBreak(true);
        $pdf->SetAuthor('Author');
        $pdf->SetDisplayMode('real', 'default');
        $pdf->AddPage();
        $style = array(
            'cellfitalign' => 'R',
            'padding' => 'auto',
            'fgcolor' => array(0,0,0),
            'vpadding' => 'auto',
        );
        $html='<style>
        .text-center{text-align:center}
        .text-justify{text-align:justify}
        .text-right{text-align:right}
        </style>';
        $html.='<img src="https://1.bp.blogspot.com/-4raLILXXx9U/XvScyOTK4aI/AAAAAAAANLQ/tTqZ-hYiNSgV_T_ojkxH7qmadNPmxTddgCLcBGAsYHQ/s1600/header.jpg" width=100% style="margin-top:-10px">';
        
        
        $html.='<h3 class="text-center"><u>SURAT KETERANGAN</u></h3>
        <h4 class="text-center">Nomor : B. 893/MRF/MA NU TBS/VI/2020</h4>
        <p class="text-justify">Berdasarkan hasil dari Tes Tulis dan Tes Lisan dan diputuskan dalam Rapat Penegas Penerimaan Peserta Didik Baru antara Pengurus Madrasah, Kepala MA, Wakil Kepala dan Panitia PPDB pada hari Rabu, 24 Juni 2020 menerangkan bahwa calon siswa dengan identitas di bawah ini:</p>
        <h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table>
        <tbody>
        <tr>
        <td width="110px">Nama</td><td width="350px">: '.$hasiltes['namasiswa'].'</td>
        </tr>
        <tr>
        <td>NISN</td><td>: '.$hasiltes['nisn'].'</td>
        </tr>
        <tr>
        <td>No. Pendaftaran</td><td>: 341'.sprintf("%03d",$hasiltes['id']).'</td>
        </tr>
        <tr>
        <td>Asal Sekolah</td><td>: '.$hasiltes['aslsb'].'</td>
        </tr>
        </tbody>
        </table>
        </h4>
        <span class="text-center">Telah Diterima di :</span>
        <h3 class="text-center">'.$hasiltes['mpa'].'<br/>NU Tasywiquth Thullab Salafiyah ( TBS ) Kudus</h3>
        <p>Demikian surat keterangan ini kami buat dengan sebenarnya untuk dipergunakan sebagaimana mestinya.</p>
        <img src="https://1.bp.blogspot.com/-kyl6qudSups/XvSstwH5uyI/AAAAAAAANLk/sZEBr3JXhDobQM4c0w8b2eKTZ6Q9dRp5wCLcBGAsYHQ/s1600/New%2BPicture.png" class="text-right" width="245px">
        <p><i>*Surat ini harap dicetak sebagai persyaratan daftar ulang</i></p>
        ';
        $pdf->writeHTMLCell(0, 0, '', '', $html, 0, 1, 0, true, '', true);
        $pdf->Ln(4);
        $pdf->write1DBarcode($hasiltes['nisn'], 'C39', '', '', '', 18, 0.4, $style, 'N');
        
        $pdf->Output($hasiltes['nisn'].'.pdf', 'I');
	}
	public function hasiltespenjurusan()
	{
	    $jur=array('1'=>'Matematika dan Ilmu Alam (MIA)','2'=>'Ilmu-Ilmu Sosial (IIS)','3'=>'Ilmu Bahasa dan Budaya (IIB)','4'=>'Ilmu-Ilmu Keagamaan (IIK)');
	    $hasiltes=$this->dbrevo->select('student__ppdb.nisn,student__ppdb.id,namasiswa,kelas,jurusan')->from('student__ppdb')->where('student__ppdb.nisn',$this->session->userdata('username'))->join('biodata__student','student__ppdb.nisn=biodata__student.nisn','left')->get()->row_array();
	    $this->load->library('Tcpdf');
	    $pdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
	    $pdf->SetFont('times', '', 14, '', false);
        $pdf->SetTitle('My Title');
        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);
        $pdf->SetTopMargin(10);
        $pdf->SetAutoPageBreak(true);
        $pdf->SetAuthor('Author');
        $pdf->SetDisplayMode('real', 'default');
        $pdf->AddPage();
        $style = array(
            'cellfitalign' => 'R',
            'padding' => 'auto',
            'fgcolor' => array(0,0,0),
            'vpadding' => 'auto',
        );
        $html='<style>
        .text-center{text-align:center}
        .text-justify{text-align:justify}
        .text-right{text-align:right}
        </style>';
        $html.='<img src="https://1.bp.blogspot.com/-4raLILXXx9U/XvScyOTK4aI/AAAAAAAANLQ/tTqZ-hYiNSgV_T_ojkxH7qmadNPmxTddgCLcBGAsYHQ/s1600/header.jpg" width=100% style="margin-top:-10px">';
        
        
        $html.='<h3 class="text-center"><u>SURAT KETERANGAN</u></h3>
        <h4 class="text-center">Nomor : B. 907/MRF/MA NU TBS/VII/2020</h4>
        <p class="text-justify">Berdasarkan Hasil Tes Penjurusan dan Rapat Penegas Penjurusan pada hari Kamis, 24 Dzul Qo’dah 1441 H / 16 Juli 2020 M menerangkan bahwa siswa kelas X dengan identitas di bawah ini:</p>
        <h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table>
        <tbody>
        <tr>
        <td width="110px">Nama</td><td width="350px">: '.$hasiltes['namasiswa'].'</td>
        </tr>
        <tr>
        <td>No. Pendaftaran</td><td>: 341'.sprintf("%03d",$hasiltes['id']).'</td>
        </tr>
        <tr>
        <td>NISN</td><td>: '.$hasiltes['nisn'].'</td>
        </tr></tbody></table></h4>
        '.br(1).'Telah diterima di: '.br(1).'
        <h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table><tbody><tr>
        <td width="110px">Jurusan</td><td width="350px">: '.$jur[$hasiltes['jurusan']].'</td>
        </tr>
        <tr>
        <td>Kelas</td><td>: '.$hasiltes['kelas'].'</td>
        </tr>
        </tbody>
        </table>
        </h4>
        <p>Demikian surat keterangan ini kami buat dengan sebenarnya untuk dipergunakan sebagaimana mestinya.</p>
        <img src="https://1.bp.blogspot.com/-k_nnhCAmjbI/XxEUTagUtrI/AAAAAAAANNM/p11vh-6fctIGDfb4E0o7EgAB-PqnN0jIQCLcBGAsYHQ/s1600/Screenshot_1.png" class="text-right" width="245px">
        
        ';
        $pdf->writeHTMLCell(0, 0, '', '', $html, 0, 1, 0, true, '', true);
        $pdf->Ln(4);
        $pdf->write1DBarcode($hasiltes['nisn'], 'C39', '', '', '', 18, 0.4, $style, 'N');
        
        $pdf->Output($hasiltes['nisn'].'.pdf', 'I');
	}
	
	//=================================KHATAMAN=============================
	public function tambahsiswa()
	{
	    $data['nama']=$this->input->post('nama');
	    $data['kelas']=$this->input->post('kelas');
	    $data['absen']=$this->input->post('absen');
	    $this->fapplicant->tambahsiswa($data);
	}
	public function aksikhataman()
	{
	    $aksi=$this->input->get('aksi');
	    $id=$this->input->get('id');
	    echo $this->fapplicant->aksikhataman($aksi,$id);
	}
	
	
	//==========================MATSAMA=====================================
	

	public function matsama_login($m)
	{
	    $materi=array(
	        ''=>null,
            '1'=>'Sambutan Kepala MA NU TBS Kudus',
            '2'=>'Profil MA NU TBS Kudus',
            '3'=>'Kesiswaan dan Ekstra Kurikuler MA NU TBS Kudus',
            '4'=>'Do`a Awal dan Akhir Pembelajaran MA NU TBS Kudus',
            '5'=>'Tata tertib MA NU TBS Kudus',
            '6'=>'Lembaga Pengembangan Bakat MA NU TBS Kudus',
            '7'=>'Seputar Persatuan Pelajar MA NU TBS Kudus',
            '8'=>'Ke-Aswajaan',
            '9'=>'Kurikulum MA NU TBS Kudus'
        );
	    $data['nisn']=$this->session->userdata('username');
	    $data['var']=$materi[$m];
	    $data['catatan']='sudah login';
	    $data['date']=date('Y-m-d H:i:s');
	    
        $this->fapplicant->matsama_login($data);
	}
	public function matsama_jawab()
	{
	    $data['nisn']=$this->session->userdata('username');
	    $data['var']=$this->input->post('materi');
	    $data['val']=$this->input->post('jawaban');
	    $data['date']=date('Y-m-d H:i:s');
	    $data['catatan']=$this->input->post('persen');
        $this->fapplicant->matsama_jawab($data);
	}
	
	
	//==========================PENJURUSAN=====================================
	public function cekdatalengkap()
	{
	    $data['nisn']=$this->session->userdata('username');
	    $data['lengkap']=$this->fapplicant->cekdatalengkap($data);
	    $j=0;
	    $i=0;
	    if($data['lengkap']!=null){
	        foreach($data['lengkap'] as $k=>$a){
	            $j++;
	            if($a!=null) {
	                $i++;
	            }
	        }
	    }
	    return $i.'/'.$j;
	}
	public function simpanjur()
	{
	    $data['pil_jurusan']=$this->input->get('pil_jur');
	    $this->dbrevo->where('nisn',$this->session->userdata('username'))->update('biodata__student',$data);
	}
	public function soal_penjurusan()
	{
	    $mapel=$this->input->get('mapel');
	    echo json_encode($this->fapplicant->pat2020($mapel));
	}
	public function cekmapel()
	{
	    $query=$this->dbrevo->select('mapel,nilai')->from('student__jawaban_ppdb')->where('mapel',$this->input->get('mapel'))->where('nisn',$this->session->userdata('nisn'))->get()->row_array();
	    echo $query['mapel'];
	}
	public function jawabjur()
	{
	    $aksi=$this->input->get('aksi');
	    $data['nisn']=$this->session->userdata('username');
	    if($aksi=='mulai') $data['waktu_mulai']=date('Y-m-d H:i:s');
	    else if($aksi=='selesai') $data['waktu_selesai']=date('Y-m-d H:i:s');
	    $data['mapel']=$this->input->get('mapel');
	    $data['jawaban']=$this->input->get('jawaban');
	    $data['nilai']=$this->input->get('nilai');
	    $data['pelanggaran']=$this->input->get('pelanggaran');
	    $result=$this->fapplicant->jawabjur($data,$aksi);
	    if($result=='selesai') echo 'selesai';
	    else{
	        if((strtotime($result)+(20*60))<=strtotime('now')){
	            echo 'gagal';
	        } else{
	            $j=0;
    	        $w=date('H:i:s',strtotime($result)+(20*60)-strtotime('now'));
    	        $r=null;
    	        $r['m']=substr($w,3,2);
    	        $r['d']=substr($w,6,2);
    	        echo json_encode($r);
	        }
	    }
	}	
	
	
	
	
	
	
	
	
}
