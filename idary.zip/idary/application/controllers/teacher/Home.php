<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
    function __construct(){
        parent::__construct();
        $this->dbrevo = $this->load->database('revo', TRUE);
		/*if($this->session->userdata('user_level')!=1){
		    redirect(base_url());
		}*/
    }
//==============================================================
//                  HALAMAN
//==============================================================
	public function index()
	{
	    $data=array();
	    $this->pakaitemplate('teacher/home',$data);
	}
	public function pakaitemplate($content,$data)
	{
	    $level=$this->session->userdata('user_level');
	    $data['sidemenus']=$this->fungsi->sidemenu($level);
	    $this->load->view('template/header');
	    $this->load->view('template/topmenu');
	    $this->load->view('template/sidemenu',$data);
	    $this->load->view($content,$data);
	    $this->load->view('template/footer');
	}
	public function pakaiblank($content,$data)
	{
	    $data['contents']=$this->load->view($content,$data,TRUE);
	    $this->load->view('blank',$data);
	}
	public function presensi()
	{
	    $data['notif_title']=$this->input->get('id');
	    $data['kelas']=$this->input->get('kelas');
	    $data['presensi']=$this->dbrevo->select('user__notification.*,nisn,kelas,nama_lengkap')->from('user__notification')->where($data)->join('student__biodata','student__biodata.nisn=user__notification.notif_for','left')->get()->result_array();
	    $data['mapel']=$this->dbrevo->select('*')->from('student__mapel')->order_by('date_start DESC, kelas ASC, pelajaran ASC')->get()->result_array();
	    $this->pakaitemplate('teacher/presensi',$data);
	}
	public function nilaipas2020()
	{
	    $data['kode']=$this->input->get('id');
	    $data['student__biodata.kelas']=$this->input->get('kelas');
	    if($data['student__biodata.kelas']==null) unset($data['student__biodata.kelas']);
	    $data['presensi']=$this->dbrevo->select('student__jawaban_tes.nisn,student__biodata.kelas,nama_lengkap,absen,kode,pelajaran,mapel,nilai')->from('student__jawaban_tes')->where($data)->join('student__biodata','student__biodata.nisn=student__jawaban_tes.nisn','left')->join('student__mapel_tes','mapel=kode','left')->get()->result_array();
	    $data['mapel']=$this->dbrevo->select('*')->from('student__mapel_tes')->order_by('date DESC, kelas ASC, pelajaran ASC')->get()->result_array();
	    $data['kelas']=$this->input->get('kelas');
	    $data['soal']=$this->dbrevo->select('count(mapel) as jumlah_soal')->from('student__soal_tes')->where('mapel',$data['kode'])->get()->row_array();
	    $this->pakaitemplate('teacher/nilaipas2020',$data);
	}
	public function rekappas2020()
	{
	    $data['kode']=$this->input->get('id');
	    $data['presensi']=$this->dbrevo->select('count(student__jawaban_tes.nisn) as jumlah, student__biodata.kelas')->from('student__jawaban_tes')->where('mapel',$data['kode'])->join('student__biodata','student__biodata.nisn=student__jawaban_tes.nisn','left')->group_by('kelas')->get()->result_array();
	    $data['siswa']=$this->dbrevo->select('count(nisn) as total,kelas')->from('student__biodata')->where('status','1')->group_by('kelas')->get()->result_array();
	    $data['mapel']=$this->dbrevo->select('*')->from('student__mapel_tes')->order_by('date DESC, kelas ASC, pelajaran ASC')->get()->result_array();
	    $this->pakaitemplate('teacher/rekappas',$data);
	}
	
	
	
	
	
	
	
	
	
	
	
// 	public function listpendaftar()
// 	{
// 	    $data['listpendaftar']=$this->fadmin->listpendaftar();
// 	    $this->pakaitemplate('teacher/listpendaftar',$data);
// 	}
// 	public function pat2020()
// 	{
// 	    $kelas=$this->input->get('kelas');
// 	    $mapel=$this->input->get('mapel');
// 	    $data['absen']=null;
// 	    if($kelas!=null && $mapel!=null) $data['absen']=json_encode($this->db->select('student__profilpat2020.nisn,absen,kelas,nama,nilai')->from('student__profilpat2020')->join('student__jawabanpat2020','student__profilpat2020.nisn=student__jawabanpat2020.nisn')->where('kelas',$kelas)->get()->result_array());
// 	    else if($kelas!=null) $data['absen']=json_encode($this->db->select('absen,kelas,nama')->from('student__profilpat2020')->where('kelas',$kelas)->get()->result_array());
// 	    $this->pakaiblank('teacher/pat2020',$data);
// 	}
// 	public function hasilpat2020()
// 	{
// 	    $data['listmapel']=$this->db->select('*')->from('student__mapelpat2020')->order_by('kelas')->order_by('pelajaran')->get()->result_array();
// 	    $data['mapel']=$this->input->get('mapel');
// 	    $data['kelas']=$this->input->get('kelas');
// 	    $data['nilai']=json_encode($this->db->select('nama,kelas,absen,mapel,jawaban,nilai')->from('student__profilpat2020')->where('mapel',$data['mapel'])->where('kelas',$data['kelas'])->order_by('absen')->join('student__jawabanpat2020', 'student__profilpat2020.nisn = student__jawabanpat2020.nisn', 'left')->get()->result_array());
// 	   // echo $data['nilai'];
// 		$this->pakaitemplate('teacher/nilai',$data);
// 	}
// 	public function leger()
// 	{
// 	    $data['kelas']=$this->input->get('kelas');
//         if($data['kelas']==null) $data['kelas']="X C";
//         $kel=substr($data['kelas'],0,2);
// 	    $data['listmapel']=$this->db->select('kode,pelajaran,kelas, COUNT(mapel) AS jum')->from('student__mapelpat2020')->order_by('pelajaran')->like('kelas',$kel)->join('student__soal_ppdb', 'student__mapelpat2020.kode = student__soal_ppdb.mapel', 'inner')->group_by('mapel')->get()->result_array();
// 	    $mentah=$this->db->select('nama,kelas,absen,mapel,jawaban,nilai')->from('student__profilpat2020')->where('kelas',$data['kelas'])->order_by('absen')->join('student__jawabanpat2020', 'student__profilpat2020.nisn = student__jawabanpat2020.nisn', 'left')->get()->result_array();
// 	    foreach($mentah as $m){
// 	        $mateng[$m['nama']]['absen']=$m['absen'];
// 	        $mateng[$m['nama']]['kelas']=$m['kelas'];
// 	        $mateng[$m['nama']]['nama']=$m['nama'];
// 	        $mateng[$m['nama']][$m['mapel']]=$m['nilai'];
// 	    }
// 	    $data['nilai']=json_encode($mateng);
// 		$this->pakaitemplate('teacher/leger',$data);
// 	}
}
