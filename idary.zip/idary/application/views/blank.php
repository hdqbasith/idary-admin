<!DOCTYPE html>
<html lang="en">
    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Idary Admin, Pusat Data MA NU TBS Kudus yang dikembangkan oleh HDQBasith Studio">
        <meta name="author" content="Hadziqi Basith">

        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo base_url();?>assets/images/favicon.ico">
        <!-- App title -->
        <title>Idary Admin</title>

        <!-- App css -->
        <link href="<?php echo base_url()?>assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assets/css/icons.css" rel="stylesheet" type="text/css" />
        <!--<link href="<?php echo base_url();?>assets/css/pages.css" rel="stylesheet" type="text/css" />-->
        <!--<link href="<?php echo base_url();?>assets/css/menu.css" rel="stylesheet" type="text/css" />-->
        <!--<link href="<?php echo base_url();?>assets/css/responsive.css" rel="stylesheet" type="text/css" />-->

        <!-- HTML5 Shiv and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->

        <!--<script src="<?php echo base_url();?>assets/js/modernizr.min.js"></script>-->
        <script src="<?php echo base_url()?>assets/js/jquery.min.js"></script>
        <script src="<?php echo base_url()?>assets/js/bootstrap.min.js"></script>

    </head>


    <body style="padding-bottom:0px">




        <div class="wrapper">
            <div class="container">

                        <?php 
                        echo $contents;
                        ?>


                <!-- Footer -->
                <footer class="footer text-center" style="position:unset">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12 text-center">
                                © 2019 Admin Baru
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- End Footer -->

            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->


        <!-- jQuery  -->
        <!--<script src="<?php echo base_url();?>assets/js/detect.js"></script>-->
        <!--<script src="<?php echo base_url();?>assets/js/fastclick.js"></script>-->
        <!--<script src="<?php echo base_url();?>assets/js/jquery.blockUI.js"></script>-->
        <!--<script src="<?php echo base_url();?>assets/js/waves.js"></script>-->
        <!--<script src="<?php echo base_url();?>assets/js/jquery.slimscroll.js"></script>-->
        <!--<script src="<?php echo base_url();?>assets/js/jquery.scrollTo.min.js"></script>-->
        <!--<script src="<?php echo base_url();?>assets/plugins/switchery/switchery.min.js"></script>-->
        <!--<script src="<?php echo base_url();?>assets/js/jquery.core.js"></script>-->
        <!--<script src="<?php echo base_url();?>assets/js/jquery.app.js"></script>-->

    </body>
</html>