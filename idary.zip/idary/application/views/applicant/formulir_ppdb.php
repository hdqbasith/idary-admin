<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$a['namasiswa']='Nama Lengkap'; $a['nama_arab']='Nama (arab)'; $a['nisn']='NISN'; $a['nik']='NIK'; $a['ttlsiswa']='Tempat Lahir'; $a['tglsiswa']='Tanggal Lahir'; $a['almlengkap']='Alamat Rumah'; $a['hpsiswa']='No. HP'; $a['emailsiswa']='Email'; $a['m_citacita_id']='Cita-Cita'; $a['m_hobi_id']='Hobi'; $a['jrssiswa']='Pilihan Jurusan 1'; $a['jrssiswa2']='Pilihan Jurusan 2'; $a['jrssiswa3']='Pilihan Jurusan 3'; $a['jrssiswa4']='Pilihan Jurusan 4'; 
$op['jurusan']=array(
    ''=>'','1'=>'IPA', '2'=>'IPS', '3'=>'Bahasa', '4'=>'Keagamaan'
);
$op['daritbs']=array('1'=>'Ya, dari TBS','0'=>'Tidak, dari sekolah lain');
$fl = array(
    'class'=> 'col-sm-4 control-label'
);
$fc =array(
    'class'=> 'form-control',
    // 'required'=>'',
    'type'=>'text',
    'autocomple'=>'off'
);
$fd = array(
    'class'=> 'datepicker form-control',
    'placeholder' => 'dd-mm-yyyy',
    'autocomplete' => 'off',
    // 'required' => ''
);
$op['kelasmts']=array(
    '.'=>'.','MPA'=>'MPA','IX A'=>'IX A', 'IX B'=>'IX B', 'IX C'=>'IX C', 'IX D'=>'IX D', 'IX E'=>'IX E', 'IX F'=>'IX F', 'IX G'=>'IX G', 'IX H'=>'IX H', 'IX I'=>'IX I', 'IX J'=>'IX J', 'IX K'=>'IX K', 'IX L'=>'IX L', 'IX M'=>'IX M', 'IX N'=>'IX N', 'IX O'=>'IX O', 'LAMA'=>'Kelas X (Tidak Naik)'
);
echo form_button('back','Kembali','btn btn-rounded btn-danger waves-effect waves-light btn-lg')
.heading('Gunakanlah huruf Kapital di "Setiap Awal Kata", "JANGAN SEMUA HURUF"',3,'');

echo form_open(base_url('cekjs'),'name="formedit" id="formedit" class="form-horizontal" style="background:white"')
	.dvo('panel panel-color panel-teal')
		.dvo('panel-heading')
			.heading('Biodata Calon Siswa Baru', 4, 'class="panel-title"')
		.dvc()

		.dvo('panel-body')
			.dvo('row')
    			.dvo('col-md-6','','border-right: 2px solid lightgrey')
    				.dvo('form-group')
    					.form_label('NISN', 'nisn', $fl)
    					.dvo('col-sm-8')
    						.form_input('nisn', '', $fc)
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Nama Lengkap', 'namasiswa', $fl)
    					.dvo('col-sm-8')
    						.form_input('namasiswa', '', $fc)
    					.dvc()
    				.dvc() 
    				.dvo('form-group')
    					.form_label('NIK', 'nik', $fl)
    					.dvo('col-sm-8')
    						.form_input('nik', '', $fc)
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Tempat Lahir', 'ttlsiswa', $fl)
    					.dvo('col-sm-8')
    						.form_input('ttlsiswa', '', $fc)
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Tanggal Lahir', 'tglsiswa', $fl)
    					.dvo('col-sm-8')
    						.form_input('tglsiswa', '', $fd)
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Alamat Rumah', 'almlengkap', $fl)
    					.dvo('col-sm-8')
    						.form_input('almlengkap', '', $fc)
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('No. HP', 'hpsiswa', $fl)
    					.dvo('col-sm-8')
    						.form_input('hpsiswa', '', $fc)
    					.dvc()
    				.dvc()
    			.dvc()
    			.dvo('col-md-6','','border-right: 2px solid lightgrey')
    				.dvo('form-group')
    					.form_label('Email', 'emailsiswa', $fl)
    					.dvo('col-sm-8')
    						.form_input('emailsiswa', '', $fc)
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Pilihan Jurusan 1', 'jrssiswa', $fl)
    					.dvo('col-sm-8')
        					.form_dropdown('jrssiswa', $op['jurusan'])
    					.dvc()
    				.dvc() 
    				.dvo('form-group')
    					.form_label('Pilihan Jurusan 2', 'jrssiswa2', $fl)
    					.dvo('col-sm-8')
        					.form_dropdown('jrssiswa2', $op['jurusan'])
    					.dvc()
    				.dvc() 
    				.dvo('form-group')
    					.form_label('Pilihan Jurusan 3', 'jrssiswa3', $fl)
    					.dvo('col-sm-8')
        					.form_dropdown('jrssiswa3', $op['jurusan'])
    					.dvc()
    				.dvc() 
    				.dvo('form-group')
    					.form_label('Pilihan Jurusan 4', 'jrssiswa4', $fl)
    					.dvo('col-sm-8')
        					.form_dropdown('jrssiswa4', $op['jurusan'])
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Dari MTs/MPA TBS?', 'daritbs', $fl)
    					.dvo('col-sm-8')
        					.form_dropdown('daritbs', $op['daritbs'])
    					.dvc()
    				.dvc()
    				.dvo('form-group d-block')
    					.form_label('Kelas Asal', 'kelasmts', $fl)
    					.dvo('col-sm-8')
        					.form_dropdown('kelasmts', $op['kelasmts'])
    					.dvc()
    				.dvc()
    				.dvo('form-group d-none')
    					.form_label('Asal Sekolah', 'aslsb', $fl)
    					.dvo('col-sm-8')
    						.form_input('aslsb', 'MTs/MPA NU TBS', $fc)
    					.dvc()
    				.dvc()
    			.dvc()
			.dvc()
		.dvc()
	.dvc()
	.po('Pastikan Anda sudah yakin dengan pilihan prioritas jurusan Anda. Anda tidak bisa mengubah pilihan prioritas jurusan Anda. Bacalah <a href="http://ma.madrasahtbs.sch.id/mengenal-jurusan-di-ma-nu-tbs-kudus/">Artikel ini</a> sebelum memutuskan.')
	.pc()
	.form_button('simpan','Simpan','btn btn-rounded btn-teal waves-effect waves-light btn-lg btn-block')
.form_close()


?>
<link href="<?php echo base_url()?>assets/plugins/datepicker/bootstrap-datepicker.min.css" rel="stylesheet">
<link href="<?php echo base_url()?>assets/plugins/bootstrap-sweetalert/sweet-alert.css" rel="stylesheet" type="text/css">

<script src="<?php echo base_url()?>assets/plugins/bootstrap-sweetalert/sweet-alert.min.js"></script>
<script src="<?php echo base_url()?>assets/plugins/datepicker/bootstrap-datepicker.min.js"></script>
<script>
    jQuery.extend(jQuery.expr[':'], {
        focusable: function (el, index, selector) {
            return $(el).is('a, button, :input, [tabindex]');
        }
    })
    $(document).on('keypress', 'input,select', function (e) {
        if (e.which == 13) {
            e.preventDefault();
            var $canfocus = $(':focusable');
            var index = $canfocus.index(this) + 1;
            if (index >= $canfocus.length) index = 0;
            $canfocus.eq(index).focus();
        }
    })
    $(document).ready(function(){
        if($("#nisn").val()=="NISN") $('input').val("");
        $("#nisn").val("<?php echo $nisn ?>");
        $("#nama_lengkap").focus();
        $(".page-title").text("Formulir PPDB 2020");
        $("select").attr("required",1);
        $("#aslsb, #kelasmts").attr("required",0);
        $("#nisn").attr("readonly",1);
        $('#daritbs').val('1');
        $(".d-none").hide();
        $(".d-block").show();
    })
    $('.datepicker').datepicker({
    	format: "dd-mm-yyyy",
    	defaultViewDate: {year:2000, month:0, day:1},
    	startView: 2,
    	autoclose: 'true',
    })
    $("form").on("submit",function(e){
        e.preventDefault();
        swal({
        	title:"Menyimpan...", 
        	text:"Mohon tunggu sebentar. Jika halaman tidak dialihkan silakan klik simpan sekali lagi.",
        	type:"success",
        	timer: 10000,
        	showConfirmButton:false,
    	})
        $('#tglsiswa').val($('#tglsiswa').val().split("-").reverse().join("-"));
        var values=$('#formedit').serialize();
        $.post("<?php  echo base_url('applicant/simpanppdb'); ?>",values,function(data){
            if(data=="sukses"){
                swal.close();
                location.href="suksesdaftar";
            }
            else {
                swal({
                	title:"Ups...", 
                	text:"Sepertinya NISN tersebut sudah terdaftar. Pastikan NISN Anda sudah benar. Jika masih tidak bisa silakan hubungi admin",
                	type:"warning",
                	timer: 10000
            	})
            }
        })
    })
    
    $('#daritbs').on('change',function(){
        $(".d-none,.d-block").toggle();
    })
    $('#jrssiswa').on('change',function(){
        $('#jrssiswa2,#jrssiswa3,#jrssiswa4').prop('selectedIndex',0);
        $('#jrssiswa2 option,#jrssiswa3 option,#jrssiswa4 option').show();
        $('#jrssiswa2 option[value="'+$(this).val()+'"]').hide();
        $('#jrssiswa3 option[value="'+$(this).val()+'"]').hide();
        $('#jrssiswa4 option[value="'+$(this).val()+'"]').hide();
    })
    $('#jrssiswa2').on('change',function(){
        $('#jrssiswa3,#jrssiswa4').prop('selectedIndex',0);
        $('#jrssiswa3 option,#jrssiswa4 option').show();
        $('#jrssiswa3 option[value="'+$('#jrssiswa').val()+'"]').hide();
        $('#jrssiswa3 option[value="'+$(this).val()+'"]').hide();
        $('#jrssiswa4 option[value="'+$(this).val()+'"]').hide();
    })
    $('#jrssiswa3').on('change',function(){
        $('#jrssiswa4').prop('selectedIndex',0);
        $('#jrssiswa4 option').show();
        $('#jrssiswa4 option[value="'+$('#jrssiswa').val()+'"]').hide();
        $('#jrssiswa4 option[value="'+$('#jrssiswa2').val()+'"]').hide();
        $('#jrssiswa4 option[value="'+$(this).val()+'"]').hide();
    })
    $("#back").click(function(){
        window.history.go(-1);
    })
    
    history.pushState(null, null, location.href);
    window.onpopstate = function () {
        swal({
        	title:"Konfirmasi", 
        	text:"Ingin meninggalkan halaman?",
        	type:"warning",
        	showCancelButton:true,
            confirmButtonText: "Ya",
            cancelButtonText: "Tidak",
    	}, function(a){
    	    if(a) history.go(-1);
    	    else history.pushState(null, null, location.href);
    	})
    };
</script>