<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$nisn=$this->session->userdata['username'];
$nama= $this->session->userdata('user_fullname');
$fl = array(
    'class'=> 'col-sm-4 control-label'
);
$fc =array(
    'class'=> 'form-control',
    'required'=>'required',
    'type'=>'text',
    'autocomple'=>'off'
);
$fp =array(
    'class'=> 'form-control',
    'required'=>'required',
    'type'=>'password',
    'autocomple'=>'off'
);
$op['kelas']=array(
     'MPA 1'=>'MPA 1', 'MPA 2'=>'MPA 2', 'X A'=>'X A', 'X B'=>'X B', 'X C'=>'X C', 'X D'=>'X D', 'X E'=>'X E', 'X F'=>'X F', 'X E'=>'X E', 'X F'=>'X F', 'X G'=>'X G', 'X H'=>'X H', 'X I'=>'X I', 'X J'=>'X J', 'X K'=>'X K', 'X L'=>'X L', 'X M'=>'X M', 'X N'=>'X N', 'XI A'=>'XI A', 'XI B'=>'XI B', 'XI C'=>'XI C', 'XI D'=>'XI D', 'XI E'=>'XI E', 'XI F'=>'XI F', 'XI G'=>'XI G', 'XI H'=>'XI H', 'XI I'=>'XI I', 'XI J'=>'XI J', 'XI K'=>'XI K', 'XI L'=>'XI L', 'XI M'=>'XI M'
    );
?>
<div id="d1" style="display:none;">
    <div class="col-lg-12">
        <div class="portlet">
            <div class="portlet-heading bg-danger">
                <h3 class="portlet-title">
                    MOHON KEIKHLASANNYA UNTUK MEMBACA
                </h3>
                <div class="portlet-widgets">
                    <a data-toggle="collapse" href="#bd1" class="collapsed" aria-expanded="false"><i class="ion-minus-round"></i></a>
                </div>
                <div class="clearfix"></div>
            </div>
            <div id="bd1" class="panel-collapse collapse">
                <div class="portlet-body">
                    <h4>Sebelumnya kami mohon maaf jika beberapa hari ini kami galak dan keras</h4>
                    <ul><h5>Mengapa kami begitu galak?</h5>
                        <li>Dalam pemrograman, kesalahan tidak bisa ditolerir. Anda sudah mengalami sendiri bahwa pengetikan "password" dengan huruf kapital berbeda dengan huruf kecil</li>
                        <li>Gara-gara kurang satu huruf saja dalam pemrograman maka program bisa tidak berjalan secara keseluruhan</li>
                        <li>Jumlah siswa MA NU TBS yang mengikuti PAT sekitar 1.000 orang. Lebih mudah 1.000 orang memahami satu aplikasi daripada satu aplikasi memahami 1.000 orang</li>
                    </ul>
                    <ul><h5>Pak, aplikasinya kok ada yang salah, bagaimana?</h5>
                        <li>Tidak usah panik, jangan terburu-buru menghubungi Panitia atau Bapak-Bapak Guru</li>
                        <li>Tunggulah satu/dua jam. Panitia pun melakukan kesalahan, dan untuk memperbaikinya butuh waktu. Jadi, jangan menuntut Panitia segera menyelesaikan masalah Anda</li>
                        <li>Ketika Anda menghubungi Panitia, artinya semakin lama kesalahan diperbaiki</li>
                    </ul>
                    <ul><h5>Pak, nilai saya kok NOL? Waktunya kok sudah habis? Saya tidak sengaja melakukan kesalahan?</h5>
                        <li>Sekali lagi, jangan panik. Tunggu satu/dua jam.</li>
                        <li>Kalau kesalahan dari Panitia, Anda pasti akan mendapat informasi</li>
                        <li><ol>Kalau kesalahan dari Anda, ingatlah bahwa kemungkinannya adalah:
                                <li>Anda tidak mengindahkan peraturan dari Panitia</li>
                                <li>Anda sudah pernah mengeklik "mulai" tapi Anda tidak langsung mengerjakan soal. Jadi, waktu habis/tinggal sedikit ketika Anda login kembali</li>
                                <li>Koneksi internet Anda buruk sehingga ketika kirim jawaban tidak terjadi apa-apa</li>
                                <li>Browser yang Anda gunakan tidak kompatibel</li>
                            </ol>
                        </li>
                    </ul>
                    <ul><h5>Apa yang perlu Anda lakukan ketika melakukan kesalahan?</h5>
                        <li>JANGAN BURU-BURU MENGHUBUNGI PANITIA</li>
                        <li>Baca dulu peraturan yang ada, barangkali ada yang Anda lewatkan</li>
                        <li>Baca kembali informasi yang ada di grup WA</li>
                        <li>Diskusikan dulu dengan teman Anda, barangkali ada yang mengalami hal yang sama</li>
                        <li>BUATLAH PERWAKILAN KELAS UNTUK MENGAJUKAN MASALAH KE PANITIA. JANGAN MENGAJUKAN SENDIRI-SENDIRI</li>
                    </ul>
                    <ul><h5>Kalau mau mengajukan remedi bagaimana Pak caranya?</h5>
                        <li>Pastikan dulu bahwa pada jam 12.00 nilai Anda "null" atau terlalu rendah</li>
                        <li><ul>Buatlah surat permohonan maaf kepada Panitia dengan menyertakan:
                                <li>Biodata (Nama, kelas, NISN)</li>
                                <li>Kronologi kejadian yang menyebabkan Anda mengajukan remedi</li>
                                <li>Tanda tangan orang tua</li>
                            </ul>
                        </li>
                        <li>Kirimkan foto surat Anda ke call center. Tunggulah balasan dari Panitia dengan sabar</li>
                    </ul>
                    <ol><h5>Demi kebaikan bersama, sebaiknya Anda tidak melakukan hal-hal berikut:</h5>
                        <li>Mengajukan masalah selain kepada call center, termasuk wali kelas</li>
                        <li>Mengambil gambar/menscreenshoot soal</li>
                        <li>Membuka tab baru/aplikasi lain</li>
                        <li>Mengerjakan soal tidak sesuai jadwal</li>
                        <li>Melanggar peraturan lain dari Panitia</li>
                        <li>Mengapa? Sekali lagi pemrograman tidak menolerir kesalahan. Satu orang berbuat kesalahan, seluruh sistem bisa rusak</li>
                    </ol>
                    <h3>Terima kasih karena telah menyempatkan waktu Anda untuk membaca tulisan ini. Semoga dengan mengikuti peraturan ini, Anda mendapatkan ilmu yang barokah dan bermanfaat. Amin...</h3>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="d2" style="display:none;">
    <div class="col-lg-12">
        <div class="portlet">
            <div class="portlet-heading bg-danger">
                <h3 class="portlet-title">
                    SELAMAT DATANG, <?php echo $nama; ?>!
                </h3>
                <div class="portlet-widgets">
                    <a data-toggle="collapse" href="#bd2" class="collapsed" aria-expanded="false"><i class="ion-minus-round"></i></a>
                </div>
                <div class="clearfix"></div>
            </div>
            <div id="bd2" class="panel-collapse collapse">
                <div class="portlet-body">
                    <h5>Berhubung Panitia baik hati dan tidak sombong serta rajin menabung, maka:</h5>
                    <ul>
                        <li><b>BUDAYAKAN BACA DENGAN TELITI SAMPAI AKHIR, JANGAN BUDAYAKAN TANYA!</b></li>
                        <li>Hari ini masih bisa update profil kalian di bawah ini.</li>
                        <li>Pastikan password huruf kecil semua, jangan ada lagi anak MA tidak tahu Kapital</li>
                        <li>Kalian lupa password = GAME OVER. TIDAK ADA AMPUN!!!</li>
                        <li>Setiap update profil, semua kolom wajib diisi, termasuk password!</li>
                        <li>Selesai update profil akan otomatis logout</li>
                        <li>Pastikan profil kalian sudah benar sebelum mengerjakan tes</li>
                        <li>Soal ada di bawah</li>
                        <LI>BAGI YANG HARI SENIN NILAINYA NOL/JELEK KARENA MASALAH TEKNIS, SILAKAN HUBUNGI CALL CENTER DENGAN MENYERTAKAN NISN DAN KRONOLOGI KEJADIAN. HER AKAN DIBERIKAN DI AKHIR PAT</LI>
                    </ul>
                    <?php
                    echo form_open(base_url('cekjs'),'name="formedit" id="formedit" class="form-horizontal" style="background:white"')
                        .dvo('form-group')
        					.form_label('NISN', 'nisn', $fl)
        					.dvo('col-sm-8')
        						.form_input('nisn',$nisn, $fc)
        					.dvc()
        				.dvc() 
                        .dvo('form-group')
        					.form_label('Nama Lengkap', 'nama', $fl)
        					.dvo('col-sm-8')
        						.form_input('nama', $nama, $fc)
        					.dvc()
        				.dvc() 
        				.dvo('form-group')
        					.form_label('Kelas', 'kelas', $fl)
        					.dvo('col-sm-8')
            					.form_dropdown('kelas', $op['kelas'],$profil['kelas'])
        					.dvc()
        				.dvc()
                        .dvo('form-group')
        					.form_label('Nomor Absen', 'absen', $fl)
        					.dvo('col-sm-8')
        						.form_input('absen', $profil['absen'], $fc)
        					.dvc()
        				.dvc() 
                        .dvo('form-group')
        					.form_label('Password Baru', 'password', $fl)
        					.dvo('col-sm-8')
        						.form_input('password', '', $fp)
        					.dvc()
        				.dvc() 
                        .dvo('form-group')
        					.form_label('Ulangi Password Baru', 'password2', $fl)
        					.dvo('col-sm-8')
        						.form_input('password2', '', $fp)
        					.dvc()
        				.dvc() 
        				.heading('Jangan sampai lupa password baru Anda!!!','4','class="text-danger text-center"')
                    	.form_button('simpan','Simpan','btn btn-rounded btn-teal waves-effect waves-light btn-lg btn-block')
                    .form_close();
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="h0" style="display:none;">
    <div class="col-lg-12">
        <div class="portlet">
            <div class="portlet-heading bg-warning">
                <h3 class="portlet-title">
                    NILAI
                </h3>
                <div class="portlet-widgets">
                    <a data-toggle="collapse" href="#bh0" class="collapsed" aria-expanded="false"><i class="ion-minus-round"></i></a>
                </div>
                <div class="clearfix"></div>
            </div>
            <div id="bh0" class="panel-collapse collapse">
                <div class="portlet-body col-md-12">
                    <h4>Jangan salahkan panitia kalau nilai Anda NOL karena tidak mengisi profil dengan benar!
                    <br/>BAGI YANG HARI INI NILAINYA NOL/JELEK KARENA MASALAH TEKNIS, SILAKAN HUBUNGI CALL CENTER DENGAN MENYERTAKAN "NISN DAN KRONOLOGI KEJADIAN". HER AKAN DIBERIKAN DI AKHIR PAT. INGAT, JANGAN BANYAK TANYA!!!
                    </h4>
                    <table class="table table-colored table-brown table-bordered" width="100%">
                        <thead>
                            <tr>
                                <th>Kelas</th>
                                <th>No. Absen</th>
                                <th>Nama</th>
                                <th>Mapel</th>
                                <th>Nilai</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                        </tbody>
                    </table>
                    <h5>*Nilai = jawaban benar</h5>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="h1" style="display:none;">
    <div class="col-lg-12">
        <div class="portlet">
            <div class="portlet-heading bg-primary">
                <h3 class="portlet-title">
                    SENIN, 1 JUNI 2020
                </h3>
                <div class="portlet-widgets">
                    <a data-toggle="collapse" href="#bh1" class="collapsed" aria-expanded="false"><i class="ion-minus-round"></i></a>
                </div>
                <div class="clearfix"></div>
            </div>
            <div id="bh1" class="panel-collapse collapse">
                <div class="portlet-body">
                    <h4>
                        <p>BAGI YANG HARI SENIN NILAINYA NOL/JELEK KARENA MASALAH TEKNIS, SILAKAN HUBUNGI CALL CENTER DENGAN MENYERTAKAN "NISN DAN KRONOLOGI KEJADIAN". HER AKAN DIBERIKAN DI AKHIR PAT. INGAT, JANGAN BANYAK TANYA!!!</p>
                        <p>JANGAN MENGERJAKAN SOAL DI LUAR HARI DAN JAM YANG DITENTUKAN KARENA TIDAK MASUK REKAPAN. HUBUNGI CALL CENTER JIKA INGIN MENGERJAKAN SOAL DI HARI YANG TIDAK SESUAI</p>
                    </h4>
                    <h4>kelas MPA</h4>
                    <a class="btn btn-danger btn-lg" href="<?php echo base_url('student/pat2020?mapel=FiqMPA'); ?>">Fiqih</a>
                    <a class="btn btn-orange btn-lg" href="<?php echo base_url('student/pat2020?mapel=MhdsMPA'); ?>">Muhadatsah</a>
                    <h4>kelas X</h4>
                    <a class="btn btn-danger btn-lg" href="<?php echo base_url('student/pat2020?mapel=Fiqih2X'); ?>">Fiqih 2</a>
                    <a class="btn btn-orange btn-lg" href="<?php echo base_url('student/pat2020?mapel=AAkhlaqX'); ?>">Akidah Akhlak</a>
                    <a class="btn btn-teal btn-lg" href="<?php echo base_url('student/pat2020?mapel=mtqX'); ?>">Ilmu Manthiq</a>
                    <h4>kelas XI</h4>
                    <a class="btn btn-danger btn-lg" href="<?php echo base_url('student/pat2020?mapel=Fiq2XI'); ?>">Fiqih 2</a>
                    <a class="btn btn-orange btn-lg" href="<?php echo base_url('student/pat2020?mapel=Aakhlaq_XI'); ?>">Akidah Akhlak</a>
                    <a class="btn btn-teal btn-lg" href="<?php echo base_url('student/pat2020?mapel=MantiqXI'); ?>">Ilmu Manthiq</a>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="h2" style="display:none;">
    <div class="col-lg-12">
        <div class="portlet">
            <div class="portlet-heading bg-primary">
                <h3 class="portlet-title">
                    SELASA, 2 JUNI 2020
                </h3>
                <div class="portlet-widgets">
                    <a data-toggle="collapse" href="#bh2" class="collapsed" aria-expanded="false"><i class="ion-minus-round"></i></a>
                </div>
                <div class="clearfix"></div>
            </div>
            <div id="bh2" class="panel-collapse collapse">
                <div class="portlet-body">
                    <h4>BUDAYAKAN BACA PERATURAN, JANGAN NANYA TERUS!!!
                        <br/>BACA DULU SEMUA INFO DI HALAMAN INI, JANGAN ASAL NANYA!!!
                    </h4>
                    <?php 
                    $class=substr($profil['kelas'],0,2);
                    if($class=='MP'){
                        echo '<h4>kelas MPA</h4>
                        <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=MatMPA').'">Matematika</a>
                        <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=NhwMPA').'">Nahwu</a>';
                    } elseif($class=='X '){
                        echo '<h4>kelas X</h4>
                        <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=Matwa_X').'">Matematika</a>
                        <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=NahwX').'">Nahwu</a>
                        <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=ski_x').'">SKI</a>';
                    } elseif($class=='XI'){
                        echo '<h4>kelas XI</h4>
                        <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=MatwaXI').'">Matematika</a>
                        <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=NhwXI').'">Nahwu</a>
                        <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=SKI-XI').'">SKI</a>
                        <h4>Matematika kelas XI belum ada kuncinya jadi terlihat nilai NOL</h4>';
                    } else echo '<h4 class="text-danger">NDABLEK!!! KANDANANE ANGEL. PROFILMU UPDATE DISIK!!!</h4><img src="https://cf.shopee.co.id/file/e13b9ea10da7ca16d82ae29e267dfc6a" width="100%">';
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="h3" style="display:none;">
    <div class="col-lg-12">
        <div class="portlet">
            <div class="portlet-heading bg-primary">
                <h3 class="portlet-title">
                    RABU, 3 JUNI 2020
                </h3>
                <div class="portlet-widgets">
                    <a data-toggle="collapse" href="#bh3" class="collapsed" aria-expanded="false"><i class="ion-minus-round"></i></a>
                </div>
                <div class="clearfix"></div>
            </div>
            <div id="bh3" class="panel-collapse collapse">
                <div class="portlet-body">
                    <h4><i>Tidak ada ceritanya menyontek menjadikan ilmu barokah</i></h4>
                    <?php 
                    $class=substr($profil['kelas'],0,2);
                    if($class=='MP'){
                        echo '<h4>kelas MPA</h4>
                        <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=MPAHadis').'">Hadits</a>
                        <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=MPA_Tauhid').'">Tauhid</a>';
                    } elseif($class=='X '){
                        echo '<h4>kelas X</h4>
                        <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=PPKnX').'">PPKn</a>
                        <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=SejInaX').'">Sejarah Indonesia</a>
                        <a class="btn btn-success btn-lg" href="'.base_url('student/pat2020?mapel=AswjXAD').'">Aswaja X A-D</a>
                        <a class="btn btn-teal btn-lg" href="'.base_url('student/pat2020?mapel=AswjXEN').'">Aswaja X E-N</a>';
                    } elseif($class=='XI'){
                        echo '<h4>kelas XI</h4>
                        <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=ppknXI').'">PPKn</a>
                        <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=SejIndoXI').'">Sejarah Indonesia</a>
                        <a class="btn btn-teal btn-lg" href="'.base_url('student/pat2020?mapel=AswaXI').'">Aswaja</a>';
                    } else echo '<h4 class="text-danger">NDABLEK!!! KANDANANE ANGEL. PROFILMU UPDATE DISIK!!!</h4><img src="https://cf.shopee.co.id/file/e13b9ea10da7ca16d82ae29e267dfc6a" width="100%">';
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="h4" style="display:none;">
    <div class="col-lg-12">
        <div class="portlet">
            <div class="portlet-heading bg-primary">
                <h3 class="portlet-title">
                    KAMIS, 4 JUNI 2020
                </h3>
                <div class="portlet-widgets">
                    <a data-toggle="collapse" href="#bh4" class="collapsed" aria-expanded="false"><i class="ion-minus-round"></i></a>
                </div>
                <div class="clearfix"></div>
            </div>
            <div id="bh4" class="panel-collapse collapse">
                <div class="portlet-body">
                    <h4><i>"Jika engkau mengikutiku, maka jangan bertanya tentang apapun, sampai aku sendiri menerangkannya kepadamu"</i></h4>
                    <?php 
                    if(strtotime('2020/06/10 00:00:01') >= strtotime(date("Y-m-d H:i:s")) || strtotime(date("Y-m-d H:i:s")) >= strtotime('2020/06/10 23:59:59')) {
                        echo '
                        <h4>kelas MPA</h4>
                        <a class="btn btn-danger btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Akhlak</a>
                        <a class="btn btn-orange btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Tafsir</a>
                        <h4>kelas X</h4>
                        <a class="btn btn-danger btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Bahasa Arab</a>
                        <a class="btn btn-orange btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Tafsir</a>
                        <a class="btn btn-teal btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Fiqih 1</a>
                        <h4>kelas XI</h4>
                        <a class="btn btn-danger btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Bahasa Arab</a>
                        <a class="btn btn-orange btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Tafsir</a>
                        <a class="btn btn-teal btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Ilmu Falak</a>';
                    } else{
                        $class=substr($profil['kelas'],0,2);
                        if($class=='MP'){
                            echo '<h4>kelas MPA</h4>
                            <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=MPAAkhlaq').'">Akhlak</a>
                            <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=MPATafsir').'">Tafsir</a>';
                        } elseif($class=='X '){
                            echo '<h4>kelas X</h4>
                            <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=ArabXAC').'">Bahasa Arab A-C</a>
                            <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=ArabXDN').'">Bahasa Arab D-N</a>
                            <a class="btn btn-success btn-lg" href="'.base_url('student/pat2020?mapel=TafsirX').'">Tafsir</a>
                            <a class="btn btn-teal btn-lg" href="'.base_url('student/pat2020?mapel=Fiq1X').'">Fiqih 1</a>';
                        } elseif($class=='XI'){
                            echo '<h4>kelas XI</h4>
                            <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=ArabXI').'">Bahasa Arab</a>
                            <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=TafsirXI').'">Tafsir</a>
                            <a class="btn btn-teal btn-lg" href="'.base_url('student/pat2020?mapel=FalakXI').'">Ilmu Falak</a>';
                        } else echo '<h4 class="text-danger">NDABLEK!!! KANDANANE ANGEL. PROFILMU UPDATE DISIK!!!</h4><img src="https://cf.shopee.co.id/file/e13b9ea10da7ca16d82ae29e267dfc6a" width="100%">';
                    }
                    ?>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<div id="h5" style="display:none;">
    <div class="col-lg-12">
        <div class="portlet">
            <div class="portlet-heading bg-primary">
                <h3 class="portlet-title">
                    JUMU`AH, 5 JUNI 2020
                </h3>
                <div class="portlet-widgets">
                    <a data-toggle="collapse" href="#bh5" class="collapsed" aria-expanded="false"><i class="ion-minus-round"></i></a>
                </div>
                <div class="clearfix"></div>
            </div>
            <div id="bh5" class="panel-collapse collapse">
                <div class="portlet-body">
                    <h4><i>"Sesungguhnya orang-orang sebelum kalian binasa karena banyak bertanya dan berselisih dengan para Nabi"</i></h4>
                    <?php 
                    if(strtotime('2020/06/10 00:00:01') >= strtotime(date("Y-m-d H:i:s")) || strtotime(date("Y-m-d H:i:s")) >= strtotime('2020/06/10 23:59:59')) {
                        echo '
                        <h4>kelas MPA</h4>
                        <a class="btn btn-danger btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Bahsa Inggris</a>
                        <a class="btn btn-orange btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Shorof</a>
                        <h4>kelas X</h4>
                        <a class="btn btn-danger btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Bahasa Inggris</a>
                        <a class="btn btn-orange btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Qiro`atul Kitab</a>
                        <a class="btn btn-teal btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Qiro`ah Sab`ah</a>
                        <h4>kelas XI</h4>
                        <a class="btn btn-danger btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Bahasa Inggris</a>
                        <a class="btn btn-orange btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Qiro`atul Kitab</a>
                        <a class="btn btn-teal btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Qiro`ah Sab`ah</a>';
                    } else{
                        $class=substr($profil['kelas'],0,2);
                        if($class=='MP'){
                            echo '<h4>kelas MPA</h4>
                            <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=EngMPA').'">Bahasa Inggris</a>
                            <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=SrfMPA').'">Shorof</a>';
                        } elseif($class=='X '){
                            echo '<h4>kelas X</h4>
                            <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=EngX').'">Bahasa Inggris</a>
                            <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=QKitabX').'">Qiro`atul Kitab</a>
                            <a class="btn btn-success btn-lg" href="'.base_url('student/pat2020?mapel=Qir7X').'">Qiro`ah Sab`ah</a>';
                        } elseif($class=='XI'){
                            echo '<h4>kelas XI</h4>
                            <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=EngXI').'">Bahasa Inggris</a>
                            <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=QKitabXI').'">Qiro`atul Kitab</a>
                            <a class="btn btn-success btn-lg" href="'.base_url('student/pat2020?mapel=QSabXI').'">Qiro`ah Sab`ah</a>';
                        } else echo '<h4 class="text-danger">NDABLEK!!! KANDANANE ANGEL. PROFILMU UPDATE DISIK!!!</h4><img src="https://cf.shopee.co.id/file/e13b9ea10da7ca16d82ae29e267dfc6a" width="100%">';
                    }
                    ?>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<div id="h6" style="display:none;">
    <div class="col-lg-12">
        <div class="portlet">
            <div class="portlet-heading bg-primary">
                <h3 class="portlet-title">
                    SABTU, 6 JUNI 2020
                </h3>
                <div class="portlet-widgets">
                    <a data-toggle="collapse" href="#bh6" class="collapsed" aria-expanded="false"><i class="ion-minus-round"></i></a>
                </div>
                <div class="clearfix"></div>
            </div>
            <div id="bh6" class="panel-collapse collapse">
                <div class="portlet-body">
                    <h4><i>"Yang hari ini jawabannya terkirim sendiri padahal waktu belum habis, berarti Anda telah melakukan pelanggaran peraturan. Tidak ada komplain!"</i></h4>
                    <?php 
                    if(strtotime('2020/06/10 00:00:01') >= strtotime(date("Y-m-d H:i:s")) || strtotime(date("Y-m-d H:i:s")) >= strtotime('2020/06/10 23:59:59')) {
                        echo '
                        <h4>kelas MPA</h4>
                        <a class="btn btn-danger btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Imla`</a>
                        <a class="btn btn-orange btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Pegon</a>
                        <h4>kelas X</h4>
                        <a class="btn btn-danger btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Ushul Fiqih (selain PK)</a>
                        <a class="btn btn-danger btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Fiqih Ushul Fiqih (PK)</a>
                        <a class="btn btn-orange btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Tauhid</a>
                        <a class="btn btn-teal btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Informatika</a>
                        <h4>kelas XI</h4>
                        <a class="btn btn-danger btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Ushul Fiqih (selain PK)</a>
                        <a class="btn btn-danger btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Fiqih Ushul Fiqih (PK)</a>
                        <a class="btn btn-orange btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Tauhid</a>
                        <a class="btn btn-teal btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Tashawuf</a>';
                    } else{
                        $class=substr($profil['kelas'],0,2);
                        if($class=='MP'){
                            echo '<h4>kelas MPA</h4>
                            <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=MPAImla').'">Imla`</a>
                            <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=MPAPegon').'">Pegon</a>';
                        } elseif($class=='X '){
                            echo '<h4>kelas X</h4>
                            <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=UF-XAD').'">Ushul Fiqih (A-D)</a>
                            <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=UF-XEJ').'">Ushul Fiqih (E-J)</a>
                            <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=FUF-XPK').'">Fiqih Ushul Fiqih (PK)</a>
                            <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=TauhidX').'">Tauhid</a>
                            <a class="btn btn-success btn-lg" href="'.base_url('student/pat2020?mapel=ITX').'">Informatika</a>';
                        } elseif($class=='XI'){
                            echo '<h4>kelas XI</h4>
                            <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=UF-XI').'">Ushul Fiqih (selain PK)</a>
                            <a class="btn btn-brown btn-lg" href="'.base_url('student/pat2020?mapel=FUF_XI').'">Fiqih Ushul Fiqih (PK)</a>
                            <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=TauhidXI').'">Tauhid</a>
                            <a class="btn btn-success btn-lg" href="'.base_url('student/pat2020?mapel=TswfXI').'">Tashawuf</a>
                            <p>Tasawuf belum ada kuncinya</p>';
                        } else echo '<h4 class="text-danger">NDABLEK!!! KANDANANE ANGEL. PROFILMU UPDATE DISIK!!!</h4><img src="https://cf.shopee.co.id/file/e13b9ea10da7ca16d82ae29e267dfc6a" width="100%">';
                    }
                    ?>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<div id="h7" style="display:none;">
    <div class="col-lg-12">
        <div class="portlet">
            <div class="portlet-heading bg-primary">
                <h3 class="portlet-title">
                    AHAD, 7 JUNI 2020
                </h3>
                <div class="portlet-widgets">
                    <a data-toggle="collapse" href="#bh7" class="collapsed" aria-expanded="false"><i class="ion-minus-round"></i></a>
                </div>
                <div class="clearfix"></div>
            </div>
            <div id="bh7" class="panel-collapse collapse">
                <div class="portlet-body">
                    <h4><i>"Pantaskah kita bertemu Rosulullah, sementara kita tidak tahu cara menghormati guru dan ulama yang merupakan ahli waris beliau? "</i></h4>
                    <?php 
                    if(strtotime('2020/06/10 00:00:01') >= strtotime(date("Y-m-d H:i:s")) || strtotime(date("Y-m-d H:i:s")) >= strtotime('2020/06/10 23:59:59')) {
                        echo '
                        <h4>kelas MPA</h4>
                        <a class="btn btn-danger btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Falak</a>
                        <h4>kelas X</h4>
                        <a class="btn btn-danger btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Bahasa Indonesia</a>
                        <a class="btn btn-danger btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Biologi (IPA)</a>
                        <a class="btn btn-danger btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Fisika (IPA)</a>
                        <a class="btn btn-orange btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Ekonomi (IPS)</a>
                        <a class="btn btn-orange btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Sejarah (IPS)</a>
                        <a class="btn btn-teal btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Antropologi (BHS)</a>
                        <a class="btn btn-teal btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Bahasa Jawa (BHS)</a>
                        <a class="btn btn-success btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Hadits Ilmu Hadits</a>
                        <a class="btn btn-success btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Ilmu Akhlaq</a>
                        <h4>kelas XI</h4>
                        <a class="btn btn-danger btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Bahasa Indonesia</a>
                        <a class="btn btn-brown btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Kimia (IPA)</a>
                        <a class="btn btn-brown btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Fisika (IPA)</a>
                        <a class="btn btn-orange btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Ekonomi (IPS)</a>
                        <a class="btn btn-orange btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Sejarah (IPS)</a>
                        <a class="btn btn-teal btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Antropologi (BHS)</a>
                        <a class="btn btn-teal btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">B&S Indonesia (BHS)</a>
                        <a class="btn btn-success btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Hadits Ilmu Hadits</a>
                        <a class="btn btn-success btn-lg" href="#" onclick="alert(\'Mboh kang, sak karepmu. Dikandani gurumu kok angele pol!\');">Qowa`id Fiqih</a>';
                    } else{
                        $class=substr($profil['kelas'],0,2);
                        if($class=='MP'){
                            echo '<h4>kelas MPA</h4>
                            <a class="btn btn-orange btn-lg" href="https://drive.google.com/file/d/1ol070L4r66O5zNMTDD6j-D0HsQvwAWqz/view?usp=sharing">Falak</a>
                            <p>Downloadlah file di atas dan ikuti petunjuknya. Pengumpulan paling lambat hari Ahad, tanggal 07 Juni 2020 M pukul 15.00 WIB ke WA 087839280030</p>';
                        } elseif($class=='X '){
                            echo '<h4>kelas X</h4>
                            <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=BIndoX').'">Bahasa Indonesia</a>
                            <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=BioX').'">Biologi (IPA)</a>
                            <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=FisX').'">Fisika (IPA)</a>
                            <a class="btn btn-teal btn-lg" href="'.base_url('student/pat2020?mapel=EkoX').'">Ekonomi (IPS)</a>
                            <a class="btn btn-teal btn-lg" href="'.base_url('student/pat2020?mapel=SejX').'">Sejarah (IPS)</a>
                            <a class="btn btn-success btn-lg" href="'.base_url('student/pat2020?mapel=AntroX').'">Antropologi (BHS)</a>
                            <a class="btn btn-success btn-lg" href="'.base_url('student/pat2020?mapel=BJawaX').'">Bahasa Jawa (BHS)</a>
                            <a class="btn btn-brown btn-lg" href="'.base_url('student/pat2020?mapel=HIHXPK').'">Hadits Ilmu Hadits (PK)</a>
                            <a class="btn btn-brown btn-lg" href="'.base_url('student/pat2020?mapel=IA-XPK').'">Ilmu Akhlaq (PK)</a>';
                        } elseif($class=='XI'){
                            echo '<h4>kelas XI</h4>
                            <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=IndoXI-IPA').'">Bahasa Indonesia (IPA)</a>
                            <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=Indo_XIDM').'">Bahasa Indonesia (selain IPA)</a>
                            <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=KimXI').'">Kimia (IPA)</a>
                            <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=FisXI').'">Fisika (IPA)</a>
                            <a class="btn btn-teal btn-lg" href="'.base_url('student/pat2020?mapel=EkoXI').'">Ekonomi (IPS)</a>
                            <a class="btn btn-teal btn-lg" href="'.base_url('student/pat2020?mapel=SejXI').'">Sejarah (IPS)</a>
                            <a class="btn btn-success btn-lg" href="'.base_url('student/pat2020?mapel=AntroXI').'">Antropologi (BHS)</a>
                            <a class="btn btn-success btn-lg" href="'.base_url('student/pat2020?mapel=BSIndoXI').'">B&S Indonesia (BHS)</a>
                            <a class="btn btn-brown btn-lg" href="'.base_url('student/pat2020?mapel=HIH_XI').'">Hadits Ilmu Hadits (PK)</a>
                            <a class="btn btn-brown btn-lg" href="'.base_url('student/pat2020?mapel=QaFiXI').'">Qowa`id Fiqih (PK)</a>
                            <p>Tasawuf belum ada kuncinya</p>';
                        } else echo '<h4 class="text-danger">NDABLEK!!! KANDANANE ANGEL. PROFILMU UPDATE DISIK!!!</h4><img src="https://cf.shopee.co.id/file/e13b9ea10da7ca16d82ae29e267dfc6a" width="100%">';
                    }
                    ?>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<div id="h8" style="display:none;">
    <div class="col-lg-12">
        <div class="portlet">
            <div class="portlet-heading bg-primary">
                <h3 class="portlet-title">
                    SENIN, 8 JUNI 2020
                </h3>
                <div class="portlet-widgets">
                    <a data-toggle="collapse" href="#bh8" class="collapsed" aria-expanded="false"><i class="ion-minus-round"></i></a>
                </div>
                <div class="clearfix"></div>
            </div>
            <div id="bh8" class="panel-collapse collapse">
                <div class="portlet-body">
                    <h4><i>"Janji adalah hutang yang wajib dibayar. Pastikan kita sudah membayar hutang-hutang kita agar tidak ditagih di akhirat nanti."</i></h4>
                    <?php 
                    if(strtotime('2020/06/10 00:00:01') >= strtotime(date("Y-m-d H:i:s")) || strtotime(date("Y-m-d H:i:s")) >= strtotime('2020/06/10 23:59:59')) {
                        echo '
                        <h4>kelas MPA</h4>
                        -
                        <h4>kelas X</h4>
                        <p>LIHAT JADWAL<p/>
                        <h4>kelas XI</h4>
                        <p>LIHAT JADWAL. Untuk kelas XI BHS ada tambahan mapel <b>Sastra Arab</b><p/>';
                    } else{
                        $class=substr($profil['kelas'],0,2);
                        if($class=='MP'){
                            echo '<h4>kelas MPA</h4>';
                        } elseif($class=='X '){
                            echo '<h4>kelas X</h4>
                            <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=NU_X').'">Ke-NU-an</a>
                            <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=Blg_X').'">Balaghoh</a>
                            <a class="btn btn-teal btn-lg" href="'.base_url('student/pat2020?mapel=MTKP_X').'">Matematika Peminatan (IPA)</a>
                            <a class="btn btn-success btn-lg" href="'.base_url('student/pat2020?mapel=BSAr_X').'">Bahasa dan Sastra Arab (BHS)</a>
                            <a class="btn btn-brown btn-lg" href="'.base_url('student/pat2020?mapel=GeoX').'">Geografi (IPS)</a>
                            <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=BArabPX').'">Bahasa Arab Peminatan (PK)</a>';
                        } elseif($class=='XI'){
                            echo '<h4>kelas XI</h4>
                            <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=NU_XI').'">Ke-NU-an</a>
                            <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=Blg_XI').'">Balaghoh</a>
                            <a class="btn btn-teal btn-lg" href="'.base_url('student/pat2020?mapel=MTKP_XI').'">Matematika Peminatan (IPA)</a>
                            <a class="btn btn-success btn-lg" href="'.base_url('student/pat2020?mapel=SasIngXI').'">Bahasa dan Sastra Inggris (BHS)</a>
                            <a class="btn btn-success btn-lg" href="'.base_url('student/pat2020?mapel=BSAr_XI').'">Bahasa dan Sastra Arab (BHS)</a>
                            <a class="btn btn-brown btn-lg" href="'.base_url('student/pat2020?mapel=GeoXI').'">Geografi (IPS)</a>
                            <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=Ikal_XI').'">Ilmu Kalam (PK)</a>';
                        } else echo '<h4 class="text-danger">NDABLEK!!! KANDANANE ANGEL. PROFILMU UPDATE DISIK!!!</h4><img src="https://cf.shopee.co.id/file/e13b9ea10da7ca16d82ae29e267dfc6a" width="100%">';
                    }
                    ?>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<div id="h9" style="display:none;">
    <div class="col-lg-12">
        <div class="portlet">
            <div class="portlet-heading bg-primary">
                <h3 class="portlet-title">
                    SELASA, 9 JUNI 2020
                </h3>
                <div class="portlet-widgets">
                    <a data-toggle="collapse" href="#bh9" class="collapsed" aria-expanded="false"><i class="ion-minus-round"></i></a>
                </div>
                <div class="clearfix"></div>
            </div>
            <div id="bh9" class="panel-collapse collapse">
                <div class="portlet-body">
                    <h4><i>"Sesuai instruksi Kepala Madrasah, siswa yang tidak mengikuti PAT dengan lengkap TIDAK BISA NAIK KELAS"</i></h4>
                    <?php 
                    if(strtotime('2020/06/10 00:00:01') >= strtotime(date("Y-m-d H:i:s")) || strtotime(date("Y-m-d H:i:s")) >= strtotime('2020/06/10 23:59:59')) {
                        echo '
                        <h4>kelas MPA</h4>
                        -
                        <h4>kelas X</h4>
                        <p>LIHAT JADWAL<p/>
                        <h4>kelas XI</h4>
                        <p>LIHAT JADWAL. untuk kelas XI ada tambahan mapel <b>Hadits</b><p/>';
                    } else{
                        $class=substr($profil['kelas'],0,2);
                        if($class=='MP'){
                            echo '<h4>kelas MPA</h4>';
                        } elseif($class=='X '){
                            echo '<h4>kelas X</h4>
                            <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=Hds_X').'">Hadits</a>
                            <a class="btn btn-teal btn-lg" href="'.base_url('student/pat2020?mapel=Kim_X').'">Kimia (IPA)</a>
                            <a class="btn btn-success btn-lg" href="'.base_url('student/pat2020?mapel=BSIndo_X').'">B&S Indonesia (BHS)</a>
                            <a class="btn btn-success btn-lg" href="'.base_url('student/pat2020?mapel=BSIng_X').'">B&S Inggris (BHS)</a>
                            <a class="btn btn-brown btn-lg" href="'.base_url('student/pat2020?mapel=Sosio_X').'">Sosiologi (IPS)</a>
                            <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=TIT_X').'">Tafsir Ilmu Tafsir (PK)</a>
                            <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=Ikalam_X').'">Ilmu Kalam (PK)</a>';
                        } elseif($class=='XI'){
                            echo '<h4>kelas XI</h4>
                            <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=QH_XI').'">Al-Qur`an Hadits</a>
                            <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=Hds_XIAE').'">Hadits (A-E)</a>
                            <a class="btn btn-danger btn-lg" href="'.base_url('student/pat2020?mapel=Hds_XIFM').'">Hadits (F-M)</a>
                            <a class="btn btn-teal btn-lg" href="'.base_url('student/pat2020?mapel=Bio_XI').'">Biologi (IPA)</a>
                            <a class="btn btn-success btn-lg" href="'.base_url('student/pat2020?mapel=BJawaXI').'">Bahasa Jawa (BHS)</a>
                            <a class="btn btn-brown btn-lg" href="'.base_url('student/pat2020?mapel=SosioXI').'">Sosiologi (IPS)</a>
                            <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=IAkhlaqXI').'">Ilmu Akhlaq (PK)</a>
                            <a class="btn btn-orange btn-lg" href="'.base_url('student/pat2020?mapel=TIT_XI').'">Tafsir Ilmu Tafsir (PK)</a>';
                        } else echo '<h4 class="text-danger">NDABLEK!!! KANDANANE ANGEL. PROFILMU UPDATE DISIK!!!</h4><img src="https://cf.shopee.co.id/file/e13b9ea10da7ca16d82ae29e267dfc6a" width="100%">';
                    }
                    ?>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<div id="d3" style="display:none;">
    <div class="col-lg-12">
        <div class="portlet">
            <div class="portlet-heading bg-orange">
                <h3 class="portlet-title">
                    REMEDI
                </h3>
                <div class="portlet-widgets">
                    <a data-toggle="collapse" href="#bd3" class="collapsed" aria-expanded="false"><i class="ion-minus-round"></i></a>
                </div>
                <div class="clearfix"></div>
            </div>
            <div id="bd3" class="panel-collapse collapse">
                <div class="portlet-body">
                    <h4>BACALAH SEBELUM MENGAJUKAN REMEDI</h4>
                    <ol>
                        <li>Remedi hanya untuk yang nilainya "null / 0" karena masalah teknis (internet error, sakit, telat info, atau HP ngehang)</li>
                        <li>Yang nilainya jelek tidak usah mengajukan remedi, positif thinking saja</li>
                        <li>Silakan diskusi dulu dengan teman-teman, berapa jumlah mapel yang seharusnya dikerjakan</li>
                        <li>Silakan isi form berikut: <a href="https://bit.ly/RemidiPAT" class="btn btn-lg btn-teal">Form Pengajuan remidi</a></li>
                        <li>JANGAN MENGHUBUNGI PANITIA SETELAH MENGISI FORMULIR. DITUNGGU SAJA!!!</li>
                        <li>Isilah formulir dengan lengkap, jujur, dan tidak dibuat-buat</li>
                        <li>NISN TIDAK BOLEH KELIRU. Aplikasi hanya mengenali NISN, bukan Nama ataupun kelas</li>
                        <li>Sebutkan mapel dan alasan remedi. Contoh: 1. Matematika Wajib = Ketika mengerjakan saya ketiduran, begitu bangun ternyata sudah tidak bisa diakses. Saya mohon agar Bapak Guru memberikan kesampatan remedi</li>
                        <li>Pengisian formulir yang tidak sesuai aturan tidak akan ditanggapi. Silakan melakukan pengisian kembali dengan data yang LENGKAP dan BENAR</li>
                        <li>Pengajuan remedi terakhir hari Rabu, 10 Juni 2020 pukul 12.00 WIB</li>
                        <li>Waktu pelaksanaan remedi hanya hari Rabu, 10 Juni 2020 mulai pukul 00.01 WIB sampai 23.59 WIB</li>
                        <li>Silakan login dan klik mapel remedi yang hendak dikerjakan. Jika tidak bisa diklik, silakan tunggu 1 jam. Jika masih belum bisa, silakan isi ulang formulir dan tunggu 1 jam.</li>
                        <li>Setelah selesai mengerjakan, pastikan nilai sudah terlihat di menu nilai</li>
                        <li>Tidak ada waktu lain mengerjakan remedi. Jika hari Rabu punya 7 mapel remedi dan baru mengerjakan 6, maka yang satu nilainya NOL dan berpotensi TIDAK NAIK KELAS</li>
                        <li>Mapel yang belum dikerjakan bisa dicek <a href="https://masterdata.adminbaru.com/student/leger">di sini</a></li>
                        <li>PANITIA TIDAK MELAYANI SISWA YANG TIDAK MAU MEMBACA DAN MENGIKUTI ATURAN</li>
                        <li>Untuk kasus khusus silakan hubungi Bapak Ali Mahsun, JANGAN HUBUNGI PANITIA LAIN, APALAGI WALI KELAS!!!</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="d4">
    <div class="col-lg-12">
        <div class="portlet">
            <div class="portlet-heading bg-orange">
                <h3 class="portlet-title">
                    TERIMA KASIH
                </h3>
                <div class="clearfix"></div>
            </div>
            <div id="bd4" class="panel-collapse collapse in">
                <div class="portlet-body">
                    <h4>Alhamdulillah, PAT Online 2020 telah selesai. Kami mohon maaf apabila dalam penyelenggaraan PAT ini terdapat banyak kekurangan dan kesalahan.
                    <br/>Aplikasi kami tutup. Bila ada pertanyaan silakan hubungi Bapak Ali Mahsun.
                    <br/>Semoga kita dapat segera kembali bermuwajahah dalam majelis ilmu bersama para siswa di MA NU TBS Kudus yang kita cintai. Amin</h4>
                    <p class="text-right"><br/>Kudus, 11 Juni 2020<br/>Panitia</p>
                </div>
            </div>
        </div>
    </div>
</div>
<link href="<?php echo base_url()?>assets/plugins/bootstrap-sweetalert/sweet-alert.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url()?>assets/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url()?>assets/plugins/datatables/datatables.min.js"></script>
<script src="<?php echo base_url()?>assets/plugins/bootstrap-sweetalert/sweet-alert.min.js"></script>
<script>
    $(document).ready(function(){
        // if("<?php //echo $pass['password'];?>"=="e422c38d9d751a5fad07b8464295562b"){
        //     $("#d2").show();
        // }
        $("#nisn").prop("readonly",true);
    })
    $("#formedit").on("submit",function(e){
        e.preventDefault();
        if($('#password').val()!=$('#password2').val()){
            swal({
            	title:"Upsss...", 
            	text:"Karepmu piye, passworde kok ra podo? Ngejak geger po piye?",
            	type:"warning",
            	timer: 10000
        	});
        	$('#password2').focus();
        } else{
            swal({
            	title:"Menyimpan...", 
            	text:"Mohon tunggu sebentar. Jika halaman tidak dialihkan silakan klik simpan sekali lagi.",
            	type:"success",
            	timer: 10000
        	});
            var values=$('#formedit').serialize();
            $.post("<?php  echo base_url('student/simpan_profilpat'); ?>",values,function(data){
                swal.close();
                window.location.href="<?php echo base_url('logout'); ?>";
            });
        };
    });
    var data=<?php echo $nilai;?>;
    var table='';
    $.each(data,function(index,value){
        table+="<tr><td>"+this.kelas+"</td><td>"+this.absen+"</td><td>"+this.nama+"</td><td>"+this.pelajaran+" - "+this.class+"</td><td>"+this.nilai+"</td></tr>";
    })
    $("tbody").html(table);
    $('table').DataTable({
        responsive:true,
        pageLength: 100,
    });
</script>