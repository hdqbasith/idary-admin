<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$nomor=array('1'=>'01','2'=>'02','3'=>'03','4'=>'04','5'=>'05','6'=>'06','7'=>'07','8'=>'08','9'=>'09','10'=>'10','11'=>'11','12'=>'12','13'=>'13','14'=>'14','15'=>'15','16'=>'16','17'=>'17','18'=>'18','19'=>'19','20'=>'20','21'=>'21','22'=>'22','23'=>'23','24'=>'24','25'=>'25','26'=>'26','27'=>'27','28'=>'28','29'=>'29','30'=>'30','31'=>'31','32'=>'32','33'=>'33','34'=>'34','35'=>'35','36'=>'36','37'=>'37','38'=>'38','39'=>'39','40'=>'40','41'=>'41','42'=>'42','43'=>'43','44'=>'44','45'=>'45','46'=>'46','47'=>'47','48'=>'48','49'=>'49','50'=>'50','51'=>'51','52'=>'52','53'=>'53','54'=>'54','55'=>'55','56'=>'56','57'=>'57','58'=>'58','59'=>'59','60'=>'60','61'=>'61','62'=>'62','63'=>'63','64'=>'64','65'=>'65','66'=>'66','67'=>'67','68'=>'68','69'=>'69','70'=>'70','71'=>'71','72'=>'72','73'=>'73','74'=>'74','75'=>'75','76'=>'76','77'=>'77','78'=>'78','79'=>'79','80'=>'80','81'=>'81','82'=>'82','83'=>'83','84'=>'84','85'=>'85','86'=>'86','87'=>'87','88'=>'88','89'=>'89','90'=>'90','91'=>'91','92'=>'92','93'=>'93','94'=>'94','95'=>'95','96'=>'96','97'=>'97','98'=>'98','99'=>'99','100'=>'100');
shuffle($nomor);
$fl = array(
    'class'=> 'col-sm-4 control-label'
);
$fc =array(
    'class'=> 'form-control',
    'required'=>'',
    'type'=>'text',
    'autocomplete'=>'off'
);
echo dvo('panel panel-color panel-teal','d0')
	.dvo('panel-heading')
		.heading($header['setting_value'], 4, 'class="panel-title" id="judul"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		        .po('','id="isi"')
		        .pc()
		        .'<button class="btn btn-teal" id="terus" style="float: right">Lanjut</button>';
		    echo dvc()
	    .dvc()
    .dvc()
.dvc();
?>
<div id="d2" class="col-lg-9" style="display:none">
    <div class="portlet">
        <div class="portlet-heading portlet-teal">
            <h3 class="portlet-title text-dark" id="nomor">
                Soal nomor
            </h3>
            <div class="portlet-widgets">
                <button class="btn btn-rounded btn-danger" id="pilihsoal">Pilih Soal</button>
                <!--<a data-toggle="collapse" data-parent="#accordion1" href="#soal" class="" aria-expanded="true"><button class="btn btn-inverse"><i class="ion-minus-round"></i></button></a>-->
            </div>
            <div class="clearfix"></div>
        </div>
        <div id="soal" class="panel-collapse collapse in" style="" aria-expanded="true">
            <div class="portlet-body">
                <table style="width:100%">
                    <thead>
                        <tr>
                            <th><span id="pertanyaan" style="text-transform:none;"></span></th>
                        </tr>
                    </thead>
                    <tbody style="margin-top:20px;">
                        <tr>
                            <td id="gambar"></td>
                        </tr>
                        <tr>
                            <td><p id="a" class="btn btn-block btn-rounded" style="text-align:left; margin:5px;white-space: normal;"></p></td>
                        </tr>
                        <tr>
                            <td><p id="b" class="btn btn-block btn-rounded" style="text-align:left; margin:5px;white-space: normal;"></p></td>
                        </tr>
                        <tr>
                            <td><p id="c" class="btn btn-block btn-rounded" style="text-align:left; margin:5px;white-space: normal;"></p></td>
                        </tr>
                        <tr>
                            <td><p id="d" class="btn btn-block btn-rounded" style="text-align:left; margin:5px;white-space: normal;"></p></td>
                        </tr>
                        <tr>
                            <td><p id="e" class="btn btn-block btn-rounded" style="text-align:left; margin:5px;white-space: normal;"></p></td>
                        </tr>
                    </tbody>
                </table>
                <div class="row" style="margin-top:20px;" id="navsoal">
                    <div class="col-xs-4">
                        <button id="kembali" class="btn btn-lg btn-teal btn-rounded" onclick="gantisoal(n-1)">Back</button>
                    </div>
                    <div class="col-xs-4 text-center">
                        <button id="tandai" class="btn btn-lg btn-orange btn-rounded">Tandai</button>
                    </div>
                    <div class="col-xs-4 text-right">
                        <button id="lanjut" class="btn btn-lg btn-teal btn-rounded" onclick="gantisoal(n+1)">Next</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="d3" class="col-lg-3" style="display:none">
    <div class="portlet">
        <div class="portlet-heading portlet-teal">
            <h3 class="portlet-title text-dark">
                Soal
            </h3>
            <div class="portlet-widgets">
                <!--<a data-toggle="collapse" data-parent="#accordion1" href="#listnomor" class="" aria-expanded="true"><button class="btn btn-inverse"><i class="ion-minus-round"></i></button></a>-->
            </div>
            <div class="clearfix"></div>
        </div>
        <div id="listnomor" class="panel-collapse collapse in" style="" aria-expanded="true">
            <div class="portlet-body">
                <div id="listnosoal">
                </div>
                <div style="margin-top:20px;">
                    <button id="kirim" class="btn btn-success btn-block btn-lg btn-rounded">Kirim jawaban</button>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="d4" class="col-lg-12" style="display:none">
    <div class="portlet">
        <div class="portlet-heading portlet-teal">
            <h3 class="portlet-title text-dark">
                Selesai
            </h3>
            <div class="clearfix"></div>
        </div>
        <div class="panel-collapse collapse in" style="" aria-expanded="true">
            <div class="portlet-body">
                <p></p>
            </div>
        </div>
    </div>
</div>
<div id="d5" class="col-lg-3">
    <div class="portlet">
        <div class="portlet-heading portlet-teal">
            <h3 class="portlet-title text-dark">
                Webcam
            </h3>
            <div class="clearfix"></div>
        </div>
        <div class="panel-collapse collapse in" style="" aria-expanded="true">
            <div class="portlet-body">
                <video id="dummy" width="160" height="120" autoplay></video>
            </div>
        </div>
    </div>
</div>
<?php echo JS_SWAL; ?>
<!--<link href="https://fonts.googleapis.com/css2?family=Amiri&display=swap" rel="stylesheet"> -->
<script>
    var soal=[];
    var n=1;
    var jawaban=[];
    var urutan=[];
    var kirim=[];
    var mapel="<?php echo $mapel;?>";
    $("#kirim").click(function(){
        swal({
        	title:"Konfirmasi", 
        	text:"Apakah Anda sudah selesai?",
        	type:"warning",
        	showCancelButton:true,
            confirmButtonText: "Sudah",
            cancelButtonText: "Belum!",
            closeOnConfirm: false,
    	}, function(a){
    	    if(a) {
    	        selesai="1";
    	    }
    	    else swal.close();
            if(selesai=="1"){
        	    swal({
                	title:"Memproses...", 
                	text:"Mohon tunggu sebentar. Jika halaman tidak dialihkan, silakan coba lagi",
                	type:"info",
                	timer: 10000,
                	showConfirmButton:false,
                	closeOnCancel: false,
            	});
                kirim[0]='';
                var i=0;
                var nilai=0;
                $.each(soal,function(){
                    i++;
                    kirim[urutan[i]]=jawaban[i];
                    if(jawaban[i]==undefined) kirim[urutan[i]]=' ';
                    if(jawaban[i]==soal[i].jawaban){
                        nilai++;
                    }
                });
                var kirimjawaban='';
                i=1;
                $.each(kirim,function(){
                    if(kirim[i]!=undefined) kirimjawaban+=kirim[i];
                    i++;
                });
                var pelanggaran="copas "+copas+" blur "+blurred;
                $.get("<?php echo base_url("student/jawaban_tes?aksi=selesai&mapel="); ?>"+mapel+"&jawaban="+kirimjawaban+"&nilai="+nilai+"&pelanggaran="+pelanggaran,function(data){
                    swal.close();
                    incek=0;
                    $("#terus").hide();
                    if(<?php echo $show_result['setting_value'];?>==1){
                        cek[incek].isi='Jawaban benar Anda: '+nilai+'<br/>Anda meng-copy soal sebanyak '+copas+' kali dan berpindah tab/aplikasi sebanyak '+blurred+' kali.';
                    }
                    gantidiv();
                    $("#d3").hide();
                    clearInterval(x);
                    $(".navbar-right").html(menu);
                });
            }
    	});
    });
    $(document).ready(function(){
        if("<?php echo $ikut_tes['nilai']; ?>"!="" || "<?php echo $mapel;?>"=="") {
            incek=0;
            $("#terus").hide();
        }
        gantidiv();
    });
    function getsoal(){
	    swal({
        	title:"Mengambil soal...", 
        	text:"Mohon tunggu sebentar. Jika halaman tidak dialihkan, silakan refresh",
        	type:"info",
        	timer: 2000,
        	showConfirmButton:false,
        	closeOnCancel: false,
    	});
        $.get("<?php echo base_url("student/soal_tes?mapel="); ?>"+mapel,function(data){
            swal.close();
            soal=data;
            var btn='';
            var i=1;
            $.each(soal,function(index,value){
                urutan[i]=soal[i].nomor;
                if(i==1) btn+='<h4>'+soal[i].mapel+'</h4>';
                btn+='<button class="btn btn-inverse" onclick="gantisoal(parseInt(this.id))" style="margin:3px" id="'+i+'">'+i+'</button>';
                i++;
            });
            $("#listnosoal").html(btn);
            gantisoal(n);
        },"json");
    }
    $("#a,#b,#c,#d,#e").click(function(){
        $("#a,#b,#c,#d,#e").removeClass("btn-success").removeClass("btn-orange");
        $(this).addClass("btn-success");
        $("#"+n).removeClass("btn-inverse").removeClass("btn-orange").addClass("btn-success");
        jawaban[n]=this.id;
    });
    function gantisoal(k){
        n=k;
        if(n==1){
            $("#kembali").hide();
        } else if(n>Object.keys(soal).length){
            $("#pilihsoal").click();
        } else{
            $("#kembali").show();
            $("#lanjut").show();
        }
        $("#a,#b,#c,#d,#e").removeClass("btn-success").removeClass("btn-orange");
        $("#nomor").text("Soal nomor "+n);
        $("#pertanyaan").html(soal[n].soal);
        if(soal[n].gambar!=null) $("#gambar").html('<img style="max-width:100%" src="'+soal[n].gambar+'">');
        else $("#gambar").html("");
        $("#"+jawaban[n]).addClass("btn-success");
        if(jawaban[n]=="f") $("#a,#b,#c,#d,#e").addClass("btn-orange");
        $("#d3").hide();
        $("#d2").show();
        if (soal[n].dir == 'rtl'){
            $("#a").html("أ. "+soal[n].a).css({'text-align':'right'});
            $("#b").html("ب. "+soal[n].b).css({'text-align':'right'});
            $("#c").html("ج. "+soal[n].c).css({'text-align':'right'});
            $("#d").html("د. "+soal[n].d).css({'text-align':'right'});
            $("#e").html("هـ. "+soal[n].e).css({'text-align':'right'});
            $("th").css({'text-align':'right','direction':'rtl'});
            $("th,#a,#b,#c,#d,#e").css({'font-family': 'Amiri','font-size':'18px','line-height': '2.429'});
        } else{
            $("#a").html("a. "+soal[n].a).css({'text-align':'left'});
            $("#b").html("b. "+soal[n].b).css({'text-align':'left'});
            $("#c").html("c. "+soal[n].c).css({'text-align':'left'});
            $("#d").html("d. "+soal[n].d).css({'text-align':'left'});
            $("#e").html("e. "+soal[n].e).css({'text-align':'left'});
            $("th").css({'text-align':'left','direction':'ltr'});
            $("th,#a,#b,#c,#d,#e").css({'font-family': 'roboto','font-size':'14px','line-height': '1.429'});
            $("ar").css({'font-family': 'Amiri','font-size':'18px','line-height': '2.429','direction':'rtl'});
        }
    };
    $("#tandai").click(function(){
        $("#"+n).removeClass("btn-inverse").removeClass("btn-success").addClass("btn-orange");
        $("#a,#b,#c,#d,#e").removeClass("btn-success").addClass("btn-orange");
        jawaban[n]='f';
    });
    $("#pilihsoal").click(function(){
        $("#d2").hide();
        $("#d3").show();
    });
    history.pushState(null, null, location.href);
    window.onpopstate = function () {
        swal({
        	title:"Konfirmasi", 
        	text:"Ingin meninggalkan halaman?",
        	type:"warning",
        	showCancelButton:true,
            confirmButtonText: "Ya",
            cancelButtonText: "Tidak",
    	}, function(a){
    	    if(a) history.go(-1);
    	    else history.pushState(null, null, location.href);
    	})
    };
    $("#navsoal").css({
        "position": "fixed",
        "left": "0",
        "bottom": "0",
        "width": "100%",
        "z-index":"20",
        "background":"black",
        "padding":"5px"
    })
    var incek=1;
    var cek = [
        {
            judul:'Anda Sudah mengerjakan Tes',
            isi:'Terima kasih telah mengikuti tes ini',
            klik:'lanjut()'
        },
        {
            judul:'Kejujuran',
            isi:'Apakah Anda siap mengerjakan Tes dengan jujur?'
                +'Ingatlah bahwa Allah Maha Mengetahui perbuatan kita. Kejujuran kita menunjukkan seberapa besar keimanan kita.',
            klik:'lanjut()'
        },
        {
            judul:'Token',
            isi:'Masukkan Token: <br/><input id="token"/>'
                +'<p>*Token akan dirilis di grup WA jika sudah tiba waktunya. Harap bersabar</p>',
            klik:'token()'
        },
        {
            judul:'Perhatian!!!',
            isi:'Waktu 60 menit akan berjalan setelah Anda mengeklik tombol lanjut. Tidak ada remedi jika Anda melakukan kesalahan. Nilai Anda tidak akan masuk jika Anda melebihi waktu yang ditentukan.',
            klik:'mulaites()'
        }
    ];
    function gantidiv(){
        $("#d0").show();
        $("#judul").text(cek[incek].judul);
        $("#isi").html(cek[incek].isi);
        $("#terus").attr("onclick",cek[incek].klik);
    }
    function lanjut(){
        incek++;
        gantidiv();
    }
    function token(){
        if($("#token").val()=="<?php echo $token['token'];?>"){
            lanjut();
        } else{
            swal("Waduh!!","Token yang Anda masukkan keliru!!!","error");
        }
    }
    function blok(id){
        $(id).addClass('btn-teal');
        mapel=$(id).attr('id');
    }
    var menu=$(".navbar-right").html();
    var x;
    function mulaites(){
        $.get("<?php echo base_url('student/jawaban_tes?aksi=mulai&mapel='); ?>"+mapel,function(data){
            if(data=="gagal"){
                swal("Waduh!!","Anda sudah pernah mengerjakan atau waktu Anda sudah habis!!!","error");
            } else{
                $("#d0").hide();
                $("#d2").show();
                getsoal();
                var waktu=JSON.parse(data);
                J=waktu.j;
                M=waktu.m;
                D=waktu.d;
                var countdown='<li><a href="#"><h4 class="text-orange" id="countdown"></h4></a></li>';
                $(".navbar-right").html(countdown+menu);
                x = setInterval(function() {
                    D--;
                    if(D==-1) {
                        D=59;
                        M--;
                    };
                    if(M==-1) {
                        M=59;
                        J--;
                    };
                    var A='',B='';
                    if(D<10) A="0";
                    if(M<10) B="0";
                    $("#countdown").html(J+":"+B+M+":"+A+D);
                    if(D==0 && M==0 && J==0) {
                        selesai="1";
                        $("#kirim").click();
                    }
                }, 1000);
            }
        })
    }
    var blurred = 0;
    var copas = 0;
    window.onblur = function() {
        blurred++;
    };
    $(document).bind('copy', function(e) {
        copas++;
    });
    var video = document.getElementById('dummy');
    var localstream;
    if(navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        navigator.mediaDevices.getUserMedia({ video: true }).then(function(stream) {
            localstream=stream;
            video.srcObject = stream;
            video.play();
        });
    }
</script>