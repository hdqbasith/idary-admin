<div id="d1">
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$nisn=$this->session->userdata['username'];
// if($tbs['kelasmts']=='MPA') echo
// '<div class="col-lg-12">
//     <div class="portlet">
//         <div class="portlet-heading bg-teal">
//             <h3 class="portlet-title">
//                 Ujian Akhir MPA
//             </h3>
//             <div class="portlet-widgets">
//                 <a data-toggle="collapse" data-parent="#accordion1" href="#bg-teal"><i class="ion-minus-round"></i></a>
//                 <span class="divider"></span>
//                 <a href="#" data-toggle="remove"><i class="ion-close-round"></i></a>
//             </div>
//             <div class="clearfix"></div>
//         </div>
//         <div id="bg-teal" class="panel-collapse collapse in">
//             <div class="portlet-body">
//             <a href="'.base_url("student/home").'">Klik di sini</a>
//             </div>
//         </div>
//     </div>
// </div>';
// if($tbs['kelasmts']!=null) echo
// '<div class="col-lg-12">
//     <div class="portlet">
//         <div class="portlet-heading bg-teal">
//             <h3 class="portlet-title">
//                 Informasi
//             </h3>
//             <div class="portlet-widgets">
//                 <a data-toggle="collapse" data-parent="#accordion1" href="#bg-teal"><i class="ion-minus-round"></i></a>
//                 <span class="divider"></span>
//                 <a href="#" data-toggle="remove"><i class="ion-close-round"></i></a>
//             </div>
//             <div class="clearfix"></div>
//         </div>
//         <div id="bg-teal" class="panel-collapse collapse in">
//             <div class="portlet-body">
//                 <ol><h3>PENGUMUAN PENJURUSAN</h3>
//                     <h4>A. PERTIMBANGAN</h4>
//                     <li>Jadwal Tes Penjurusan yang bersamaan dengan PAT MA dan PAT MTs TBS.</li>
//                     <li>Bahwa Penjurusan diharapkan mencari kemampuan yang valid.</li>
//                     <li>Tes Penjurusan Harus Face 2 Face dengan penguji.</li>
//                     <li>Keputusan Kepala Madrasah</li>
                    
//                     <h4>B. MEMUTUSKAN</h4>
//                     <li>Tes Penjurusan siswa dari MTs TBS dan MPA diundur</li>
//                     <li>Perkiraan waktu : 10-16 JULI 2020 (AwaL KBM)</li>
//                     <li>Teknis dan Bentuk Tes Akan diumumkan menyusul.</li>
//                 </ol>
//                 <ul>]
//                     Bagi siswa MTs NU TBS dan MPA yang telah mendaftar dan mengisi biodata di web PPDB dapat bergabung di salah satu Grup Naik Tingkat MA TBS 2020.
//                     <li><a href="https://chat.whatsapp.com/DHa4c3nftBj5AlxyzDm5jT">Grup Naik MA TBS 2020 - 1</a></li>
//                     <li><a href="https://chat.whatsapp.com/Fm1d7flHzDkHgvgUKiYTEu">Grup Naik MA TBS 2020 - 2</a></li>
//                     Pilih salah satu saja. Informasi akan disampaikan lewat grup tersebut.
//                 </ul>
                
//             </div>
//         </div>
//     </div>
// </div>';
?>
<div class="row" id="divlistmenu">
    <div class="col-md-12">
        <div class="card-box">
            <h4>Selamat Datang <?php echo $this->session->userdata('user_fullname'); ?>!</h4>
            <p><h5>Jadwal kegiatan madrasah adalah:</h5>
                <ul>
                    <li>Matsama : 12-14 Juli 2020</li>
                    <li>Tes Penjurusan : 15 Juli 2020</li>
                </ul>
            </p>
            <p><h5>Syarat dan tata tertib tes penjurusan:</h5>
                <ol>
                    <li>Mengisi <a href="https://masterdata.adminbaru.com/student/formulir_full" class="btn btn-teal">Biodata Lengkap</a> paling lambat 14 Juli 2020</li>
                    <li><b>MENGIKUTI MATSAMA SECARA PENUH DAN MENGERJAKAN TUGAS-TUGAS YANG DIBERIKAN</b></li>
                    <li>Apabila ada masalah saat tes penjurusan silakan hubungi <a href="https://wa.me/6289618740940">089618740940</a> dengan format:
                        <ul>
                            <li>Nama: </li>
                            <li>NISN: </li>
                            <li>Masalah: </li>
                        </ul>
                    </li>
                    <li>Siswa akan diberi kesempatan sekali untuk mengubah pilihan prioritas jurusannya</li>
                    <li>Ada 5 paket soal, WAJIB dikerjakan SEMUANYA</li>
                    <li>Ranking diambil dari rata-rata nilai 5 paket soal, dengan mempertimbangkan mapel yang sesuai jurusannya</li>
                    <li>Contoh 1: Ahmad memilih jurusan IPA, nilai rata-ratanya 8,0 tapi nilai IPA-nya 3,5 maka Ahmad tidak bisa masuk jurusan IPA</li>
                    <li>Contoh 2: Husain memilih jurusan Keagamaan, nilai IPA-nya 10 tapi Husain tidak mengerjakan 4 paket soal yang lain, maka Husain tidak bisa masuk jurusan Keagamaan</li>
                    <li>Panitia tidak akan mentolerir segala bentuk kecurangan dan pelanggaran peraturan</li>
                    <li>Hasil tes penjurusan tidak dapat diganggu gugat. Bagi yang tidak terima dengan hasil tes penjurusan JANGAN MENGIKUTI TES PENJURUSAN</li>
                    <li>Silakan belajar yang rajin agar bisa belajar sesuai jurusan yang dikehendaki</li>
                </ol>
            </p>
            <p><h5>Berikut adalah menu yang dapat Anda akses:</h5></p>
            <ul>
                <?php foreach($sidemenus as $menu){
                    if($menu['menu_parent']==0){
                        echo '<li><a href="';
                        if($menu['menu_link']==null) echo '#';
                        else echo base_url($menu['menu_link']);
                        echo '">'.$menu['menu_name'].'</a></li>';
                        $n=1;
                        foreach($sidemenus as $menu2){
                            if($menu2['menu_parent']==$menu['menu_id']){
                                if($n==1) echo '<ul>';
                                echo '<li><a href="'.base_url($menu2['menu_link']).'">'.$menu2['menu_name'].'</a></li>';
                                $n=2;
                            }
                        }
                        if($n==2) echo '</ul>';
                    }
                } ?>
            </ul>
        </div>
    </div>
</div>
</div>

<div id="d2" style="display:none">
    <div class="col-lg-12">
        <div class="portlet">
            <div class="portlet-heading bg-danger">
                <h3 class="portlet-title">
                    PERHATIAN!!
                </h3>
                <div class="clearfix"></div>
            </div>
            <div id="bg-teal" class="panel-collapse collapse in">
                <div class="portlet-body">
                    <p>
                        Mohon maaf, sepertinya Anda tidak menggunakan NISN yang benar untuk mendaftar. Perlu Anda ketahui bahwa aplikasi ini tidak menyediakan fitur perubahan NISN.
                        Jadi, silakan lakukan pengisian ulang formulir PPDB dengan menggunakan NISN yang benar lewat link berikut:<br/> <a href="https://masterdata.adminbaru.com/login#signup" class="btn btn-teal btn-rounded">Form PPDB</a>
                        <br/>Setelah melakukan pengisian ulang harap konfirmasi kepada panitia. NISN yang keliru bisa mengakibatkan Anda <b>tidak bisa mendapatkan RAPORT dan IJAZAH</b>. 
                        <br/>Jika Anda tidak tahu NISN Anda silakan tanyakan ke sekolah asal Anda. NISN terdiri dari 10 digit dengan 3 digit pertama adalah tahun lahir Anda.
                        Informasi lebih lanjut silakan hubungi Panitia PPDB.<br/>Terima kasih atas pengertiannya.<p class="text-right"><br/>ttd<br/><br/>Panitia PPDB</p>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    if(<?php echo $banned['ket']; ?>=="1"){
        $("#sidebar-menu").hide();
        $("#d1").hide();
        $("#d2").show();
    }
</script>