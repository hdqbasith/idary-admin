<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$nama=$this->session->userdata('fullname');
?>

<div id="d2" >
    <div class="col-lg-12">
        <div class="portlet">
            <div class="portlet-heading bg-teal">
                <h3 class="portlet-title">
                    PENGUMUMAN HASIL TES PENJURUSAN
                </h3>
                <div class="clearfix"></div>
            </div>
            <div id="bg-teal" class="panel-collapse collapse in">
                <div class="portlet-body">
                    <h4>Surat Keterangan Hasil Tes Penjurusan dapat didownload melalui link berikut:</h4>
                    <a href="<?php echo base_url('student/hasiltespenjurusan')?>" class="btn btn-success btn-block">Download hasil Tes Penjurusan</a>
                    <br/>
                </div>
            </div>
        </div>
    </div>
</div>