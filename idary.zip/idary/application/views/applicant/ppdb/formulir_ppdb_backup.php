<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$a['nama_lengkap']='Nama Lengkap'; $a['nama_arab']='Nama (arab)'; $a['nisn']='NISN'; $a['nik']='NIK'; $a['tempat_lahir']='Tempat Lahir'; $a['tanggal_lahir']='Tanggal Lahir'; $a['jml_saudara']='Jumlah Saudara'; $a['hp_siswa']='No. HP'; $a['email']='Email'; $a['m_citacita_id']='Cita-Cita'; $a['m_hobi_id']='Hobi'; $a['pil_jurusan1']='Pilihan Jurusan 1'; $a['pil_jurusan2']='Pilihan Jurusan 2'; $a['pil_jurusan3']='Pilihan Jurusan 3'; $a['pil_jurusan4']='Pilihan Jurusan 4'; 
$b['nama_sekolah_asal']='Nama Sekolah Asal'; $b['m_asal_sekolah_id']='Jenis Sekolah'; $b['npsn_sekolah_asal']='NPSN'; $b['alamat_sekolah_asal']='Alamat'; $b['tahun_ajaran']='Tahun Lulus'; $b['unindo']='Nilai UN Bahasa Indonesia'; $b['unmtk']='Nilai UN Matematika'; $b['unipa']='Nilai UN IPA'; $b['uning']='Nilai UN Bahasa Inggris'; 
$c['kelas_mts']='Kelas MTs TBS'; $c['absen_mts']='No. Absen'; 
$d['m_jenis_rumah_id']='Tempat Tinggal'; $d['m_jarak_id']='Jarak ke Madrasah'; $d['m_transport_id']='Transport ke madrasah'; $d['nama_pondok']='Mondok di'; $d['pimpinan_pondok']='Pimpinan Pondok'; $d['alamat_pondok']='Alamat Pondok'; $d['hp_pondok']='No. HP Pondok'; 
$e['nomor_kk']='No. KK'; $e['nama_kepala_keluarga']='Nama Kepala Keluarga'; $e['nama_ayah_kandung']='Nama Ayah Kandung'; $e['ayah_arab']='Nama Ayah (dalam tulisan arab)'; $e['tahun_lahir_ayah_kandung']='Tahun Lahir Ayah'; $e['m_kondisi_ayah_kandung_id']='Status Ayah'; $e['nik_ayah_kandung']='NIK Ayah'; $e['m_pendidikan_ayah_kandung_id']='Pendidikan Ayah'; $e['m_pekerjaan_ayah_kandung_id']='Pekerjaan Ayah'; $e['hp_ayah']='No. HP'; $e['nama_ibu_kandung']='Nama Ibu'; $e['tahun_lahir_ibu_kandung']='Tahun Lahir Ibu'; $e['m_kondisi_ibu_kandung_id']='Status Ibu'; $e['nik_ibu_kandung']='NIK Ibu'; $e['m_pendidikan_ibu_kandung_id']='Pendidikan Ibu'; $e['hp_ibu']='No. HP'; $e['m_pekerjaan_ibu_kandung_id']='Pekerjaan Ibu'; $e['nama_wali']='Nama Wali'; $e['tahun_lahir_wali']='TTL Wali'; $e['nik_wali']='NIK Wali'; $e['m_pendidikan_wali_id']='Pendidikan Wali'; $e['m_pekerjaan_wali_id']='Pekerjaan Wali'; $e['penghasilan_bulan']='Penghasilan per Bulan'; $e['alamat_ortu']='Alamat Orang Tua'; $e['alamat_arab']='Alamat (dalam tulisan arab)'; $e['m_status_rumah_id']='Status Rumah'; $e['propinsi_ortu']='Provinsi'; $e['kabupaten_ortu']='Kabupaten'; $e['kecamatan_ortu']='Kecamatan'; $e['kelurahan_ortu']='Desa'; $e['kode_pos_ortu']='Kode Pos'; $e['rt']='RT'; $e['rw']='RW';
$op['jurusan']=array(
    '1'=>'IPA', '2'=>'IPS', '3'=>'Bahasa', '4'=>'Keagamaan'
);
$op['pendidikan']=array(
    '0'=>'Tidak sekolah formal', '1'=>'<=SLTP', '2'=>'SLTA', '3'=>'D1', '4'=>'D2', '5'=>'D3', '6'=>'D4', '7'=>'S1', '8'=>'S2', '9'=>'S3'
);
$fl = array(
  'class'=> 'col-sm-4 control-label'
);
$fd = array(
  'class'=> 'datepicker form-control',
  'placeholder' => 'dd/mm/yyyy',
  'autocomplete' => 'off',
  'required' => ''
);
$op['status']=array(
    '0'=>'Masih Hidup', '1'=>'Almarhum'
);
$op['domisili']=array(
    '1'=>'Rumah Orang Tua', '2'=>'Rumah Saudara/Kerabat', '3'=>'Pondok Pesantren', '4'=>'Rumah Sewa/Kontrak/Kost', '5'=>'Panti Asuhan', '6'=>'Rumah Singgah', '7'=>'Lainnya'
);
$op['jenis']=array(
    '1'=>'SMP', '2'=>'MTs', '3'=>'SMP Terbuka', '4'=>'SLB', '5'=>'Paket B', '6'=>'Pesantren Salafiyah Wustha', '7'=>'SMP di Luar Negeri',
);
$op['status_sb']=array(
    '1'=>'Negeri', '2'=>'Swasta'
);
$op['kelas_mts']=array(
    'A'=>'IX A', 'B'=>'IX B', 'C'=>'IX C', 'D'=>'IX D', 'E'=>'IX E', 'F'=>'IX F', 'G'=>'IX G', 'H'=>'IX H', 'I'=>'IX I', 'J'=>'IX J', 'K'=>'IX K', 'L'=>'IX L'
);
    
$op['pekerjaan']=array(
    '1'=>'Tidak Bekerja (di rumah saja)', '2'=>'Pensiunan/Almarhum', '3'=>'PNS (selain guru/dokter/bidan/perawat)', '4'=>'TNI/Polisi', '5'=>'Guru/Dosen', '6'=>'Pegawai Swasta', '7'=>'Pengusaha/Wiraswasta', '8'=>'Pengacara/Hakim/Jaksa/Notaris', '9'=>'Seniman/Pelukis/Artis/Sejenis', '10'=>'Dokter/Bidan/Perawat', '11'=>'Pilot/Pramugari', '12'=>'Pedagang', '13'=>'Petani/Peternak', '14'=>'Nelayan', '15'=>'Buruh (Tani/Pabrik/Bangunan)', '16'=>'Sopir/Masinis/Kondektur', '17'=>'Politikus', '18'=>'Lainnya'
);
echo form_button('kembali','Kembali','btn btn-rounded btn-danger waves-effect waves-light btn-lg')
    .heading('Gunakanlah huruf besar di "Awal Kata", "JANGAN SEMUA HURUF"',3,'');
echo form_open('fungsiard/tes','name="formedit" id="formedit" class="form-horizontal"')
	.dvo('panel panel-color panel-teal')
		.dvo('panel-heading')
			.heading('Data Pribadi', 4, 'class="panel-title"')
		.dvc()

		.dvo('panel-body')
			.dvo('row')
    			.dvo('col-md-6','','border-right: 2px solid lightgrey')
    				.dvo('form-group')
    					.form_label('NISN', 'nisn', $fl)
    					.dvo('col-sm-8')
    						.form_input('nisn', $a['nisn'], 'class="form-control"')
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Nama Lengkap', 'nama_lengkap', $fl)
    					.dvo('col-sm-8')
    						.form_input('nama_lengkap', $a['nama_lengkap'], 'class="form-control"')
    					.dvc()
    				.dvc() 
    				.dvo('form-group')
    					.form_label('NIK', 'nik', $fl)
    					.dvo('col-sm-8')
    						.form_input('nik', $a['nik'], 'class="form-control"')
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Tempat Lahir', 'tempat_lahir', $fl)
    					.dvo('col-sm-8')
    						.form_input('tempat_lahir', $a['tempat_lahir'], 'class="form-control"')
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Tanggal Lahir', 'tanggal_lahir', $fl)
    					.dvo('col-sm-8')
    						.form_input('tanggal_lahir', $a['tanggal_lahir'], $fd)
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Jumlah Saudara', 'jml_saudara', $fl)
    					.dvo('col-sm-8')
    						.form_input('jml_saudara', $a['jml_saudara'], 'class="form-control"')
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('No. HP', 'hp_siswa', $fl)
    					.dvo('col-sm-8')
    						.form_input('hp_siswa', $a['hp_siswa'], 'class="form-control"')
    					.dvc()
    				.dvc()
    			.dvc()
    			.dvo('col-md-6','','border-right: 2px solid lightgrey')
    				.dvo('form-group')
    					.form_label('Email', 'email', $fl)
    					.dvo('col-sm-8')
    						.form_input('email', $a['email'], 'class="form-control"')
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Cita-Cita', 'm_citacita_id', $fl)
    					.dvo('col-sm-8')
    						.form_input('m_citacita_id', $a['m_citacita_id'], 'class="form-control"')
    					.dvc()
    				.dvc() 
    				.dvo('form-group')
    					.form_label('Hobi', 'm_hobi_id', $fl)
    					.dvo('col-sm-8')
    						.form_input('m_hobi_id', $a['m_hobi_id'], 'class="form-control"')
    					.dvc()
    				.dvc() 
    				.dvo('form-group')
    					.form_label('Pilihan Jurusan 1', 'pil_jurusan', $fl)
    					.dvo('col-sm-8')
    						.form_input('pil_jurusan', $a['pil_jurusan1'], 'class="form-control"')
    					.dvc()
    				.dvc() 
    				.dvo('form-group')
    					.form_label('Pilihan Jurusan 2', 'pil_jurusan', $fl)
    					.dvo('col-sm-8')
    						.form_input('pil_jurusan', $a['pil_jurusan2'], 'class="form-control"')
    					.dvc()
    				.dvc() 
    				.dvo('form-group')
    					.form_label('Pilihan Jurusan 3', 'pil_jurusan', $fl)
    					.dvo('col-sm-8')
    						.form_input('pil_jurusan', $a['pil_jurusan3'], 'class="form-control"')
    					.dvc()
    				.dvc() 
    				.dvo('form-group')
    					.form_label('Pilihan Jurusan 4', 'pil_jurusan', $fl)
    					.dvo('col-sm-8')
    						.form_input('pil_jurusan', $a['pil_jurusan4'], 'class="form-control"')
    					.dvc()
    				.dvc()
    			.dvc()
			.dvc()
		.dvc()
	.dvc()
	.dvo('panel panel-color panel-teal')
		.dvo('panel-heading')
			.heading('Alamat', 4, 'class="panel-title"')
		.dvc()

		.dvo('panel-body')
			.dvo('row')
    			.dvo('col-md-6','','border-right: 2px solid lightgrey')
    				.dvo('form-group')
    					.form_label('Tempat Tinggal', 'm_jenis_rumah_id', $fl)
    					.dvo('col-sm-8')
    						.form_input('m_jenis_rumah_id', $d['m_jenis_rumah_id'], 'class="form-control"')
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Jarak ke Madrasah', 'm_jarak_id', $fl)
    					.dvo('col-sm-8')
    						.form_input('m_jarak_id', $d['m_jarak_id'], 'class="form-control"')
    					.dvc()
    				.dvc() 
    				.dvo('form-group')
    					.form_label('Transport ke Madrasah', 'm_transport_id', $fl)
    					.dvo('col-sm-8')
    						.form_input('m_transport_id', $d['m_transport_id'], 'class="form-control"')
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Mondok di', 'nama_pondok', $fl)
    					.dvo('col-sm-8')
    						.form_input('nama_pondok', $d['nama_pondok'], 'class="form-control"')
    					.dvc()
    				.dvc()
    			.dvc()
    			.dvo('col-md-6','','border-right: 2px solid lightgrey')
    				.dvo('form-group')
    					.form_label('Pimpinan Pondok', 'pimpinan_pondok', $fl)
    					.dvo('col-sm-8')
    						.form_input('pimpinan_pondok', $d['pimpinan_pondok'], 'class="form-control"')
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Alamat Pondok', 'alamat_pondok', $fl)
    					.dvo('col-sm-8')
    						.form_input('alamat_pondok', $d['alamat_pondok'], 'class="form-control"')
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('No. HP Pondok', 'hp_pondok', $fl)
    					.dvo('col-sm-8')
    						.form_input('hp_pondok', $d['hp_pondok'], 'class="form-control"')
    					.dvc()
    				.dvc()
    			.dvc()
			.dvc()
		.dvc()
	.dvc()
	.dvo('panel panel-color panel-teal')
		.dvo('panel-heading')
			.heading('Sekolah Asal', 4, 'class="panel-title"')
		.dvc()

	.dvc()
	.dvo('panel panel-color panel-teal')
		.dvo('panel-heading')
			.heading('Orang Tua dan Wali', 4, 'class="panel-title"')
		.dvc()

	.dvc()
	.form_button('simpan','Simpan','btn btn-rounded btn-orange waves-effect waves-light btn-lg btn-block')
.form_close();



?>

<script>
    jQuery.extend(jQuery.expr[':'], {
        focusable: function (el, index, selector) {
            return $(el).is('a, button, :input, [tabindex]');
        }
    });
    $(document).on('keypress', 'input,select', function (e) {
        if (e.which == 13) {
            e.preventDefault();
            var $canfocus = $(':focusable');
            var index = $canfocus.index(this) + 1;
            if (index >= $canfocus.length) index = 0;
            $canfocus.eq(index).focus();
        };
    });
    $(document).ready(function(){
        if($("#nisn").val()=="NISN") $('input').val("");
        $("#nisn").val("<?php echo $this->session->userdata['username']; ?>");
        $("#nama_lengkap").focus();
    });
</script>