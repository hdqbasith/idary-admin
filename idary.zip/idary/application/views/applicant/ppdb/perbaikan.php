<?php
defined('BASEPATH') OR exit('No direct script access allowed');
echo dvo('panel panel-color panel-teal','d0')
	.dvo('panel-heading')
		.heading('Perbaikan', 4, 'class="panel-title" id="judul"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		        .po('Mohon maaf, sedang perbaikan. Silakan kembali pukul 16.00')
		        .pc();
		    echo dvc()
	    .dvc()
    .dvc()
.dvc();
?>