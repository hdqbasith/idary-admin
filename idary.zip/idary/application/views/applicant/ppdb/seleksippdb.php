<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$nomor=array('1'=>'01','2'=>'02','3'=>'03','4'=>'04','5'=>'05','6'=>'06','7'=>'07','8'=>'08','9'=>'09','10'=>'10','11'=>'11','12'=>'12','13'=>'13','14'=>'14','15'=>'15','16'=>'16','17'=>'17','18'=>'18','19'=>'19','20'=>'20','21'=>'21','22'=>'22','23'=>'23','24'=>'24','25'=>'25','26'=>'26','27'=>'27','28'=>'28','29'=>'29','30'=>'30','31'=>'31','32'=>'32','33'=>'33','34'=>'34','35'=>'35','36'=>'36','37'=>'37','38'=>'38','39'=>'39','40'=>'40','41'=>'41','42'=>'42','43'=>'43','44'=>'44','45'=>'45','46'=>'46','47'=>'47','48'=>'48','49'=>'49','50'=>'50','51'=>'51','52'=>'52','53'=>'53','54'=>'54','55'=>'55','56'=>'56','57'=>'57','58'=>'58','59'=>'59','60'=>'60','61'=>'61','62'=>'62','63'=>'63','64'=>'64','65'=>'65','66'=>'66','67'=>'67','68'=>'68','69'=>'69','70'=>'70','71'=>'71','72'=>'72','73'=>'73','74'=>'74','75'=>'75','76'=>'76','77'=>'77','78'=>'78','79'=>'79','80'=>'80','81'=>'81','82'=>'82','83'=>'83','84'=>'84','85'=>'85','86'=>'86','87'=>'87','88'=>'88','89'=>'89','90'=>'90','91'=>'91','92'=>'92','93'=>'93','94'=>'94','95'=>'95','96'=>'96','97'=>'97','98'=>'98','99'=>'99','100'=>'100');
shuffle($nomor);
?>

<div id="d1" class="col-lg-12">
    <div class="portlet">
        <div class="portlet-heading bg-teal">
            <h4 class="text-white">PERATURAN TES SELEKSI PPDB 2020</h4>
        </div>
        <ol><h4>Mohon dibaca, dipahami, dan diikuti</h4>
            <li>HANYA UNTUK PENDAFTAR DARI LUAR MTs TBS</li>
            <li>Pastikan HP/laptop Anda baterainya full serta memiliki akses internet yang cukup</li>
            <li>Link soal dibuka pukul 08.00 dan ditutup pukul 20.00</li>
            <li>Waktu mengerjakan adalah 120 menit setelah Anda mengeklik "mulai". Waktu habis, jawaban otomatis terkirim</li>
            <li>Setelah mengeklik mulai, dilarang membuka "tab baru" atau aplikasi lain (WA/FB/Google)</li>
            <li>Pastikan internet Anda tidak putus selama pengerjaan soal</li>
            <li>Jawaban Anda hilang jika Anda merefresh browser Anda. Anda harus mengerjakan dari awal dengan waktu yang tersisa</li>
            <li>Pastikan Anda mengeklik tombol "kirim jawaban" setelah selesai mengerjakan, jika tidak jawaban Anda tidak akan tersimpan</li>
            <li>Jika tombol kirim jawaban tidak bisa diklik, silakan tunggu 30 detik sebelum mengeklik lagi. Jika tiga kali tidak bisa, cek internet Anda</li>
            <li>Jika Anda TIDAK SENGAJA mengeklik tombol "kirim jawaban", maka TIDAK ADA PENGULANGAN</li>
            <li>Anda tidak diperkenankan men-screenshot/meng-copy/memfoto/menyebarkan soal di aplikasi ini</li>
            <li>Anda tidak diperkenankan menyontek dalam bentuk apapun (membuka buku/internet/dll)</li>
            <div class="checkbox checkbox-success">
                <input type="checkbox" id="setuju" class="form-control" />
                <label class="control-label text-danger" for="setuju">Dengan ini saya telah memahami peraturan di atas dan siap mengerjakan tes seleksi dengan jujur. Jika saya melanggar peraturan di atas saya siap menanggung akibatnya baik di dunia maupun di akhirat, termasuk tidak diterima di MA NU TBS Kudus.</label>
            </div>
        </ol>
        <button id="mulai" class="btn btn-teal btn-lg btn-rounded disabled">Mulai</button>
    </div>
</div>
<div id="d2" class="col-lg-12" style="display:none">
    <div class="portlet">
        <div class="portlet-heading bg-teal">
            <h3 class="portlet-title text-dark" id="nomor">
                Soal nomor
            </h3>
            <div style="position:absolute; opacity:0.05;" class="col-md-12">
                <h4 class="text-center"><?php echo $this->session->userdata('username').'<br/>'.$this->session->userdata('user_fullname');?></h4>
            </div>
            <div class="portlet-widgets">
                <button class="btn btn-rounded btn-danger" id="pilihsoal">Pilih Soal</button>
                <!--<a data-toggle="collapse" data-parent="#accordion1" href="#soal" class="" aria-expanded="true"><button class="btn btn-inverse"><i class="ion-minus-round"></i></button></a>-->
            </div>
            <div class="clearfix"></div>
        </div>
        <div id="soal" class="panel-collapse collapse in" style="" aria-expanded="true">
            <div class="portlet-body" style="z-index:2">
                <table style="width:100%">
                    <thead>
                        <tr>
                            <th><span id="pertanyaan" style="text-transform:none;"></span></th>
                        </tr>
                    </thead>
                    <tbody style="margin-top:20px;">
                        <tr>
                            <td id="gambar"></td>
                        </tr>
                        <tr>
                            <td><p id="a" class="btn btn-block btn-rounded" style="text-align:left; margin:5px;white-space: normal;"></p></td>
                        </tr>
                        <tr>
                            <td><p id="b" class="btn btn-block btn-rounded" style="text-align:left; margin:5px;white-space: normal;"></p></td>
                        </tr>
                        <tr>
                            <td><p id="c" class="btn btn-block btn-rounded" style="text-align:left; margin:5px;white-space: normal;"></p></td>
                        </tr>
                        <tr>
                            <td><p id="d" class="btn btn-block btn-rounded" style="text-align:left; margin:5px;white-space: normal;"></p></td>
                        </tr>
                        <tr style="display:none">
                            <td><p id="e" class="btn btn-block btn-rounded" style="text-align:left; margin:5px;white-space: normal;"></p></td>
                        </tr>
                    </tbody>
                </table>
                <div class="row" style="margin-top:20px;" id="navsoal">
                    <div class="col-xs-4">
                        <button id="kembali" class="btn btn-lg btn-teal btn-rounded" onclick="gantisoal(n-1)">Back</button>
                    </div>
                    <div class="col-xs-4 text-center">
                        <button id="tandai" class="btn btn-lg btn-orange btn-rounded">Tandai</button>
                    </div>
                    <div class="col-xs-4 text-right">
                        <button id="lanjut" class="btn btn-lg btn-teal btn-rounded" onclick="gantisoal(n+1)">Next</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="d3" class="col-lg-12" style="display:none">
    <div class="portlet">
        <div class="portlet-heading bg-teal">
            <h3 class="portlet-title text-dark">
                Soal
            </h3>
            <div class="portlet-widgets">
                <!--<a data-toggle="collapse" data-parent="#accordion1" href="#listnomor" class="" aria-expanded="true"><button class="btn btn-inverse"><i class="ion-minus-round"></i></button></a>-->
            </div>
            <div class="clearfix"></div>
        </div>
        <div id="listnomor" class="panel-collapse collapse in" style="" aria-expanded="true">
            <div class="portlet-body">
                <div id="listnosoal">
                </div>
                <div style="margin-top:20px;">
                    <button id="kirim" class="btn btn-success btn-block btn-lg btn-rounded">Kirim jawaban</button>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="d4" class="col-lg-12" style="display:none">
    <div class="portlet">
        <div class="portlet-heading bg-teal">
            <h3 class="portlet-title text-dark">
                Hasil Tes
            </h3>
            <div class="clearfix"></div>
        </div>
        <div class="panel-collapse collapse in" style="" aria-expanded="true">
            <div class="portlet-body">
                <h4>Terima kasih telah mengikuti tes seleksi.<br/><span id="nilai" class="text-danger"></span></h4>
                <br/><a class="btn btn-danger btn-lg" href="https://masterdata.adminbaru.com/student/index">kembali</a>
            </div>
        </div>
    </div>
</div>
<link href="https://fonts.googleapis.com/css2?family=Amiri&display=swap" rel="stylesheet"> 
<script>
    if("<?php echo $ppdb['kelasmts']; ?>"!="") $("#d1").html("Hanya untuk pendaftar dari luar MTs TBS");
    var soal=[];
    var n=1;
    var jawaban=[];
    var urutan=[];
    var kirim=[];
    var selesai="0";
    $("#kirim").click(function(){
        if (confirm("Sudah Selesai?") == true) {
            selesai="1";
        }
        if(selesai=="1"){
            kirim[0]='';
            var i=0;
            var nilai=0;
            $.each(soal,function(){
                i++;
                kirim[urutan[i]]=jawaban[i];
                if(jawaban[i]==undefined) kirim[urutan[i]]=' ';
                if(jawaban[i]==soal[i].jawaban){
                    nilai++;
                }
            });
            var kirimjawaban='';
            i=1;
            $.each(kirim,function(){
                if(kirim[i]!=undefined) kirimjawaban+=kirim[i];
                i++;
            });
            if(copas>0 && blurred>0) $("#nilai").text("Anda telah meng-copy soal sebanyak "+copas+" kali dan berpindah tab/aplikasi/layar mati sebanyak "+blurred+" kali.");
            var pelanggaran="copas "+copas+" blur "+blurred;
            $.get("<?php echo base_url("student/jawaban_ppdb?aksi=selesai&jawaban="); ?>"+kirimjawaban+"&nilai="+nilai+"&pelanggaran="+pelanggaran,function(data){
                $("#d2,#d3").hide();
                $("#d4").show();
            });
        }
    });
    $(document).ready(function(){
        $.get("<?php echo base_url("student/get_soal"); ?>",function(data){
            soal=data;
            var btn="<h4>Tes Seleksi PPDB 2020</h4>";
            var i=1;
            $.each(soal,function(index,value){
                urutan[i]=soal[i].nomor;
                btn+='<button class="btn btn-inverse" onclick="gantisoal(parseInt(this.id))" style="margin:3px" id="'+i+'">'+i+'</button>';
                i++;
            });
            $("#listnosoal").html(btn);
        },"json");
    });
    $("#a,#b,#c,#d,#e").click(function(){
        $("#a,#b,#c,#d,#e").removeClass("btn-success").removeClass("btn-orange");
        $(this).addClass("btn-success");
        $("#"+n).removeClass("btn-inverse").removeClass("btn-orange").addClass("btn-success");
        jawaban[n]=this.id;
    });
    function gantisoal(k){
        n=k;
        if(n==1){
            $("#kembali").hide();
        } else if(n>Object.keys(soal).length){
            $("#pilihsoal").click();
        } else{
            $("#kembali").show();
            $("#lanjut").show();
        }
        $("#a,#b,#c,#d,#e").removeClass("btn-success").removeClass("btn-orange");
        $("#nomor").text("Soal nomor "+n);
        $("#pertanyaan").html(soal[n].soal);
        if(soal[n].gambar!=null) $("#gambar").html('<img style="max-width:100%" src="'+soal[n].gambar+'">');
        else $("#gambar").html("");
        $("#"+jawaban[n]).addClass("btn-success");
        if(jawaban[n]=="f") $("#a,#b,#c,#d,#e").addClass("btn-orange");
        $("#d3").hide();
        $("#d2").show();
        if (soal[n].dir == 'rtl'){
            $("#a").html("أ. "+soal[n].a).css({'text-align':'right'});
            $("#b").html("ب. "+soal[n].b).css({'text-align':'right'});
            $("#c").html("ج. "+soal[n].c).css({'text-align':'right'});
            $("#d").html("د. "+soal[n].d).css({'text-align':'right'});
            $("#e").html("هـ. "+soal[n].e).css({'text-align':'right'});
            $("th").css({'text-align':'right','direction':'rtl'});
            $("th,#a,#b,#c,#d,#e").css({'font-family': 'Amiri','font-size':'18px','line-height': '2.429'});
        } else{
            $("#a").html("a. "+soal[n].a).css({'text-align':'left'});
            $("#b").html("b. "+soal[n].b).css({'text-align':'left'});
            $("#c").html("c. "+soal[n].c).css({'text-align':'left'});
            $("#d").html("d. "+soal[n].d).css({'text-align':'left'});
            $("#e").html("e. "+soal[n].e).css({'text-align':'left'});
            $("th").css({'text-align':'left','direction':'ltr'});
            $("th,#a,#b,#c,#d,#e").css({'font-family': 'roboto','font-size':'14px','line-height': '1.429'});
            $("ar").css({'font-family': 'Amiri','font-size':'18px','line-height': '2.429','direction':'rtl'});
        }
    };
    $("#tandai").click(function(){
        $("#"+n).removeClass("btn-inverse").removeClass("btn-success").addClass("btn-orange");
        $("#a,#b,#c,#d,#e").removeClass("btn-success").addClass("btn-orange");
        jawaban[n]='f';
    });
    $("#mulai").click(function(){
        $(this).prop('disabled',true);
        var J=1, M=59, D=59;
        $.get("<?php echo base_url('student/jawaban_ppdb?aksi=mulai'); ?>",function(data){
            if(data=="gagal"){
                alert('Anda sudah pernah mengerjakan atau waktu Anda sudah habis!!!');
            } else{
                var waktu=JSON.parse(data);
                J=waktu.j;
                M=waktu.m;
                D=waktu.d;
                $("#d2").show();
                $("#d1").hide();
                gantisoal(n);
                var menu=$(".navbar-right").html();
                var countdown='<li><a href="#"><h4 class="text-orange" id="countdown"></h4></a></li>';
                $(".navbar-right").html(countdown+menu);
                var x = setInterval(function() {
                    D--;
                    if(D==-1) {
                        D=59;
                        M--;
                    };
                    if(M==-1) {
                        M=59;
                        J--;
                    };
                    var A='',B='';
                    if(D<10) A="0";
                    if(M<10) B="0";
                    $("#countdown").html(J+":"+B+M+":"+A+D);
                    if(D==0 && M==0 && J==0) {
                        selesai="1";
                        $("#kirim").click();
                    }
                }, 1000);
            }
        });
    });
    $("#pilihsoal").click(function(){
        $("#d2").hide();
        $("#d3").show();
    });
    window.onbeforeunload = function(e) {
        return "Yakin?";
    }
    $("#navsoal").css({
        "position": "fixed",
        "left": "0",
        "bottom": "0",
        "width": "100%",
        "z-index":"20",
        "background":"black",
        "padding":"5px"
    })
    
    $('#setuju').change(function() {
        if(this.checked) $("#mulai").removeClass("disabled");
        else $("#mulai").addClass("disabled");
    });
    var blurred = 0;
    var copas = 0;
    window.onblur = function() {
        blurred++;
    };
    $(document).bind('copy', function(e) {
        copas++;
    });
</script>