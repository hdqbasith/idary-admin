<h1>ok</h1>
<div class="col-lg-12">
    <div class="portlet">
        <div class="portlet-heading bg-teal">
            <h3 class="portlet-title">
                Petunjuk Umum
            </h3>
            <div class="portlet-widgets">
                <a data-toggle="collapse" data-parent="#accordion1" href="#bg-teal"><i class="ion-minus-round"></i></a>
                <span class="divider"></span>
                <a href="#" data-toggle="remove"><i class="ion-close-round"></i></a>
            </div>
            <div class="clearfix"></div>
        </div>
        <div id="bg-teal" class="panel-collapse collapse in">
            <div class="portlet-body">
                <ul>
                    <li>Isilah Data Anda dengan berpedoman pada data Ijazah dan KK.</li>
                    <li>Isilah Data Anda dengan lengkap. Pengisian data yang tidak lengkap bisa mengakibatkan nama Anda tidak tercatat di pusat data Nasional.</li>
                    <li>Untuk nama arab boleh dikosongi, dengan catatan tidak akan protes apabila panitia keliru dalam menuliskan nama arab Anda dan Ayah Anda.</li>
                    <li>Pilihan Jurusan Anda tidak bisa diubah.</li>
                    <li>Harap bersabar ketika mengisi kolom kabupaten, kecamatan, dan kelurahan/desa. Tunggu sampai muncul pilihan.</li>
                    <li>Apabila Desa/Kelurahan Anda tidak tersedia dalam pilihan, silakan isi manual di kolom alamat.</li>
                    <li>Ketika Anda mengirimkan pertanyaan kepada panitia, harap menunggu jawaban dengan sabar. Panitia tidak selalu online dan belum tentu bisa menjawab langsung pertanyaan Anda.</li>
                    <li>Nomor yang ada di halaman ini adalah nomor Pengembang Aplikasi, bukan nomor Panitia. Hubungi nomor ini hanya jika ada error di aplikasi. Untuk masalah teknis silakan hubungi nomor Panitia yang ada di <a href="http://ma.madrasahtbs.sch.id">website madrasah</a> atau di brosur pendaftaran.</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Trigger the modal with a button -->
<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body">
        <p>Some text in the modal.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<button id="toast">Toast</button>
<link href="<?php echo base_url()?>assets/plugins/toastr/toastr.min.css" rel="stylesheet">

<script src="<?php echo base_url()?>assets/plugins/toastr/toastr.min.js"></script>
<script>
    history.pushState(null, document.title, location.href);
    window.addEventListener('popstate', function (event)
    {
        let leavePage = confirm("Apakah Anda ingin meniggalkan halaman ini?");
        if (leavePage) {
            history.back() 
        } else {
            history.pushState(null, document.title, location.href);
        }  
    });
    $('#toast').click(function(){
        toastr.options = {
        "closeButton": false,
        "debug": false,
        "newestOnTop": false,
        "progressBar": true,
        "positionClass": "toast-bottom-right",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "100",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "show",
        "hideMethod": "hide"
        };
        toastr.success('Data berhasil disimpan', 'Sukses!');
    });
</script>