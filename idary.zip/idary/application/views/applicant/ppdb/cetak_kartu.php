<?php
echo
dvo('panel panel-color panel-teal')
	.dvo('panel-heading')
		.heading('Cetak Kartu Tes PPDB', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		    .po('Pencetakan kartu tes belum bisa dilakukan. Silakan tunggu informasi selanjutnya')
		    .dvc()
	    .dvc()
    .dvc()
.dvc()
		   
?>
<script>
        $(".page-title").text("Cetak Kartu Tes PPDB");
        $("#judul_hlm").text("Cetak Kartu Tes");
</script>