<div id="d1">
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$nisn=$this->session->userdata['username'];
echo
'<div class="col-lg-12">
    <div class="portlet">
        <div class="portlet-heading bg-teal">
            <h3 class="portlet-title">
                Selamat datang '.$this->session->userdata('user_fullname').'
            </h3>
            <div class="portlet-widgets">
                <a data-toggle="collapse" data-parent="#accordion1" href="#bg-teal"><i class="ion-minus-round"></i></a>
                <span class="divider"></span>
                <a href="#" data-toggle="remove"><i class="ion-close-round"></i></a>
            </div>
            <div class="clearfix"></div>
        </div>
        <div id="bg-teal" class="panel-collapse collapse in">
            <div class="portlet-body">
                <p>Selamat datang di Idary Admin, sistem informasi terpadu MA NU TBS Kudus. Silakan kembali lagi di hari Rabu, 22 Juli 2020. Insya`allah informasi akan disampaikan mulai hari tersebut.
                </p>
            </div>
        </div>
    </div>
</div>';
?>