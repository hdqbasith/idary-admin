<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$fl = array(
  'class'=> 'col-sm-4 control-label'
);
echo dvo('panel panel-color panel-teal','d0')
	.dvo('panel-heading')
		.heading('Pengajuan Ganti NISN/Username', 4, 'class="panel-title" id="judul"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		        .form_open('','name="form" id="form" class="form-horizontal" style="background:white"')
    				.dvo('form-group')
    					.form_label('NISN Lama', 'nisn_lama', $fl)
    					.dvo('col-sm-8')
        					.form_input('nisn_lama', '', 'class="form-control"')
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('NISN Baru', 'nisn_baru', $fl)
    					.dvo('col-sm-8')
        					.form_input('nisn_baru', '', 'class="form-control"')
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Password Lama', 'password_lama', $fl)
    					.dvo('col-sm-8')
        					.form_input('password_lama', '', 'class="form-control" type="password"')
    					.dvc()
    				.dvc()
                	.form_button('simpan','Simpan','btn btn-rounded btn-teal waves-effect waves-light btn-lg btn-block')
                .form_close()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();

?>
<link href="<?php echo base_url()?>assets/plugins/bootstrap-sweetalert/sweet-alert.css" rel="stylesheet" type="text/css">

<script src="<?php echo base_url()?>assets/plugins/bootstrap-sweetalert/sweet-alert.min.js"></script>
<script>
    $("#form").submit(function(e){
        e.preventDefault();
        swal({
        	title:"Menyimpan...", 
        	text:"Mohon tunggu sebentar. Jika tidak ada notifikasi sukses, silakan coba lagi",
        	type:"warning",
        	timer: 10000,
        	closeOnCancel: false
    	});
    	values=this.serialize();
        $.post("<?php echo base_url("student/gantinisn"); ?>",values,function(data){
            swal({
            	title:data, 
            	text:"Data Anda berhasil disimpan",
            	type:"success",
            	timer: 3000
        	});
        });
    });
</script>