<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$tanggal=date('d')-22;
if(date('d')<24) $tanggal=date('d')+8;
if(date('H')<18) $tanggal-=1;
?>
<div id="d0" class="col-lg-12 text-center">
    <div class="panel panel-color panel-info">
        <div class="panel-heading">
            <h3>Khataman Akbar<br/>MA NU TBS Kudus<br/>Edisi Ramadlan 1441 H</h3>
        </div>
        <div class="panel-body">
            <h5><?php echo $tanggal;?> Ramadlan 1441 H</h5>
            <h3>Jumlah khataman</h3>
            <h1 id="jum_khatam" class="btn btn-teal btn-rounded btn-lg btn-block" style="font-size:68pt"><?php echo $jumlah['jumlah'];?></h1>
        </div>
    </div>
</div>
<div id="d1" class="col-lg-12">
    <div class="portlet">
        <div class="portlet-heading portlet-teal">
            <h3 class="portlet-title text-dark">
                Progres Membaca
            </h3>
            <div class="portlet-widgets">
                <button id="baru" class="btn btn-orange">Daftar</button>
                <a data-toggle="collapse" data-parent="#accordion1" href="#d1body" class="" aria-expanded="true"><i class="ion-minus-round"></i></a>
            </div>
            <div class="clearfix"></div>
        </div>
        <div id="d1body" class="panel-collapse collapse in" style="" aria-expanded="true">
            <div class="portlet-body">
                <p>Harap mengisi data dengan jujur dan jangan keliru mengisi data orang lain. Klik tanda <b class="text-primary">"+"</b> pada kolom Kelas/Absen untuk mengisi data.<p>
                <table id="tabel" class="table table-bordered">
                    <thead>
                        <tr>
                            <td>Kelas/Absen</td>
                            <td>Nama</td>
                            <td>Sudah Baca Juz</td>
                            <td>Jumlah Khatam</td>
                            <td>id</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($listsiswa as $l){
                            echo '<tr>
                                <td>'.$l->kelas.' / '.$l->absen.'</td>
                                <td>'.$l->nama.'</td>
                                <td>'.$l->juz.'</td>
                                <td>'.$l->khatam.'</td>
                                <td>'.$l->id.'</td>
                            </tr>';
                        } 
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<div id="d2" class="col-lg-12" style="display:none">
    <button id="batal" class="btn btn-danger btn-block btn-rounded">Batal</button>
    <div class="portlet">
        <div class="portlet-heading portlet-teal">
            <h3 class="portlet-title text-dark">
                Daftar
            </h3>
            <div class="portlet-widgets">
                <a data-toggle="collapse" data-parent="#accordion1" href="#d2body" class="" aria-expanded="true"><i class="ion-minus-round"></i></a>
            </div>
            <div class="clearfix"></div>
        </div>
        <div id="d2body" class="panel-collapse collapse in" style="" aria-expanded="true">
            <div class="portlet-body">
                <form id="formedit">
                    <div class="form-group row">
                        <label class="col-md-6" for="nama">Nama</label>
                        <input type="text" class="col-md-6 form-control" id="nama" name="nama" autocomplete="on">
                    </div>
                    <div class="form-group row">
                        <label class="col-md-6" for="kelas">Kelas</label>
                        <select type="text" class="col-md-6 form-control" id="kelas" name="kelas" autocomplete="on">
                            <option>Guru</option>
                            <option>Karyawan</option>
                            <option>Alumni</option>
                            <option>XA</option>
                            <option>XB</option>
                            <option>XC</option>
                            <option>XD</option>
                            <option>XE</option>
                            <option>XF</option>
                            <option>XG</option>
                            <option>XH</option>
                            <option>XI</option>
                            <option>XJ</option>
                            <option>XK</option>
                            <option>XL</option>
                            <option>XM</option>
                            <option>XN</option>
                            <option>XIA</option>
                            <option>XIB</option>
                            <option>XIC</option>
                            <option>XID</option>
                            <option>XIE</option>
                            <option>XIF</option>
                            <option>XIG</option>
                            <option>XIH</option>
                            <option>XII</option>
                            <option>XIJ</option>
                            <option>XIK</option>
                            <option>XIL</option>
                            <option>XIM</option>
                            <option>XIIA</option>
                            <option>XIIB</option>
                            <option>XIIC</option>
                            <option>XIID</option>
                            <option>XIIE</option>
                            <option>XIIF</option>
                            <option>XIIG</option>
                            <option>XIIH</option>
                            <option>XIII</option>
                            <option>XIIJ</option>
                            <option>XIIK</option>
                            <option>XIIL</option>
                            <option>XIIM</option>
                        </select>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-6" for="absen">No. Absen</label>
                        <input type="number" class="col-md-6 form-control" id="absen" name="absen" autocomplete="on">
                    </div>
                    <div class="text-center">
                        <button id="daftar" class="btn btn-teal btn-rounded text-center">Daftar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<link href="<?php echo base_url()?>assets/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url()?>assets/plugins/bootstrap-sweetalert/sweet-alert.css" rel="stylesheet" type="text/css">

<script src="<?php echo base_url()?>assets/plugins/bootstrap-sweetalert/sweet-alert.min.js"></script>
<script src="<?php echo base_url()?>assets/plugins/datatables/datatables.min.js"></script>
<script>
    $(document).ready(function(){
        $('#tabel').DataTable({
            responsive:true,
    		columnDefs: [
    		    {
    		        "render": function ( data, type, row ) {
    		            var button1='<button id="kurangjuz" data-id="'+row[4]+'" onclick="aksi($(this).data(\'id\'),this.id)" class="btn btn-teal btn-rounded"><i class="mdi mdi-minus"></i></button>';
    		            var button2='<button id="tambahjuz" data-id="'+row[4]+'" onclick="aksi($(this).data(\'id\'),this.id)" class="btn btn-teal btn-rounded"><i class="mdi mdi-plus"></i></button>';
                        return button1+'<span class="btn">'+row[2]+'</span>'+button2;
                    },
                    "targets": 2
    		    },{
    		        "render": function ( data, type, row ) {
    		            var button1='<button id="kurangkhatam" data-id="'+row[4]+'" onclick="aksi($(this).data(\'id\'),this.id)" class="btn btn-teal btn-rounded"><i class="mdi mdi-minus"></i></button>';
    		            var button2='<button id="tambahkhatam" data-id="'+row[4]+'" onclick="aksi($(this).data(\'id\'),this.id)" class="btn btn-teal btn-rounded"><i class="mdi mdi-plus"></i></button>';
                        return button1+'<span class="btn">'+row[3]+'</span>'+button2;
                    },
                    "targets": 3
    		    },            {
                    "targets": [ 4 ],
                    "visible": false
                }]
        });
    });
    $('#baru').click(function(){
        $("#d1").hide();
        $('#d2').show();
        $('#nama').focus();
    });
    $('#batal').click(function(){
        $("#d2").hide();
        $('#d1').show();
    });
    $('#formedit').submit(function(e){
        e.preventDefault();
        swal({
        	title:"Tunggu sebentar", 
        	text:"Sedang menyimpan data. Jika terlalu lama refresh browser...",
        	type:"info",
        	showOkButton:false
    	});
    	values= $('#formedit').serialize();
		$.post("<?php echo base_url('student/tambahsiswa');?>",values,function(){
		    window.location.reload();
		});
    });
    function aksi(id,aksi){
        swal({
        	title:"Anda Yakin?", 
        	text:"Jangan mengedit milik orang lain.",
        	type:"warning",
        	showCancelButton:true,
            confirmButtonText: "Ya",
            cancelButtonText: "Batalkan!",
            closeOnConfirm: false,
    	}, function(a){
    	    swal({
            	title:"Tunggu sebentar", 
            	text:"Sedang menyimpan data. Jika terlalu lama refresh browser...",
            	type:"info",
            	showOkButton:false
        	});
    		$.get("<?php echo base_url('student/aksikhataman?aksi=');?>"+aksi+"&id="+id,function(data){
    		    if(data=='ok'){
    		        window.location.reload();
    		    }
    		});
    	});
    };
</script>