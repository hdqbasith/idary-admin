<?php
defined('BASEPATH') OR exit('No direct script access allowed');

echo dvo('panel panel-color panel-teal')
	.dvo('panel-heading')
		.heading('Detail Akun', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
	    .po('Selamat, Anda telah terdaftar sebagai calon siswa baru '.$nama_madrasah['setting_value'].' Tahun Ajaran '.$ta['setting_value'])
	    .pc()
	    .po('Silakan Anda login kembali menggunakan data sebagai berikut:')
	    .pc()
	    .heading('Username: '.$this->session->userdata('username'),3)
	    .heading('Password: ungguliptek',3)
	    .ao(base_url('login'),'LOGIN','class="btn btn-block btn-lg btn-teal"')
	    .ac()
	.dvc()
.dvc();
?>