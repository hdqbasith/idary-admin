<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$nomor=array('1'=>'01','2'=>'02','3'=>'03','4'=>'04','5'=>'05','6'=>'06','7'=>'07','8'=>'08','9'=>'09','10'=>'10','11'=>'11','12'=>'12','13'=>'13','14'=>'14','15'=>'15','16'=>'16','17'=>'17','18'=>'18','19'=>'19','20'=>'20','21'=>'21','22'=>'22','23'=>'23','24'=>'24','25'=>'25','26'=>'26','27'=>'27','28'=>'28','29'=>'29','30'=>'30','31'=>'31','32'=>'32','33'=>'33','34'=>'34','35'=>'35','36'=>'36','37'=>'37','38'=>'38','39'=>'39','40'=>'40','41'=>'41','42'=>'42','43'=>'43','44'=>'44','45'=>'45','46'=>'46','47'=>'47','48'=>'48','49'=>'49','50'=>'50','51'=>'51','52'=>'52','53'=>'53','54'=>'54','55'=>'55','56'=>'56','57'=>'57','58'=>'58','59'=>'59','60'=>'60','61'=>'61','62'=>'62','63'=>'63','64'=>'64','65'=>'65','66'=>'66','67'=>'67','68'=>'68','69'=>'69','70'=>'70','71'=>'71','72'=>'72','73'=>'73','74'=>'74','75'=>'75','76'=>'76','77'=>'77','78'=>'78','79'=>'79','80'=>'80','81'=>'81','82'=>'82','83'=>'83','84'=>'84','85'=>'85','86'=>'86','87'=>'87','88'=>'88','89'=>'89','90'=>'90','91'=>'91','92'=>'92','93'=>'93','94'=>'94','95'=>'95','96'=>'96','97'=>'97','98'=>'98','99'=>'99','100'=>'100');
shuffle($nomor);
$fl = array(
    'class'=> 'col-sm-4 control-label'
);
$fc =array(
    'class'=> 'form-control',
    'required'=>'',
    'type'=>'text',
    'autocomplete'=>'off'
);
$op['jurusan']=array(
    ''=>'',
    '1'=>'IPA',
    '2'=>'IPS',
    '3'=>'Bahasa',
    '4'=>'Keagamaan'
);
$pil_jur1=substr($pil_jur['jrssiswa'],0,1);
$pil_jur2=substr($pil_jur['jrssiswa'],1,1);
$pil_jur3=substr($pil_jur['jrssiswa'],2,1);
$pil_jur4=substr($pil_jur['jrssiswa'],3,1);

echo dvo('panel panel-color panel-teal','d0')
	.dvo('panel-heading')
		.heading('Tes Penjurusan', 4, 'class="panel-title" id="judul"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		        .po('','id="isi"')
		        .pc()
		        .'<button class="btn btn-teal" id="terus" style="float: right">Lanjut</button>';
		    echo dvc()
	    .dvc()
    .dvc()
.dvc();
echo dvo('panel panel-color panel-teal','pil_jur','display:none')
	.dvo('panel-heading')
		.heading('Pilih Jurusan', 4, 'class="panel-title" id="judul"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		        .form_open('','name="simpanjur" id="simpanjur" class="form-horizontal" style="background:white"')
    				.dvo('form-group')
    					.form_label('Pilihan Jurusan 1', 'pil_jur1', $fl)
    					.dvo('col-sm-8')
        					.form_dropdown('pil_jur1', $op['jurusan'], $pil_jur1)
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Pilihan Jurusan 2', 'pil_jur2', $fl)
    					.dvo('col-sm-8')
        					.form_dropdown('pil_jur2', $op['jurusan'], $pil_jur2)
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Pilihan Jurusan 3', 'pil_jur3', $fl)
    					.dvo('col-sm-8')
        					.form_dropdown('pil_jur3', $op['jurusan'], $pil_jur3)
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Pilihan Jurusan 4', 'pil_jur4', $fl)
    					.dvo('col-sm-8')
        					.form_dropdown('pil_jur4', $op['jurusan'], $pil_jur4)
    					.dvc()
    				.dvc()
                	.form_button('btnjur','Simpan','btn btn-rounded btn-teal waves-effect waves-light btn-lg btn-block')
                .form_close()
		        .'<button class="btn btn-teal" id="terus" onClick="lanjut()" style="float: right">Lanjut</button>';
		    echo dvc()
	    .dvc()
    .dvc()
.dvc();
?>
<div id="d2" class="col-lg-9" style="display:none">
    <div class="portlet">
        <div class="portlet-heading portlet-teal">
            <h3 class="portlet-title text-dark" id="nomor">
                Soal nomor
            </h3>
            <div class="portlet-widgets">
                <button class="btn btn-rounded btn-danger" id="pilihsoal">Pilih Soal</button>
                <!--<a data-toggle="collapse" data-parent="#accordion1" href="#soal" class="" aria-expanded="true"><button class="btn btn-inverse"><i class="ion-minus-round"></i></button></a>-->
            </div>
            <div class="clearfix"></div>
        </div>
        <div id="soal" class="panel-collapse collapse in" style="" aria-expanded="true">
            <div class="portlet-body">
                <table style="width:100%">
                    <thead>
                        <tr>
                            <th><span id="pertanyaan" style="text-transform:none;"></span></th>
                        </tr>
                    </thead>
                    <tbody style="margin-top:20px;">
                        <tr>
                            <td id="gambar"></td>
                        </tr>
                        <tr>
                            <td><p id="a" class="btn btn-block btn-rounded" style="text-align:left; margin:5px;white-space: normal;"></p></td>
                        </tr>
                        <tr>
                            <td><p id="b" class="btn btn-block btn-rounded" style="text-align:left; margin:5px;white-space: normal;"></p></td>
                        </tr>
                        <tr>
                            <td><p id="c" class="btn btn-block btn-rounded" style="text-align:left; margin:5px;white-space: normal;"></p></td>
                        </tr>
                        <tr>
                            <td><p id="d" class="btn btn-block btn-rounded" style="text-align:left; margin:5px;white-space: normal;"></p></td>
                        </tr>
                        <tr>
                            <td><p id="e" class="btn btn-block btn-rounded" style="text-align:left; margin:5px;white-space: normal;"></p></td>
                        </tr>
                    </tbody>
                </table>
                <div class="row" style="margin-top:20px;" id="navsoal">
                    <div class="col-xs-4">
                        <button id="kembali" class="btn btn-lg btn-teal btn-rounded" onclick="gantisoal(n-1)">Back</button>
                    </div>
                    <div class="col-xs-4 text-center">
                        <button id="tandai" class="btn btn-lg btn-orange btn-rounded">Tandai</button>
                    </div>
                    <div class="col-xs-4 text-right">
                        <button id="lanjut" class="btn btn-lg btn-teal btn-rounded" onclick="gantisoal(n+1)">Next</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="d3" class="col-lg-3" style="display:none">
    <div class="portlet">
        <div class="portlet-heading portlet-teal">
            <h3 class="portlet-title text-dark">
                Soal
            </h3>
            <div class="portlet-widgets">
                <!--<a data-toggle="collapse" data-parent="#accordion1" href="#listnomor" class="" aria-expanded="true"><button class="btn btn-inverse"><i class="ion-minus-round"></i></button></a>-->
            </div>
            <div class="clearfix"></div>
        </div>
        <div id="listnomor" class="panel-collapse collapse in" style="" aria-expanded="true">
            <div class="portlet-body">
                <div id="listnosoal">
                </div>
                <div style="margin-top:20px;">
                    <button id="kirim" class="btn btn-success btn-block btn-lg btn-rounded">Kirim jawaban</button>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="d4" class="col-lg-12" style="display:none">
    <div class="portlet">
        <div class="portlet-heading portlet-teal">
            <h3 class="portlet-title text-dark">
                Selesai
            </h3>
            <div class="clearfix"></div>
        </div>
        <div class="panel-collapse collapse in" style="" aria-expanded="true">
            <div class="portlet-body">
                <p></p>
            </div>
        </div>
    </div>
</div>
<div id="d5" class="col-lg-3">
    <div class="portlet">
        <div class="portlet-heading portlet-teal">
            <h3 class="portlet-title text-dark">
                Webcam
            </h3>
            <div class="clearfix"></div>
        </div>
        <div class="panel-collapse collapse in" style="" aria-expanded="true">
            <div class="portlet-body">
                <video id="dummy" width="160" height="120" autoplay></video>
            </div>
        </div>
    </div>
</div>
<link href="https://fonts.googleapis.com/css2?family=Amiri&display=swap" rel="stylesheet"> 
<script>
    var soal=[];
    var n=1;
    var jawaban=[];
    var urutan=[];
    var kirim=[];
    var mapel="TPA";
    var listmapel=<?php echo json_encode($sudahtes);?>;
    var btncolor={};
    $("#kirim").click(function(){
        if (confirm("Sudah Selesai?") == true) {
            selesai="1";
        }
        if(selesai=="1"){
            kirim[0]='';
            var i=0;
            var nilai=0;
            $.each(soal,function(){
                i++;
                kirim[urutan[i]]=jawaban[i];
                if(jawaban[i]==undefined) kirim[urutan[i]]=' ';
                if(jawaban[i]==soal[i].jawaban){
                    nilai++;
                }
            });
            var kirimjawaban='';
            i=1;
            $.each(kirim,function(){
                if(kirim[i]!=undefined) kirimjawaban+=kirim[i];
                i++;
            });
            var pelanggaran="copas "+copas+" blur "+blurred;
            $.get("<?php echo base_url("student/jawabjur?aksi=selesai&mapel="); ?>"+mapel+"&jawaban="+kirimjawaban+"&nilai="+nilai+"&pelanggaran="+pelanggaran,function(data){
                incek=8;
                btncolor[mapel]="btn-danger";
                if(Object.keys(btncolor).length=="5"){
                    incek=0;
                    $("#terus").hide();
                }
                gantidiv();
                $("#d3").hide();
                clearInterval(x);
            });
        }
    });
    $(document).ready(function(){
        if(listmapel.length>="1") {
            incek=8;
            // $("#terus").hide();
        }
        gantidiv();
        $('#pil_jur1,#pil_jur2,#pil_jur3,#pil_jur4').attr('required',true);
    });
    function getsoal(){
        $.get("<?php echo base_url("student/soal_penjurusan?mapel="); ?>"+mapel,function(data){
            soal=data;
            var btn='';
            var i=1;
            $.each(soal,function(index,value){
                urutan[i]=soal[i].nomor;
                if(i==1) btn+='<h4>'+soal[i].mapel+'</h4>';
                btn+='<button class="btn btn-inverse" onclick="gantisoal(parseInt(this.id))" style="margin:3px" id="'+i+'">'+i+'</button>';
                i++;
            });
            $("#listnosoal").html(btn);
            gantisoal(n);
        },"json");
    }
    $("#a,#b,#c,#d,#e").click(function(){
        $("#a,#b,#c,#d,#e").removeClass("btn-success").removeClass("btn-orange");
        $(this).addClass("btn-success");
        $("#"+n).removeClass("btn-inverse").removeClass("btn-orange").addClass("btn-success");
        jawaban[n]=this.id;
    });
    function gantisoal(k){
        n=k;
        if(n==1){
            $("#kembali").hide();
        } else if(n>Object.keys(soal).length){
            $("#pilihsoal").click();
        } else{
            $("#kembali").show();
            $("#lanjut").show();
        }
        $("#a,#b,#c,#d,#e").removeClass("btn-success").removeClass("btn-orange");
        $("#nomor").text("Soal nomor "+n);
        $("#pertanyaan").html(soal[n].soal);
        if(soal[n].gambar!=null) $("#gambar").html('<img style="max-width:100%" src="'+soal[n].gambar+'">');
        else $("#gambar").html("");
        $("#"+jawaban[n]).addClass("btn-success");
        if(jawaban[n]=="f") $("#a,#b,#c,#d,#e").addClass("btn-orange");
        $("#d3").hide();
        $("#d2").show();
        if (soal[n].dir == 'rtl'){
            $("#a").html("أ. "+soal[n].a).css({'text-align':'right'});
            $("#b").html("ب. "+soal[n].b).css({'text-align':'right'});
            $("#c").html("ج. "+soal[n].c).css({'text-align':'right'});
            $("#d").html("د. "+soal[n].d).css({'text-align':'right'});
            $("#e").html("هـ. "+soal[n].e).css({'text-align':'right'});
            $("th").css({'text-align':'right','direction':'rtl'});
            $("th,#a,#b,#c,#d,#e").css({'font-family': 'Amiri','font-size':'18px','line-height': '2.429'});
        } else{
            $("#a").html("a. "+soal[n].a).css({'text-align':'left'});
            $("#b").html("b. "+soal[n].b).css({'text-align':'left'});
            $("#c").html("c. "+soal[n].c).css({'text-align':'left'});
            $("#d").html("d. "+soal[n].d).css({'text-align':'left'});
            $("#e").html("e. "+soal[n].e).css({'text-align':'left'});
            $("th").css({'text-align':'left','direction':'ltr'});
            $("th,#a,#b,#c,#d,#e").css({'font-family': 'roboto','font-size':'14px','line-height': '1.429'});
            $("ar").css({'font-family': 'Amiri','font-size':'18px','line-height': '2.429','direction':'rtl'});
        }
    };
    $("#tandai").click(function(){
        $("#"+n).removeClass("btn-inverse").removeClass("btn-success").addClass("btn-orange");
        $("#a,#b,#c,#d,#e").removeClass("btn-success").addClass("btn-orange");
        jawaban[n]='f';
    });
    $("#pilihsoal").click(function(){
        $("#d2").hide();
        $("#d3").show();
    });
    window.onbeforeunload = function(e) {
        return "Yakin?";
    }
    $("#navsoal").css({
        "position": "fixed",
        "left": "0",
        "bottom": "0",
        "width": "100%",
        "z-index":"20",
        "background":"black",
        "padding":"5px"
    })
    $.each(listmapel, function(i,v){
        if(v.mapel=="TPA") btncolor["TPA"]="btn-danger";
        else if(v.mapel=="MIA") btncolor["MIA"]="btn-danger";
        else if(v.mapel=="IIS") btncolor["IIS"]="btn-danger";
        else if(v.mapel=="IIB") btncolor["IIB"]="btn-danger";
        else if(v.mapel=="IIK") btncolor["IIK"]="btn-danger";
    })
    var incek=1;
    var cek = [
        {
            judul:'Anda Sudah mengerjakan Tes Penjurusan',
            isi:'Harap menunggu dengan sabar info Hasil Tes Penjurusan dan pembagian kelas',
            klik:'lanjut()'
        },
        {
            judul:'Syarat dan tata tertib tes penjurusan',
            isi:'<ol>'
                    +'<li>Mengisi <a href="https://masterdata.adminbaru.com/student/formulir_full" class="btn btn-teal">Biodata Lengkap</a> paling lambat 14 Juli 2020</li>'
                    +'<li><b>MENGIKUTI MATSAMA SECARA PENUH DAN MENGERJAKAN TUGAS-TUGAS YANG DIBERIKAN</b></li>'
                    +'<li>Apabila ada masalah saat tes penjurusan silakan hubungi <a href="https://wa.me/6289618740940">089618740940</a> dengan format:'
                        +'<ul>'
                            +'<li>Nama: </li>'
                            +'<li>NISN: </li>'
                            +'<li>Masalah: </li>'
                        +'</ul>'
                    +'</li>'
                    +'<li>Siswa akan diberi kesempatan sekali untuk mengubah pilihan prioritas jurusannya</li>'
                    +'<li>Ada 5 paket soal, WAJIB dikerjakan SEMUANYA</li>'
                    +'<li>Ranking diambil dari rata-rata nilai 5 paket soal, dengan mempertimbangkan mapel yang sesuai jurusannya</li>'
                    +'<li>Contoh 1: Ahmad memilih jurusan IPA, nilai rata-ratanya 8,0 tapi nilai IPA-nya 3,5 maka Ahmad tidak bisa masuk jurusan IPA</li>'
                    +'<li>Contoh 2: Husain memilih jurusan Keagamaan, nilai IPA-nya 10 tapi Husain tidak mengerjakan 4 paket soal yang lain, maka Husain tidak bisa masuk jurusan Keagamaan</li>'
                    +'<li>Panitia tidak akan mentolerir segala bentuk kecurangan dan pelanggaran peraturan</li>'
                    +'<li>Hasil tes penjurusan tidak dapat diganggu gugat. Bagi yang tidak terima dengan hasil tes penjurusan JANGAN MENGIKUTI TES PENJURUSAN</li>'
                    +'<li>Silakan belajar yang rajin agar bisa belajar sesuai jurusan yang dikehendaki</li>'
                +'</ol>',
            klik:'lanjut()'
        },
        {
            judul:'Kelengkapan data',
            isi:'Saat ini kelengkapan data Anda adalah <span class="text-danger"><?php if($lengkap!=null) echo $lengkap.'. '; else echo '0%. ';?></span>'
                +'Kami sarankan Anda untuk mengecek kembali Data Lengkap Anda karena data akan dikirimkan ke pemerintah pusat.<br/>'
                +'Kelengkapan data juga menentukan hasil tes penjurusan. Silakan lengkapi jika belum...<br/>'
                +'<a href="https://masterdata.adminbaru.com/student/formulir_full" class="btn btn-teal">Biodata Lengkap</a>',
            klik:'pilih_jur()'
        },
        {
            judul:'Pilihan Jurusan',
            isi:'',
            klik:'simpan_jur()'
        },
        {
            judul:'Siap Menerima Hasil Tes',
            isi:'Apakah Anda bersedia dan ikhlas menerima hasil tes penjurusan nantinya? Jika tidak, jangan mengikuti tes penjurusan ini. Panitia tidak akan menanggapi keluhan apapun tentang hasil tes penjurusan.',
            klik:'lanjut()'
        },
        {
            judul:'Simulasi Tes Penjurusan',
            isi:'Pastikan Anda sudah memahami cara mengerjakan Tes Penjurusan. Jika belum, Anda bisa mengikuti Simulasi Tes Penjurusan lewat link berikut:<br/>'
                +'<a href="https://masterdata.adminbaru.com/student/sim_cbtppdb" class="btn btn-teal">Simulasi Tes Penjurusan</a>',
            klik:'lanjut()'
        },
        {
            judul:'Kejujuran',
            isi:'Apakah Anda siap mengerjakan Tes Penjurusan dengan jujur? '
                +'Ingatlah bahwa Allah Maha Mengetahui perbuatan kita. Kejujuran kita menunjukkan seberapa besar keimanan kita.',
            klik:'lanjut()'
        },
        {
            judul:'Token',
            isi:'Masukkan Token: <br/><input id="token"/>'
                +'<p>*Token akan dirilis di grup WA jika sudah tiba waktunya. Harap bersabar</p>',
            klik:'token()'
        },
        {
            judul:'Mapel',
            isi:'<h4>Silakan pilih mapel</h4>'
                +'<br/><button id="TPA" class="btn '+btncolor['TPA']+'" onclick="blok(this)">Tes Potensi Akademik</button>'
                +'<br/><button id="MIA" class="btn '+btncolor["MIA"]+'" onclick="blok(this)">Matematika dan Ilmu Alam</button>'
                +'<br/><button id="IIS" class="btn '+btncolor["IIS"]+'" onclick="blok(this)">Ilmu-Ilmu Sosial</button>'
                +'<br/><button id="IIB" class="btn '+btncolor["IIB"]+'" onclick="blok(this)">Ilmu Bahasa dan Budaya</button>'
                +'<br/><button id="IIK" class="btn '+btncolor["IIK"]+'" onclick="blok(this)">Ilmu-Ilmu Keagamaan</button>',
            klik:'mulaites()'
        }
    ];
    function gantidiv(){
        $("#pil_jur").hide();
        $("#d0").show();
        $("#judul").text(cek[incek].judul);
        $("#isi").html(cek[incek].isi);
        $("#terus").attr("onclick",cek[incek].klik);
    }
    function lanjut(){
        incek++;
        gantidiv();
    }
    function pilih_jur(){
        $("#d0").hide();
        $("#pil_jur").show();
        incek++;
    }
    function token(){
        if($("#token").val()=="ANTIWAHN"){
            lanjut();
        } else{
            alert("Token keliru!!!")
        }
    }
    function blok(id){
        $("#TPA,#MIA,#IIS,#IIB,#IIK").removeClass('btn-teal');
        $(id).addClass('btn-teal');
        mapel=$(id).attr('id');
    }
    var menu=$(".navbar-right").html();
    var x;
    function mulaites(){
        $.get("<?php echo base_url('student/cekmapel?mapel=');?>"+mapel,function(a){
            if(a!=mapel){
                $.get("<?php echo base_url('student/jawabjur?aksi=mulai&mapel='); ?>"+mapel,function(data){
                    if(data=="gagal"){
                        alert('Anda sudah pernah mengerjakan atau waktu Anda sudah habis!!!');
                    } else{
                        $("#d0").hide();
                        $("#d2").show();
                        getsoal();
                        var waktu=JSON.parse(data);
                        J=0;
                        M=waktu.m;
                        D=waktu.d;
                        var countdown='<li><a href="#"><h4 class="text-orange" id="countdown"></h4></a></li>';
                        $(".navbar-right").html(countdown+menu);
                        x = setInterval(function() {
                            D--;
                            if(D==-1) {
                                D=59;
                                M--;
                            };
                            if(M==-1) {
                                M=59;
                                J--;
                            };
                            var A='',B='';
                            if(D<10) A="0";
                            if(M<10) B="0";
                            $("#countdown").html(J+":"+B+M+":"+A+D);
                            if(D==0 && M==0 && J==0) {
                                selesai="1";
                                $("#kirim").click();
                            }
                        }, 1000);
                    }
                })
            } else{
                alert("Anda sudah mengerjakan soal ini");
                $(mapel).attr("disabled",true);
            }
        })
    }
    $('#pil_jur1').on('change',function(){
        $('#pil_jur2,#pil_jur3,#pil_jur4').prop('selectedIndex',0);
        $('#pil_jur2 option,#pil_jur3 option,#pil_jur4 option').show();
        $('#pil_jur2 option[value="'+$(this).val()+'"]').hide();
        $('#pil_jur3 option[value="'+$(this).val()+'"]').hide();
        $('#pil_jur4 option[value="'+$(this).val()+'"]').hide();
    });
    $('#pil_jur2').on('change',function(){
        $('#pil_jur3,#pil_jur4').prop('selectedIndex',0);
        $('#pil_jur3 option,#pil_jur4 option').show();
        $('#pil_jur3 option[value="'+$('#pil_jur1').val()+'"]').hide();
        $('#pil_jur3 option[value="'+$(this).val()+'"]').hide();
        $('#pil_jur4 option[value="'+$(this).val()+'"]').hide();
    });
    $('#pil_jur3').on('change',function(){
        $('#pil_jur4').prop('selectedIndex',0);
        $('#pil_jur4 option').show();
        $('#pil_jur4 option[value="'+$('#pil_jur1').val()+'"]').hide();
        $('#pil_jur4 option[value="'+$('#pil_jur2').val()+'"]').hide();
        $('#pil_jur4 option[value="'+$(this).val()+'"]').hide();
    });
    $("#simpanjur").submit(function(e){
        e.preventDefault();
        values=$("#pil_jur1").val()+$("#pil_jur2").val()+$("#pil_jur3").val()+$("#pil_jur4").val();
        $.get("<?php echo base_url('student/simpanjur?pil_jur=');?>"+values,function(){
            alert("Anda berhasil mengubah prioritas pilihan jurusan Anda");
            $('#pil_jur1,#pil_jur2,#pil_jur3,#pil_jur4').attr('disabled',true);
            $("#btnjur").hide();
        })
    })
    var blurred = 0;
    var copas = 0;
    window.onblur = function() {
        blurred++;
    };
    $(document).bind('copy', function(e) {
        copas++;
    });
    var video = document.getElementById('dummy');
    var localstream;
    if(navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        navigator.mediaDevices.getUserMedia({ video: true }).then(function(stream) {
            localstream=stream;
            video.srcObject = stream;
            video.play();
        });
    }
</script>