<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$nama=$this->session->userdata('fullname');
if($diterima['kelasmts']!=null) redirect(base_url('student/index'));
echo $diterima['kelasmts'];
?>

<div id="d2" >
    <div class="col-lg-12">
        <div class="portlet">
            <div class="portlet-heading bg-teal">
                <h3 class="portlet-title">
                    PENGUMUMAN HASIL TES SELEKSI PPDB
                </h3>
                <div class="clearfix"></div>
            </div>
            <div id="bg-teal" class="panel-collapse collapse in">
                <div class="portlet-body">
                    <h4>Surat Keterangan Hasil Tes Seleksi PPDB dapat didownload melalui link berikut:</h4>
                    <a href="<?php echo base_url('student/hasiltespdf')?>" class="btn btn-success btn-block">Download hasil Tes Seleksi</a>
                    <br/>
                    <ul>Her Registrasi / Daftar Ulang dilaksanakan pada :
                        <li><b>Hari</b> : Senin - Ahad</li>
                        <li><b>Tanggal</b> : 29 Juni – 5 Juli 2020 M</li>
                        <li><b>Pukul</b> : 08.00 - 11.00</li>
                        <li><b>Tempat</b> : Musholla Gedung Barat MA NU TBS Kudus</li>
                    </ul>
                    Peserta yang belum daftar ulang setelah tanggal tersebut dianggap mengundurkan diri.
                    <br/>Informasi lengkap her registrasi dapat dilihat di link berikut:
                    <a href="https://drive.google.com/file/d/1KVt-rG0f46WR7QLDwhWp9n_aCiB3CMVB/view?usp=sharing" class="btn btn-success btn-block" target="_blamk">Informasi Her Registrasi</a>
                </div>
            </div>
        </div>
    </div>
</div>