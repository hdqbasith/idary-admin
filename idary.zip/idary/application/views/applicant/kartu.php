<?php
defined('BASEPATH') OR exit('No direct script access allowed');
setlocale(LC_ALL, 'id-ID', 'id_ID');
$aslsb="MTs NU TBS Kudus";
if($ppdb['kelasmts']==null) $aslsb=$ppdb['aslsb'];
else if($ppdb['kelasmts']=="MPA") $aslsb="MPA NU TBS Kudus";

echo dvo('panel panel-color panel-teal','d1')
	.dvo('panel-heading d-print-none')
		.heading('Kartu Tes Seleksi PPDB', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		        .'<img src="https://1.bp.blogspot.com/-37B3PpkOkfk/Xs45Ia019iI/AAAAAAAANIw/HKGN3FbU9uA1UXGzRc8acTW9UPk3Il7cACLcBGAsYHQ/s1600/logo-tbs-ikon.png" style="position:absolute; z-index:1; margin:15px 0 0 15px;width:75px">'
		        .tableo('kartu','','width:100%; border-collapse: separate; border-spacing: 15px;')
    		        .theado()
    		            .tro()
    		                .th('Kartu Tes Seleksi<br/>Penerimaan Peserta Didik Baru<br/>'.$nama_madrasah['setting_value'].'<br/>Tahun Ajaran '.$ta['setting_value'],'colspan=2 class="text-center" style="border:none; border-bottom: solid 1px black; background-color:white; color:black;"')
    		            .trc()
                    .theadc()
                    .tbodyo()
    		            .tro()
    		                .td('No. Registrasi')
    		                .td(': '.$reg_code['setting_value'].sprintf('%03d',$ppdb['id']))
    		            .trc()
    		            .tro()
    		                .td('Nama')
    		                .td(': '.$ppdb['namasiswa'])
    		            .trc()
    		            .tro()
    		                .td('NISN')
    		                .td(': '.$ppdb['nisn'])
    		            .trc()
    		            .tro()
    		                .td('Alamat')
    		                .td(': '.$ppdb['almlengkap'])
    		            .trc()
    		            .tro()
    		                .td('TTL')
    		                .td(': '.$ppdb['ttlsiswa'].", ".strftime("%d %B %Y",strtotime($ppdb['tglsiswa'])))
    		            .trc()
    		            .tro()
    		                .td('Asal Sekolah')
    		                .td(': '.$aslsb)
    		            .trc()
    		            .tro()
    		                .td('Waktu Tes Lisan')
    		                .td(': '.$tes_lisan['setting_value'])
    		            .trc()
    		            .tro()
    		                .td('Waktu Tes Tulis')
    		                .td(': '.$tes_tulis['setting_value'])
    		            .trc()
                    .tbodyc()
		        .tablec()
		        .'<div style="width:3cm; height:4cm; position:absolute; right:25px; margin-top:-190px; border:1px solid;" class="text-center">
                    <br/><br/><br/>Foto 3x4<br/>berpeci
                    </div>'
		    .dvc()
	    .dvc()
    .dvc()
.dvc()
.dvo('d-print-none')
    .$petunjuk['setting_value']
.dvc()
;

?>

<script>
    if("<?php echo $ppdb['kelasmts']; ?>" == "") $("#d2").show();
    else $("#d1").show();
    
    $(document).ready(function(){
        $("td").css("border","none");
        $("table").css("border","1pt black solid");
        $(".page-title").text("Kartu Tes Seleksi PPDB");
        $("#judul_hlm").text("Kartu Tes");
    });
</script>