<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>
<table id="list" class="table">
    <thead>
        <tr>
            <th>NISN</th>
            <th>Nama</th>
        </tr>
    </thead>
    <tbody id="bt">
        
    </tbody>
</table>
<link href="<?php echo base_url()?>assets/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url()?>assets/plugins/datatables/datatables.min.js"></script>
<script>
    $(document).ready(function(){
        var data=<?php echo $nisn;?>;
        var table='';
        $.each(data,function(index,value){
            table+="<tr><td>"+this.nisn+"</td><td>"+this.nama+"</td></tr>";
        })
        $("#bt").html(table);
        $('#list').DataTable({
            responsive:true
        });
    });
</script>