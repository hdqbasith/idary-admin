<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$fl = array(
  'class'=> 'col-sm-4 control-label'
);
$fc =array(
    'class'=> 'form-control',
    'type'=>'text',
    'autocomplete'=>'off'
);
$fr =array(
    'class'=> 'form-control',
    'required'=>'',
    'readonly'=>'',
    'type'=>'text',
    'autocomplete'=>'off'
);
echo '<a href="'.base_url('student/daftarmapel').'" class="btn btn-lg btn-danger btn-rounded">Kembali</a>';
echo dvo('panel panel-color panel-teal','d0')
	.dvo('panel-heading')
		.heading($audio['tema'], 4, 'class="panel-title" id="judul"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
    		    .dvo('col-md-12','vid')
        		    .'<iframe id="player" width="100%" src="https://www.youtube.com/embed/'.$audio['link'].'?enablejsapi=1&vq=tiny" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>'
        		    .'<p id="display">Silakan putar audio di atas dan klik tombol di bawah setelah selesai menonton</p>'
    		    .dvc()
    	    .dvc()
    	    .dvo('col-md-12')
	            .$audio['isi']
    	        .form_open(base_url('cekjs'),'name="form" id="form" class="form-horizontal" style="background:white; border-top: 3px solid; margin-top:50px"')
    				.dvo('form-group')
    					.form_label('Materi', 'materi', $fl)
    					.dvo('col-sm-8')
    						.form_dropdown('materi', array($audio['id']=>$audio['tema']),$id)
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Persentase mendengarkan', 'persen', $fl)
    					.dvo('col-sm-8')
    						.form_input('persen', $audio['persen'], $fr)
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Jawaban', 'notif_content', $fl)
    					.dvo('col-sm-8')
    						.form_textarea('notif_content', $audio['notif_content'], $fc)
    					.dvc()
    				.dvc();
                	if($audio['persen']!='100%') echo form_button('simpan','Simpan','btn btn-rounded btn-teal waves-effect waves-light btn-lg btn-block');
                	else echo '<h4 class="text-danger">Anda sudah menonton video ini 100%. Jangan mengeklik tombol simpan lagi karena bisa mengubah persentase mendengarkan.</h4>'.form_button('simpan','Simpan','btn btn-rounded btn-teal waves-effect waves-light btn-lg btn-block')
                .form_close();
		    echo dvc()
	    .dvc()
    .dvc()
.dvc();
echo JS_SWAL.JS_TOAST;
?>

<link href="https://fonts.googleapis.com/css2?family=Amiri&display=swap" rel="stylesheet"> 
<script src="https://www.youtube.com/iframe_api"></script>
<script>
    $(document).ready(function(){
        values = $("#form").serialize();
        $.post("<?php  echo base_url('student/audio'); ?>",values);
        $("ar").parent().css({'font-family': 'Amiri','font-size':'18px','line-height': '2.429','direction':'rtl'});
    })
    $("#form").on("submit",function(e){
        e.preventDefault();
        var values = $(this).serialize();
        swal({
        	title:"Menyimpan...", 
        	text:"Mohon tunggu sebentar. Jika tidak ada notifikasi sukses, silakan coba lagi",
        	type:"warning",
        	timer: 10000,
        	showConfirmButton:false,
        	closeOnCancel: false
    	});
        $.post("<?php  echo base_url('student/audio'); ?>",values,function(data){
            swal.close();
            toastr.success('Data berhasil disimpan', 'Sukses!');
        })
    });
    var player, timer, timeSpent = [], display = document.getElementById('display');

    function onYouTubeIframeAPIReady() {
    	player = new YT.Player( 'player', {
    		events: { 'onStateChange': onPlayerStateChange }
    	});
    }
    
    function onPlayerStateChange(event) {
    	if(event.data === 1) { // Started playing
            if(!timeSpent.length){
                for(var i=0, l=parseInt(player.getDuration()); i<l; i++) timeSpent.push(false);
            }
    	    timer = setInterval(record,100);
        } else {
    		clearInterval(timer);
    	}
    }
    
    function record(){
    	timeSpent[ parseInt(player.getCurrentTime()) ] = true;
    	showPercentage();
    }
    
    function showPercentage(){
        var percent = 0;
        for(var i=0, l=timeSpent.length; i<l; i++){
            if(timeSpent[i]) percent++;
        }
        percent = Math.round(percent / timeSpent.length * 100);
        display.innerHTML = "Anda telah menonton video ini sebanyak <span class=\"btn btn-teal\">"+percent + "%</span>";
        $("#persen").val(percent + "%");
    }
    $(document).on("visibilitychange", function() {
      if ( player ) {
        if ( document.hidden ) {
          player.pauseVideo();
        } else {
          player.playVideo();
        }
      }
    });
</script>