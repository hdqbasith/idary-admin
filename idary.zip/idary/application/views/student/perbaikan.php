<?php
defined('BASEPATH') OR exit('No direct script access allowed');
echo dvo('panel panel-color panel-teal','d99')
	.dvo('panel-heading')
		.heading('PENGUMUMAN', 4, 'class="panel-title" id="judul"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		        .'<h4>PENGUMUMAN PENTING</h4>
                <p>Mengharap dengan hormat atas kehadiran siswa kelas X MA NU TBS Kudus pada:</p>
                <ul><h4>Hari/Tanggal :</h4>
                	<li>Selasa, 4 Agustus 2020 (Kelas X A-D)</li>
                	<li>Rabu, 5 Agustus 2020 (Kelas X E-H)</li>
                	<li>Kamis, 6 Agustus 2020 (Kelas X I-L)</li>
                	<li>Sabtu, 8 Agustus 2020 (Kelas X M-N)</li>
                <h4>Pukul :</h4> 08.00 - 10.00 WIBB
                <br/><h4>Tempat :</h4> Lab Komputer Lt. 3 Gedung Timur
                <br/><h4>Acara :</h4>
                <li>Melengkapi biodata siswa</li>
                <li>Melengkapi berkas pendaftaran siswa</li>
                <li>Pengambilan foto siswa baru</li>
                <h4>Keterangan:</h4>
                <li>Wajib memakai masker</li>
                <li>Membawa baju seragam putih (dimasukkan tas, jangan dipakai)</li>
                <li>KBM daring insya’allah tetap berjalan</li>
                <li>Bagi yang tidak bisa hadir silakan menghubungi admin (089618740940) dengan format
                	<ul><li>Nama:</li>
                	<li>NISN:</li>
                	<li>Alasan tidak bisa hadir:</li></ul></li></ul>
                <p>Demikian undangan kami, atas perhatian dan kehadirannya kami sampaikan terima kasih.</p>
                
                <br/><br/>ttd
                
                <br/><br/>Admin MA NU TBS Kudus
                ';
		    echo dvc()
	    .dvc()
    .dvc()
.dvc();
?>