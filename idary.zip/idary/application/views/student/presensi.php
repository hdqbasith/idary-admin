<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$data['Nama']=$presensi[0]['nama_lengkap'];
$data['Kelas']=$presensi[0]['kelas'];
$data['Absen']=$presensi[0]['absen'];
$data['Pondok']=$presensi[0]['nama'];
if($data['Pondok']=='lainnya') $data['Pondok']='Pondok selain MOU';


echo dvo('panel panel-color panel-teal','d1')
	.dvo('panel-heading')
		.heading('Presensi KBM Daring', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		        .'<ul>';
		        foreach($data as $k=>$v){
		            echo '<li><b>'.$k.'</b> : '.$v.'</li>';
		        }
		        echo '</ul>'
		        .tableo('list','','width=100%')
    		        .theado()
    		            .tro()
    		                .th('Tanggal')
    		                .th('Pelajaran')
    		                .th('Guru Pengampu')
    		                .th('Tema')
    		                .th('Jawaban/Ringkasan')
    		                .th('Keterangan')
    		            .trc()
                    .theadc()
                    .tbodyo()
                    .tbodyc()
		        .tablec()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();
echo JS_SWAL;
?>

<link href="<?php echo base_url()?>assets/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url()?>assets/plugins/datatables/datatables.min.js"></script>

<script>
    $(document).ready(function(){
        $("table").DataTable({
            scrollX:true,
        });
    });
    var presensi=<?php echo json_encode($presensi);?>;
    var table='';
    $.each(presensi,function(i,v){
        if(v.notif_content==null) v.notif_content="-";
        table+="<tr><td>"+v.notif_date+"</td><td>"+v.pelajaran+"</td><td>"+v.guru+"</td><td>"+v.tema+"</td><td>"+v.notif_content+"</td><td>"+v.notif_status+"</td></tr>";
    })
    $("#list tbody").html(table);
    
    function swall(){
	    swal({
        	title:"Mengalihkan...", 
        	text:"Mohon tunggu sebentar. Jika halaman tidak dialihkan, silakan coba lagi",
        	type:"info",
        	timer: 2000,
        	showConfirmButton:false,
        	closeOnCancel: false,
    	});
    }
</script>