<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$student_id=$biodata['student_id'];
$master_province_id=$biodata['master_province_id'];
$master_regency_id=$biodata['master_regency_id'];
$master_district_id=$biodata['master_district_id'];
$master_village_id=$biodata['master_village_id'];
$student_nisn=$biodata['student_nisn'];
$student_nis=$biodata['student_nis'];
$student_name=$biodata['student_name'];
$student_place_of_birth=$biodata['student_place_of_birth'];
$student_date_of_birth=date('d/m/Y',strtotime($biodata['student_date_of_birth']));
$student_address=$biodata['student_address'];
$student_postal_code=$biodata['student_postal_code'];
$student_phone=$biodata['student_phone'];
$student_email=$biodata['student_email'];
$student_from_school=$biodata['student_from_school'];
$student_from_class=$biodata['student_from_class'];
$student_from_date=$biodata['student_from_date'];
$student_family_status=$biodata['student_family_status'];
$student_family_grade=$biodata['student_family_grade'];
$student_father_name=$biodata['student_father_name'];
$student_father_nik=$biodata['student_father_nik'];
$student_father_date_of_birth=date('d/m/Y',strtotime($biodata['student_father_date_of_birth']));
$student_father_educational_level=$biodata['student_father_educational_level'];
$student_father_occupation=$biodata['student_father_occupation'];
$student_father_phone=$biodata['student_father_phone'];
$student_mother_nik=$biodata['student_mother_nik'];
$student_mother_name=$biodata['student_mother_name'];
$student_mother_date_of_birth=date('d/m/Y',strtotime($biodata['student_mother_date_of_birth']));
$student_mother_educational_level=$biodata['student_mother_educational_level'];
$student_mother_occupation=$biodata['student_mother_occupation'];
$student_mother_phone=$biodata['student_mother_phone'];
$student_guardian_nik=$biodata['student_guardian_nik'];
$student_guardian_name=$biodata['student_guardian_name'];
$student_guardian_date_of_birth=date('d/m/Y',strtotime($biodata['student_guardian_date_of_birth']));
$student_guardian_educational_level=$biodata['student_guardian_educational_level'];
$student_guardian_occupation=$biodata['student_guardian_occupation'];
$student_guardian_phone=$biodata['student_guardian_phone'];

$opditerima=array(
    '2019-07-14'=>'14-07-2019',
    '2018-07-15'=>'15-07-2018',
    '2017-07-16'=>'16-07-2017'
);
$opstatus=array(
    'anak kandung'=>'Anak Kandung',
    'anak tiri'=>'Anak Tiri',
    'anak angkat'=>'Anak Angkat'
);
$oppdd=array(
    'TK'=>'TK',
    'SD'=>'SD',
    'SMP'=>'SMP',
    'SMA'=>'SMA',
    'D1'=>'D1',
    'D2'=>'D2',
    'D3'=>'D3',
    'D4'=>'D4',
    'S1'=>'S1',
    'S2'=>'S2',
    'S3'=>'S3'
);



$this->load->helper('form');
$this->load->helper('html');
$fn = array(
  'class'=> 'form-control',
  'type' => 'number',
  'autocomplete' => 'off'
);
$ft = array(
  'class'=> 'form-control',
  'type' => 'text',
  'autocomplete' => 'off'
);
$fl = array(
  'class'=> 'col-sm-4 control-label'
);
$fd = array(
  'class'=> 'datepicker form-control',
  'placeholder' => 'tanggal',
  'autocomplete' => 'off',
  'required' => ''
);

$fnd = array(
  'class'=> 'form-control',
  'type' => 'number',
  'step' => '0.01',
  'autocomplete' => 'off',
  'required' => ''
);
$fnr = array(
  'class'=> 'form-control',
  'type' => 'number',
  'autocomplete' => 'off',
  'required' => ''
);
$ftr = array(
  'class'=> 'form-control',
  'type' => 'text',
  'autocomplete' => 'off',
  'required' => ''
);

echo form_button('kembali','Kembali','btn btn-rounded btn-danger waves-effect waves-light btn-lg')
    .heading('Gunakanlah huruf besar di "Awal Kata", "JANGAN SEMUA HURUF"',3,'');
echo form_open('fungsiard/tes','name="formedit" id="formedit" class="form-horizontal"')
	.dvo('panel panel-color panel-purple')
		.dvo('panel-heading')
			.heading('Data Pribadi', 4, 'class="panel-title"')
		.dvc()

		.dvo('panel-body')
			.dvo('row')
				.dvo('col-md-6','','border-right: 2px solid lightgrey')
				
					.dvo('form-group')
						.form_label('NISN', 'student_nisn', $fl)
						.dvo('col-sm-8')
							.form_input('student_nisn', $student_nisn, 'class="form-control"')
							.form_input('student_id', $student_id, 'class="form-control" style="display:none;"')
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('NIS', 'student_nis', $fl)
						.dvo('col-sm-8')
							.form_input('student_nis', $student_nis, 'class="form-control" readonly')
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('Nama Lengkap', 'student_name', $fl)
						.dvo('col-sm-8')
							.form_input('student_name', $student_name, 'class="form-control"')
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('Tempat Lahir', 'student_place_of_birth', $fl)
						.dvo('col-sm-8')
							.form_input('student_place_of_birth', $student_place_of_birth, 'class="form-control"')
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('Tanggal Lahir', 'student_date_of_birth', $fl)
						.dvo('col-sm-8')
							.form_input('student_date_of_birth', $student_date_of_birth, $fd)
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('Alamat Lengkap', 'student_address', $fl)
						.dvo('col-sm-8')
							.form_input('student_address', $student_address, 'class="form-control"')
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('Kode Pos', 'student_postal_code', $fl)
						.dvo('col-sm-8')
							.form_input('student_postal_code', $student_postal_code, 'class="form-control"')
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('No. HP', 'student_phone', $fl)
						.dvo('col-sm-8')
							.form_input('student_phone', $student_phone, 'class="form-control"')
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('Email', 'student_email', $fl)
						.dvo('col-sm-8')
							.form_input('student_email', $student_email, 'class="form-control"')
						.dvc()
					.dvc() 

                .dvc()
				.dvo('col-md-6','','border-right: 2px solid lightgrey')
					.dvo('form-group')
						.form_label('Provinsi', 'master_province_id', $fl)
						.dvo('col-sm-8')
							.form_dropdown('master_province_id', $provinsi, $master_province_id)
						.dvc()
					.dvc() 
					.dvo('form-group')
						.form_label('Kabupaten', 'master_regency_id', $fl)
						.dvo('col-sm-8')
							.form_dropdown('master_regency_id', $kabupaten, $master_regency_id)
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('Kecamatan', 'master_district_id', $fl)
						.dvo('col-sm-8')
							.form_dropdown('master_district_id', $kecamatan, $master_district_id)
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('Desa', 'master_village_id', $fl)
						.dvo('col-sm-8')
							.form_dropdown('master_village_id', $desa, $master_village_id)
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('Asal Sekolah', 'student_from_school', $fl)
						.dvo('col-sm-8')
							.form_input('student_from_school', $student_from_school, 'class="form-control"')
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('Diterima kelas', 'student_from_class', $fl)
						.dvo('col-sm-8')
							.form_input('student_from_class', '10', 'readonly class="form-control"')
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('Pada Tanggal', 'student_from_date', $fl)
						.dvo('col-sm-8')
							.form_dropdown('student_from_date', $opditerima, $student_from_date)
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('Status', 'student_family_status', $fl)
						.dvo('col-sm-8')
							.form_dropdown('student_family_status', $opstatus, $student_family_status)
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('Anak ke-', 'student_family_grade', $fl)
						.dvo('col-sm-8')
							.form_input('student_family_grade', $student_family_grade, 'class="form-control"')
						.dvc()
					.dvc() 

				.dvc()
			.dvc()
		.dvc()
	.dvc()
	.dvo('panel panel-color panel-purple')
		.dvo('panel-heading')
			.heading('Data Orang Tua dan Wali', 4, 'class="panel-title"')
		.dvc()

		.dvo('panel-body')
			.dvo('row')
			.heading('Ayah', 4, '')
				.dvo('col-md-6','','border-right: 2px solid lightgrey')

					.dvo('form-group')
						.form_label('NIK Ayah', 'student_father_nik', $fl)
						.dvo('col-sm-8')
							.form_input('student_father_nik', $student_father_nik, 'class="form-control"')
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('Nama Ayah', 'student_father_name', $fl)
						.dvo('col-sm-8')
							.form_input('student_father_name', $student_father_name, 'class="form-control"')
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('Tanggal Lahir Ayah', 'student_father_date_of_birth', $fl)
						.dvo('col-sm-8')
							.form_input('student_father_date_of_birth', $student_father_date_of_birth, $fd)
						.dvc()
					.dvc() 

                .dvc()
				.dvo('col-md-6','','border-right: 2px solid lightgrey')
					.dvo('form-group')
						.form_label('Pendidikan Ayah', 'student_father_educational_level', $fl)
						.dvo('col-sm-8')
							.form_dropdown('student_father_educational_level', $oppdd, $student_father_educational_level)
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('Pekerjaan Ayah', 'student_father_occupation', $fl)
						.dvo('col-sm-8')
							.form_input('student_father_occupation', $student_father_occupation, 'class="form-control"')
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('No. HP Ayah', 'student_father_phone', $fl)
						.dvo('col-sm-8')
							.form_input('student_father_phone', $student_father_phone, 'class="form-control"')
						.dvc()
					.dvc() 
				.dvc()
            .dvc()
			.dvo('row')
			.heading('Ibu', 4, '')
				.dvo('col-md-6','','border-right: 2px solid lightgrey')
					.dvo('form-group')
						.form_label('NIK Ibu', 'student_mother_nik', $fl)
						.dvo('col-sm-8')
							.form_input('student_mother_nik', $student_mother_nik, 'class="form-control"')
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('Nama Ibu', 'student_mother_name', $fl)
						.dvo('col-sm-8')
							.form_input('student_mother_name', $student_mother_name, 'class="form-control"')
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('Tanggal Lahir Ibu', 'student_mother_date_of_birth', $fl)
						.dvo('col-sm-8')
							.form_input('student_mother_date_of_birth', $student_mother_date_of_birth, $fd)
						.dvc()
					.dvc() 

                .dvc()
				.dvo('col-md-6','','border-right: 2px solid lightgrey')
					.dvo('form-group')
						.form_label('Pendidikan Ibu', 'student_mother_educational_level', $fl)
						.dvo('col-sm-8')
							.form_dropdown('student_mother_educational_level', $oppdd, $student_mother_educational_level)
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('Pekerjaan Ibu', 'student_mother_occupation', $fl)
						.dvo('col-sm-8')
							.form_input('student_mother_occupation', $student_mother_occupation, 'class="form-control"')
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('No. HP Ibu', 'student_mother_phone', $fl)
						.dvo('col-sm-8')
							.form_input('student_mother_phone', $student_mother_phone, 'class="form-control"')
						.dvc()
					.dvc() 
				.dvc()
            .dvc()
			.dvo('row')
			.heading('Wali', 4, '')
				.dvo('col-md-6','','border-right: 2px solid lightgrey')
					.dvo('form-group')
						.form_label('NIK Wali', 'student_guardian_nik', $fl)
						.dvo('col-sm-8')
							.form_input('student_guardian_nik', $student_guardian_nik, 'class="form-control"')
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('Nama Wali', 'student_guardian_name', $fl)
						.dvo('col-sm-8')
							.form_input('student_guardian_name', $student_guardian_name, 'class="form-control"')
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('Tanggal Lahir Wali', 'student_guardian_date_of_birth', $fl)
						.dvo('col-sm-8')
							.form_input('student_guardian_date_of_birth', $student_guardian_date_of_birth, $fd)
						.dvc()
					.dvc() 

                .dvc()
				.dvo('col-md-6','','border-right: 2px solid lightgrey')
					.dvo('form-group')
						.form_label('Pendidikan Wali', 'student_guardian_educational_level', $fl)
						.dvo('col-sm-8')
							.form_dropdown('student_guardian_educational_level', $oppdd, $student_guardian_educational_level)
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('Pekerjaan Wali', 'student_guardian_occupation', $fl)
						.dvo('col-sm-8')
							.form_input('student_guardian_occupation', $student_guardian_occupation, 'class="form-control"')
						.dvc()
					.dvc() 

					.dvo('form-group')
						.form_label('No. HP Wali', 'student_guardian_phone', $fl)
						.dvo('col-sm-8')
							.form_input('student_guardian_phone', $student_guardian_phone, 'class="form-control"')
						.dvc()
					.dvc() 
				.dvc()
			.dvc()
		.dvc()
	.dvc()
	.form_button('simpan','Simpan','btn btn-rounded btn-orange waves-effect waves-light btn-lg btn-block')
.form_close();
echo JS_SWAL;
?>

<link href="<?php echo base_url()?>assets/plugins/datepicker/bootstrap-datepicker.min.css" rel="stylesheet">
<script src="<?php echo base_url()?>assets/plugins/datepicker/bootstrap-datepicker.min.js"></script>
<script>
$(document).ready(function() {
	$('#formedit').submit(function(e) {
        e.preventDefault();
		document.getElementById("student_date_of_birth").value =  document.getElementById("student_date_of_birth").value.split("/").reverse().join("/");
		document.getElementById("student_father_date_of_birth").value =  document.getElementById("student_father_date_of_birth").value.split("/").reverse().join("/");
		document.getElementById("student_mother_date_of_birth").value =  document.getElementById("student_mother_date_of_birth").value.split("/").reverse().join("/");
		document.getElementById("student_guardian_date_of_birth").value =  document.getElementById("student_guardian_date_of_birth").value.split("/").reverse().join("/");
		values = jQuery("#formedit").serialize();
        // alert(values);
        swal({
        	title:"Anda Yakin?", 
        	text:"Anda hanya punya 2 kesempatan untuk mengedit data.",
        	type:"warning",
        	showCancelButton: true,
    	},function(){
    	    $.post("<?php  echo site_url('fungsiard/simpandata'); ?>",values,function(data){
                if(data=="simpan"){
                    swal({
                    	title:"Berhasil", 
                    	text:"Data Anda telah disimpan",
                    	type:"success"
                	},function(){
                	    window.location.href="<?php echo site_url('ard'); ?>";
                	});
                }else{
                    swal("Maaf...", "Anda sudah mengedit data Anda 2 kali.\nSilakan hubungi Bapak Muhammad Fahmil Huda jika hendak mengubah data Anda.\n Terima kasih...", "error");
                }
            });
    	});
        
		document.getElementById("student_date_of_birth").value =  document.getElementById("student_date_of_birth").value.split("/").reverse().join("/");
		document.getElementById("student_father_date_of_birth").value =  document.getElementById("student_father_date_of_birth").value.split("/").reverse().join("/");
		document.getElementById("student_mother_date_of_birth").value =  document.getElementById("student_mother_date_of_birth").value.split("/").reverse().join("/");
		document.getElementById("student_guardian_date_of_birth").value =  document.getElementById("student_guardian_date_of_birth").value.split("/").reverse().join("/");
    });

});
$('.datepicker').datepicker({
	format: "dd/mm/yyyy",
	startView: 'years',
	autoclose: 'true',
});


//--------------- fungsi perubahan daerah --------------------
$("#master_province_id").change(function(){
	$.ajax({
		type: "POST",
		data: { master_province_id : $("#master_province_id").val() },
		url: "<?php echo base_url();?>fungsiard/kab",
		success: function(data){
	        //alert(data);
     		$("#master_regency_id").html(data);
            $('#master_regency_id').trigger('change');
     		$("#master_village_id").val('');
    	}
    })
});
$("#master_regency_id").change(function(){
	$.ajax({
		type: "POST",
		data: { master_regency_id : $("#master_regency_id").val() },
		url: "<?php echo base_url();?>fungsiard/kec",
		success: function(data){
	       // alert(data);
     		$("#master_district_id").html(data);
            $('#master_district_id').trigger('change');
    	}
    })
});
$("#master_district_id").change(function(){
	$.ajax({
		type: "POST",
		data: { master_district_id : $("#master_district_id").val() },
		url: "<?php echo base_url();?>fungsiard/des",
		success: function(data){
	        //alert(data);
     		$("#master_village_id").html(data);
    	}
    })
});
//------------------------END--------------------------
$("#kembali").click(function(){
   window.history.back();
});
</script>