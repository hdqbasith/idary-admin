<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$aturan=array(
    'Tabel di bawah menunjukkan daftar mapel yang sudah Anda ajukan susulan',
    'Jika mapel yang Anda cari tidak ada, berarti pengajuan Anda belum diterima oleh Admin atau pengajuan Anda tidak sesuai format yang disediakan',
    'Silakan kerjakan sebelum pukul 20.00',
    'Manfaatkan kesempatan ini dengan baik, karena kesempatan tidak selamanya datang dua kali',
    'Selamat belajar, selamat mengerjakan, semoga Anda mendapatkan ilmu yang barokah dan bermanfaat'
	);
echo dvo('panel panel-color panel-orange','d0')
	.dvo('panel-heading')
		.heading('Susulan Penilaian Akhir Semester Gasal 2020', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
    		    .po('Silakan baca dan pahami baik-baik peraturan Susulan Penilaian Akhir Semester Gasal 2020 berikut.')
    		    .ul($aturan)
    		    .pc()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();
echo dvo('panel panel-color panel-teal','d1')
	.dvo('panel-heading')
        .heading('Daftar Mapel PAS Susulan yang Anda Ajukan', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
                .tableo('list','','width=100%')
                    .theado()
                        .tro()
                            .th('Kelas')
                            .th('Mapel')
                            .th('Token')
                            .th('Link')
                            .th('Status')
                        .trc()
                    .theadc()
                    .tbodyo()
                    .tbodyc()
                .tablec()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();
echo JS_SWAL;
?>

<link href="<?php echo base_url()?>assets/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url()?>assets/plugins/datatables/datatables.min.js"></script>
<script>
    $(document).ready(function(){
        $("table").DataTable({
            scrollX:true,
            order: [[ 0, 'asc' ]]
        });
    });
    var mapel=<?php echo json_encode($mapel);?>;
    var sudahpas=<?php echo json_encode($sudahpas);?>;
    var table='';
    $.each(mapel,function(i,v){
        var statusajuan=0;
    	if(sudahpas[v.kode]==null) sudahpas[v.kode]="-"; 
    	else if(sudahpas[v.kode]["waktu_selesai"]!=null) sudahpas[v.kode]="Sudah dikerjakan";
    	else sudahpas[v.kode]='<span class="text-orange">Sedang dikerjakan, belum mengeklik tombol kirim jawaban</span>';
        table+="<tr><td>"+v.kelas+"</td><td>"+v.pelajaran+"</td><td>"+v.token+"</td><td><a class=\"btn btn-teal\" onclick=\"swall()\" href=\"<?php echo base_url('student/ulangan?mapel=');?>"+v.kode+"\">Klik</a></td><td>"+sudahpas[v.kode]+"</td></tr>";
    })
    $("#list tbody").html(table);
</script>