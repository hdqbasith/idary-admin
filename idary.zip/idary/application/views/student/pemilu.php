<?php
defined('BASEPATH') OR exit('No direct script access allowed');

if($sudah_pilih=='0'){
	echo dvo('panel panel-color panel-teal','d1')
		.dvo('panel-heading')
			.heading('Pemilihan Ketua PP/OSIS', 4, 'class="panel-title"')
		.dvc()
		.dvo('panel-body')
			.dvo('row')
			    .dvo('col-md-12')
			    	.heading('Siapa yang menurutmu pantas menjadi Ketua PP/OSIS selanjutnya? Klik satu gambar pilihanmu',4)
			    	.dvo('col-md-4 bg-orange')
			    		.img('https://1.bp.blogspot.com/-8emhCEItC0Q/X4-pG4-RBDI/AAAAAAAANh4/jQBdJttnWd45gvB8bbcMTeeTJYylV4hugCLcBGAsYHQ/s418/1.png','','width="100%" id="calon1" class="calon"')
			    		.heading('Raihan Naufal Prastika',5,'id="nama1"')
			    	.dvc()
			    	.dvo('col-md-4 bg-info')
			    		.img('https://1.bp.blogspot.com/-S8ekPND8zYo/X4-pHLY1N2I/AAAAAAAANiA/-ENkXj3_a18_v1H_r9ZBApWF4PvN6KfxACLcBGAsYHQ/s435/2.png','','width="100%" id="calon2" class="calon"')
			    		.heading('M. Najmul Ilmi A.T.U',5,'id="nama2"')
			    	.dvc()
			    	.dvo('col-md-4 bg-warning')
			    		.img('https://1.bp.blogspot.com/-82ZW_4FeFgE/X4-pHEVc1zI/AAAAAAAANh8/LabLtXvDQxUxNqJ_RNMcEYrABJ1hMVraQCLcBGAsYHQ/s432/3.png','','width="100%" id="calon3" class="calon"')
			    		.heading('M. Khilmi Al Farisi',5,'id="nama3"')
			    	.dvc()
			    .dvc()
		    .dvc()
	    .dvc()
	.dvc();

	echo dvo('panel panel-color panel-teal','d2')
		.form_button('back','Kembali','btn btn-rounded btn-danger waves-effect waves-light btn-lg')
		.dvo('panel-heading')
			.heading('Calon Ketua PP/OSIS Pilihanmu', 4, 'class="panel-title"')
		.dvc()
		.dvo('panel-body')
			.dvo('row')
			    .dvo('col-md-12 text-center')
			    	.heading('Sudah yakin dengan pilihanmu? Kamu memilih',4)
				    .dvo()
			    		.img('','','width="50%" id="pilihan" class="center-block"')
			    		.heading('',5,'id="namapilihan"')
		    		.dvc()
		    		.br(2)
					.form_button('simpan','Ya, saya memilih ini','btn btn-rounded btn-teal waves-effect waves-light btn-lg')
					.form_button('batal','Batalkan','btn btn-rounded btn-orange waves-effect waves-light btn-lg')
			    .dvc()
		    .dvc()
	    .dvc()
	.dvc();
} else{
	echo dvo('panel panel-color panel-teal','d3')
		.dvo('panel-heading')
			.heading('Hasil Pemilihan Ketua PP/OSIS', 4, 'class="panel-title"')
		.dvc()
		.dvo('panel-body')
		    .dvo('col-md-12')
		    	.dvo('','piechart','width: 600px; height: 500px;')
		    	.dvc()
		    .dvc()
		    .dvo()
				.heading('Daftar Siswa yang Sudah Memilih', 4, '')
                .tableo('list','','width=100%')
                    .theado()
                        .tro()
                            .th('Absen')
                            .th('Kelas')
                            .th('Nama')
                        .trc()
                    .theadc()
                    .tbodyo();
                    foreach ($pemilih as $p) {
                    	echo '<tr><td>'.$p['absen'].'</td><td>'.$p['kelas'].'</td><td>'.$p['nama_lengkap'].'</td></tr>';
                    }
                    echo tbodyc()
                .tablec()
		    .dvc()
	    .dvc()
	.dvc();
}
echo JS_SWAL;
?>
<link href="<?php echo base_url()?>assets/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url()?>assets/plugins/datatables/datatables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.colVis.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/fixedcolumns/3.3.1/js/dataTables.fixedColumns.min.js"></script>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Calon', 'Jumlah Suara'],
          ['M. Khilmi Al Farisi',     <?php echo $calon[3];?>],
          ['M. Najmul Ilmi A.T.U',      <?php echo $calon[2];?>],
          ['Raihan Naufal Prastika',  <?php echo $calon[1];?>],
        ]);

        var options = {
          title: 'Perolehan Suara Realtime',
          pieSliceText: 'value-and-percentage'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>

<script>
    $(document).ready(function(){
    	$("#d2").hide()
    	$("table").DataTable({
            order: [[ 1, 'asc' ],[ 0, 'asc' ]],
	        "dom": 'Bfrtip',
	        "buttons": [
	            'copy', 'excel', 'pdf','colvis'
	        ],
    	});
    })
	var pilihan;
	$(".calon").click(function(){
		pilihan=this.id.substr(5);
		$("#pilihan").prop("src",$("#calon"+pilihan).prop("src"));
		$("#namapilihan").text($("#nama"+pilihan).text());
		$("#d1").hide();
		$("#d2").show();
	})

	$("#simpan").click(function(){
        swal({
            title:"Menyimpan...", 
            text:"Mohon tunggu sebentar. Jika halaman tidak dialihkan silakan ulangi sekali lagi.",
            type:"success",
            timer: 10000,
            showConfirmButton:false,
        })
        $.get("<?php  echo base_url('student/pemilu?pilihan='); ?>"+pilihan,function(data){
        	if(data=="0"){
                swal({
                    title:"Upsss...", 
                    text:"Anda sudah pernah memilih atau mungkin Anda mengeklik tombol 2 kali",
                    type:"success",
                    timer: 3000,
                })
        	} else{
        		window.location.reload();
        	}
        })
	})
	$("#back,#batal").click(function(){
		$("#d2").hide();
		$("#d1").show();
	})
</script>