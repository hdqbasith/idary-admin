<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$fl = array(
  'class'=> 'col-sm-4 control-label'
);
$fc =array(
    'class'=> 'form-control',
    'type'=>'text',
    'autocomplete'=>'off'
);
$fr =array(
    'class'=> 'form-control',
    'required'=>'',
    'readonly'=>'',
    'type'=>'text',
    'autocomplete'=>'off'
);
echo '<a href="'.base_url('student/daftarmapel').'" class="btn btn-lg btn-danger btn-rounded">Kembali</a>';
echo dvo('panel panel-color panel-teal','d0')
	.dvo('panel-heading')
		.heading($dokumen['tema'], 4, 'class="panel-title" id="judul"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
    		    .dvo('col-md-12','vid')
        		    .'<iframe id="frame" src="https://drive.google.com/file/d/'.$dokumen['link'].'/preview" width="100%" height="480"></iframe>'
    		    .dvc()
    	    .dvc()
    	    .dvo('col-md-12')
	            .$dokumen['isi']
    	        .form_open(base_url('cekjs'),'name="form" id="form" class="form-horizontal" style="background:white; border-top: 3px solid; margin-top:50px"')
    				.dvo('form-group')
    					.form_label('Materi', 'materi', $fl)
    					.dvo('col-sm-8')
    						.form_dropdown('materi', array($dokumen['id']=>$dokumen['tema']),$id)
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Waktu membaca', 'persen', $fl)
    					.dvo('col-sm-8')
    						.form_input('persen', $dokumen['persen'], $fr)
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Jawaban/Ringkasan', 'notif_content', $fl)
    					.dvo('col-sm-8')
    						.form_textarea('notif_content', $dokumen['notif_content'], array('class'=> 'form-control','type'=>'text','autocomplete'=>'off','id'=>'notif_content'))
    					.dvc()
    				.dvc();
                	if($dokumen['persen']==null) echo form_button('simpan','Simpan','btn btn-rounded btn-teal waves-effect waves-light btn-lg btn-block');
                	else echo '<h4 class="text-danger">Anda sudah membaca file ini selama '.$dokumen['persen'].'. Jangan mengeklik tombol simpan lagi karena bisa mengubah waktu membaca.</h4>'.form_button('simpan','Simpan','btn btn-rounded btn-teal waves-effect waves-light btn-lg btn-block')
                .form_close();
		    echo dvc()
	    .dvc()
    .dvc()
.dvc();
echo JS_SWAL.JS_TOAST;
?>

<link href="https://fonts.googleapis.com/css2?family=Amiri&display=swap" rel="stylesheet"> 
<script src="https://www.youtube.com/iframe_api"></script>
<script>
    $(document).ready(function(){
        values = $("#form").serialize();
        $.post("<?php  echo base_url('student/dokumen'); ?>",values);
        jalan();
        $("ar").parent().css({'font-family': 'Amiri','font-size':'18px','line-height': '2.429','direction':'rtl'});
    })
    $("#form").on("submit",function(e){
        e.preventDefault();
        var values = $(this).serialize();
        swal({
        	title:"Menyimpan...", 
        	text:"Mohon tunggu sebentar. Jika tidak ada notifikasi sukses, silakan coba lagi",
        	type:"warning",
        	timer: 10000,
        	showConfirmButton:false,
        	closeOnCancel: false
    	});
        $.post("<?php  echo base_url('student/audio'); ?>",values,function(data){
            swal.close();
            toastr.success('Data berhasil disimpan', 'Sukses!');
        })
    });
    var blur=0;
    $(document).on("visibilitychange", function() {
        if ( document.hidden ) {
          blur=1;
        } else {
          blur=0;
        }
    });
    function jalan(){
        var d=0;
        var m=0;
        var j=0;
        x = setInterval(function() {
            if(blur==0) d++;
            if(d==60){
                d=0;
                m++;
            }
            if(m==60){
                m=0;
                j++;
            }
            var td=d,tm=m,tj=j;
            if(d.toString().length==1) td='0'+d;
            if(m.toString().length==1) tm='0'+m;
            if(j.toString().length==1) tj='0'+j;
            $("#persen").val(tj+":"+tm+":"+td);
        }, 1000);
    }
</script>

