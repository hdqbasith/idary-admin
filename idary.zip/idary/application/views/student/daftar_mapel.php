<?php
defined('BASEPATH') OR exit('No direct script access allowed');
echo dvo('panel panel-color panel-teal','d1')
    .dvo('panel-heading')
        .heading('Daftar Video yang bisa diakses', 4, 'class="panel-title"')
    .dvc()
    .dvo('panel-body')
        .dvo('row')
            .dvo('col-md-12')
                .tableo('list','','width=100%')
                    .theado()
                        .tro()
                            .th('Mapel')
                            .th('Guru Pengampu')
                            .th('Tema')
                            .th('Link')
                            .th('Kelas')
                        .trc()
                    .theadc()
                    .tbodyo()
                    .tbodyc()
                .tablec()
            .dvc()
        .dvc()
    .dvc()
.dvc();
echo dvo('panel panel-color panel-teal','d2')
	.dvo('panel-heading')
		.heading('Daftar Audio yang bisa diakses', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		        .tableo('list2','','width=100%')
    		        .theado()
    		            .tro()
    		                .th('Mapel')
    		                .th('Guru Pengampu')
    		                .th('Tema')
    		                .th('Link')
    		                .th('Kelas')
    		            .trc()
                    .theadc()
                    .tbodyo()
                    .tbodyc()
		        .tablec()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();
echo dvo('panel panel-color panel-primary','d3')
	.dvo('panel-heading')
		.heading('Daftar Dokumen (Silakan dipelajari sendiri)', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		        .tableo('list3','','width=100%')
    		        .theado()
    		            .tro()
    		                .th('Mapel')
    		                .th('Guru Pengampu')
    		                .th('Tema')
    		                .th('Link')
    		                .th('Kelas')
    		            .trc()
                    .theadc()
                    .tbodyo()
                    .td('segera hadir','colspan=5')
                    .tbodyc()
		        .tablec()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();
echo dvo('panel panel-color panel-orange','d4')
	.dvo('panel-heading')
		.heading('Daftar Soal yang bisa diakses', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		        .tableo('list4','','width=100%')
    		        .theado()
    		            .tro()
    		                .th('Mapel')
    		                .th('Guru Pengampu')
    		                .th('Tema')
    		                .th('Link')
    		                .th('Kelas')
    		            .trc()
                    .theadc()
                    .tbodyo()
                    .td('segera hadir','colspan=5')
                    .tbodyc()
		        .tablec()
		      //  if($this->session->userdata('user_level')==6) echo '<a class="btn btn-teal" target="_blank" href="https://drive.google.com/file/d/1nMWmcZZKr3Z0lHx9REpU8l0IAQ3u3BMh/view?usp=sharing">Download Soal</a>'
		    .dvc()
	    .dvc()
    .dvc()
.dvc();

echo JS_SWAL;
?>

<link href="<?php echo base_url()?>assets/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url()?>assets/plugins/datatables/datatables.min.js"></script>

<script>
    $(document).ready(function(){
        $("table").DataTable({
            scrollX:true,
            order: [[ 4, 'asc' ]]
        });
    });
    var mapel=<?php echo json_encode($mapel);?>;
    var table='';
    $.each(mapel,function(i,v){
        table+="<tr><td>"+v.pelajaran+"</td><td>"+v.guru+"</td><td>"+v.tema+"</td><td><a class=\"btn btn-teal\" onclick=\"swall()\" href=\"<?php echo base_url('student/videoyt?id=');?>"+v.id+"\">Klik</a></td><td>"+v.kelas+"</td></tr>";
    })
    $("#list tbody").html(table);
    
    var mapel2=<?php echo json_encode($mapel2);?>;
    var table2='';
    $.each(mapel2,function(i,v){
        table2+="<tr><td>"+v.pelajaran+"</td><td>"+v.guru+"</td><td>"+v.tema+"</td><td><a class=\"btn btn-teal\" onclick=\"swall()\" href=\"<?php echo base_url('student/audio?id=');?>"+v.id+"\">Klik</a></td><td>"+v.kelas+"</td></tr>";
    })
    $("#list2 tbody").html(table2);
    
    var mapel3=<?php echo json_encode($dokumen);?>;
    var table3='';
    $.each(mapel3,function(i,v){
        table3+="<tr><td>"+v.pelajaran+"</td><td>"+v.guru+"</td><td>"+v.tema+"</td><td><a class=\"btn btn-teal\" onclick=\"swall()\" href=\"<?php echo base_url('student/dokumen?id=');?>"+v.id+"\">Klik</a></td><td>"+v.kelas+"</td></tr>";
    })
    $("#list3 tbody").html(table3);
    
    var mapel4=<?php echo json_encode($soal);?>;
    var table4='';
    $.each(mapel4,function(i,v){
        table4+="<tr><td>"+v.pelajaran+"</td><td>"+v.guru+"</td><td>"+v.tema+"</td><td><a class=\"btn btn-teal\" onclick=\"swall()\" href=\"<?php echo base_url('student/ulangan?mapel=');?>"+v.link+"\">Klik</a></td><td>"+v.kelas+"</td></tr>";
    })
    $("#list4 tbody").html(table4);
    
    function swall(){
	    swal({
        	title:"Mengalihkan...", 
        	text:"Mohon tunggu sebentar. Jika halaman tidak dialihkan, silakan coba lagi",
        	type:"info",
        	timer: 2000,
        	showConfirmButton:false,
        	closeOnCancel: false,
    	});
    }
    $("#pilih").click(function(){
        if("<?php echo $this->session->userdata('user_level')?>"==8)
            window.location.href="<?php echo base_url('student/pemilu');?>";
        else {
            swal({
                title:"Ups...", 
                text:"Silakan login dengan akun siswa untuk mengikuti pemilihan",
                type:"info",
                timer: 5000,
            });
        }
    })
</script>