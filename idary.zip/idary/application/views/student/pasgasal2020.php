<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$aturan=array(
    'Waktu mengerjakan dimulai pada pukul 07.00 sampai pukul 14.00',
    'Waktu mengerjakan adalah 90 menit untuk mapel kurikulum nasional dan 60 menit untuk mapel salaf dan muatan lokal',
    'Waktu mengerjakan dihitung setelah Anda mengeklik tombol Mulai',
    'Jawaban Anda akan hilang jika Anda menutup aplikasi sebelum mengeklik tombol Kirim Jawaban',
    'Berikan izin akses kamera sebagai bukti bahwa Anda mengerjakan PAS dengan jujur',
    'Silakan cek mapel yang sudah Anda kerjakan di tabel yang ada di bawah'
    );
$raport=array(
    'Contoh Pengumuman',
    
	);
echo dvo('panel panel-color panel-orange','d3')
    .dvo('panel-heading')
        .heading('Pengumuman Penting!', 4, 'class="panel-title"')
    .dvc()
    .dvo('panel-body')
        .dvo('row')
            .dvo('col-md-12')
            .ul($raport)
            .pc()
            .dvc()
        .dvc()
    .dvc()
.dvc();
echo dvo('panel panel-color panel-teal','d0')
	.dvo('panel-heading')
		.heading('Penilaian Akhir Semester Gasal 2020', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		    .po('Silakan baca dan pahami baik-baik peraturan berikut agar Anda tidak keliru dalam mengerjakan soal-soal Penilaian Akhir Semester Gasal 2020.')
		    .ul($aturan)
		    .pc()
		    .po('Jadwal masuk sini').pc()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();
echo dvo('panel panel-color panel-teal','d1')
	.dvo('panel-heading')
		.heading('Daftar Mapel PAS hari ini', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
                .tableo('list','','width=100%')
                    .theado()
                        .tro()
                            .th('Kelas')
                            .th('Mapel')
                            .th('Link')
                            .th('Status')
                        .trc()
                    .theadc()
                    .tbodyo()
                    .tbodyc()
                .tablec()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();
echo JS_SWAL;
?>

<link href="<?php echo base_url()?>assets/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url()?>assets/plugins/datatables/datatables.min.js"></script>
<script>
    $(document).ready(function(){
        $("table").DataTable({
            scrollX:true,
            order: [[ 0, 'asc' ]]
        });
    });
    var mapel=<?php echo json_encode($mapel);?>;
    var sudahpas=<?php echo json_encode($sudahpas);?>;
    var table='';
    $.each(mapel,function(i,v){
    	if(sudahpas[v.kode]==null) sudahpas[v.kode]="-"; 
    	else if(sudahpas[v.kode]["waktu_selesai"]!=null) sudahpas[v.kode]="Sudah dikerjakan";
    	else sudahpas[v.kode]='<span class="text-orange">Sedang dikerjakan, belum mengeklik tombol kirim jawaban</span>';
        table+="<tr><td>"+v.kelas+"</td><td>"+v.pelajaran+"</td><td><a class=\"btn btn-teal\" onclick=\"swall()\" href=\"<?php echo base_url('student/ulangan?mapel=');?>"+v.kode+"\">Klik</a></td><td>"+sudahpas[v.kode]+"</td></tr>";
    })
    $("#list tbody").html(table);
</script>