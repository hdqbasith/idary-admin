<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$a['nama_lengkap']='Nama Lengkap';$a['nis_lokal']='NIS';$a['nisn']='NISN';$a['nik']='NIK (lihat KK)';$a['tempat_lahir']='Tempat Lahir';$a['tanggal_lahir']='Tanggal Lahir';$a['m_hobi_id']='Hobi';$a['m_citacita_id']='Cita-Cita';$a['jml_saudara']='Jumlah Saudara';$a['tanggal_masuk']='Tanggal Masuk'; $a['jrssiswa']='Pilihan Jurusan';$a['hp_siswa']='No. HP';$a['email']='Email';$a['nama_arab']='Nama (Arab)';$a['m_hobi_id']='Hobi';$a['m_citacita_id']='Cita-Cita';
$c['tuna_rungu']='Tuna Rungu';$c['tuna_netra']='Tuna Netra';$c['tuna_daksa']='Tunda Daksa';$c['tuna_grahita']='Tuna Grahita';$c['tuna_laras']='Tuna Laras';$c['lamban_belajar']='Lamban Belajar';$c['sulit_belajar']='Sulit Belajar';$c['gangguan_komunikasi']='Gangguan Komunikasi';$c['bakat_luar_biasa']='Bakat Luar Biasa';
$e['nomor_kk']='No. KK';$e['nama_kepala_keluarga']='Nama Kepala Keluarga';$e['nama_ayah_kandung']='Nama';$e['tahun_lahir_ayah_kandung']='TTL';$e['m_kondisi_ayah_kandung_id']='Status';$e['nik_ayah_kandung']='NIK';$e['m_pendidikan_ayah_kandung_id']='Pendidikan';$e['m_pekerjaan_ayah_kandung_id']='Pekerjaan';$e['nama_ibu_kandung']='Nama';$e['tahun_lahir_ibu_kandung']='TTL';$e['m_kondisi_ibu_kandung_id']='Status';$e['nik_ibu_kandung']='NIK';$e['m_pendidikan_ibu_kandung_id']='Pendidikan';$e['m_pekerjaan_ibu_kandung_id']='Pekerjaan';$e['nama_wali']='Nama';$e['tahun_lahir_wali']='TTL';$e['nik_wali']='NIK';$e['m_pendidikan_wali_id']='Pendidikan';$e['m_pekerjaan_wali_id']='Pekerjaan';$e['penghasilan_bulan']='Penghasilan per Bulan';$e['ayah_arab']='Nama (Arab)';$e['hp_ayah']='No. HP';$e['hp_ibu']='No. HP';
$d['m_jenis_rumah_id']='Status Tempat Tinggal';$d['alamat_siswa']='Alamat';$d['propinsi_siswa']='Provinsi';$d['kabupaten_siswa']='Kabupaten';$d['kecamatan_siswa']='Kecamatan';$d['kelurahan_siswa']='Kelurahan';$d['kode_pos_siswa']='Kode Pos';$d['m_jarak_id']='Jarak Tempat Tinggal ke Madrasah';$d['m_transport_id']='Transportasi ke madrasah';$d['nama_pondok']='Nama Pondok';$d['pimpinan_pondok']='Pimpinan';$d['alamat_pondok']='Alamat';$d['hp_pondok']='No. HP';$d['m_status_rumah_id']='Status Rumah';$d['alamat_ortu']='Alamat';$d['propinsi_ortu']='Provinsi';$d['kabupaten_ortu']='Kabupaten';$d['kecamatan_ortu']='Kecamatan';$d['kelurahan_ortu']='Desa';$d['kode_pos_ortu']='Kode Pos';$d['rt']='RT';$d['rw']='RW';
$b['m_asal_sekolah_id']='Status Sekolah';$b['tahun_ajaran']='Tahun Lulus';$b['npsn_sekolah_asal']='NPSN';$b['nama_sekolah_asal']='Nama Sekolah';$b['alamat_sekolah_asal']='Alamat';$b['unindo']='Bahasa Indonesia';$b['unmtk']='Matematika';$b['unipa']='IPA';$b['uning']='Bahasa Inggris';$b['m_jenis_sekolah_id']='Jenis Sekolah';

$op['jurusan']=array(''=>'','0'=>'','1'=>'IPA', '2'=>'IPS', '3'=>'Bahasa', '4'=>'Keagamaan');
$op['daritbs']=array('1'=>'Ya','0'=>'Tidak');
$op['hobi']=array('1'=>'Olahraga','2'=>'Kesenian','3'=>'Membaca','4'=>'Menulis','5'=>'Jalan-Jalan','6'=>'Lainnya');
$op['citacita']=array('1'=>'PNS','2'=>'TNI/Polri','3'=>'Guru/Dosen','4'=>'Dokter','5'=>'Politikus','6'=>'Wiraswasta','7'=>'Seniman/Artis','8'=>'Ilmuwan','9'=>'Agamawan','0'=>'Lainnya');
$op['status']=array('1'=>'Masih Hidup','2'=>'Sudah Meninggal','3'=>'Tidak Diketahui');
$op['pdd']=array('0'=>'Tidak Berpendidikan Formal','1'=>'SD/Sederajat','2'=>'SMP/Sederajat','3'=>'SMA/Sederajat','4'=>'D1','5'=>'D2','6'=>'D3','7'=>'D4/S1','8'=>'S2','9'=>'S3');
$op['kerja']=array('1'=>'1. Tidak Bekerja','2'=>'2. Pensiunan','3'=>'3. PNS (Selain poin 05 dan 10)','4'=>'4. TNI/Polisi','5'=>'5. Guru/Dosen','6'=>'6. Pegawai Swasta','7'=>'7. Wiraswasta/Wirausaha','8'=>'8. Pengacara/Hakim/Jaksa/Notaris','9'=>'9. Seniman/Pelukis/Artis/Sejenis','10'=>'10. Dokter/Bidan/Perawat','11'=>'11. Pilot/Pramugara','12'=>'12. Pedagang','13'=>'13. Petani/Peternak','14'=>'14. Nelayan','15'=>'15. Buruh (Tani/Pabrik/Bangunan)','16'=>'16. Sopir/Masinis/Kondektur','17'=>'17. Politikus','18'=>'18. Tidak Tentu');
$op['hasil']=array('1'=>'Kurang dari Rp 500.000','2'=>'Rp 500.000 - 1.000.000','3'=>'Rp 1.000.001 - 2.000.000','4'=>'Rp 2.000.001 - 3.000.000','5'=>'Rp 3.000.001 - 5.000.000','6'=>'Lebih dari Rp 5.000.000');
$op['jenisrumah']=array('1'=>'Tinggal dengan Orangtua/Wali','2'=>'Ikut Saudara/Kerabat','3'=>'Asrama Madrasah','4'=>'Kontrak/Kost','5'=>'Asrama Pesantren','6'=>'Panti Asuhan','7'=>'Rumah Singgah','8'=>'Lainnya');
$op['jarak']=array('1'=>'Kurang dari 5 Km','2'=>'Antara 5 - 10 Km','3'=>'Antara 11 - 20 Km','4'=>'Antara 21 - 30 Km','5'=>'Lebih dari 30 Km');
$op['statusrumah']=array('1'=>'Milik Sendiri','2'=>'Rumah Orang Tua','3'=>'Rumah Saudara/Kerabat','4'=>'Rumah Dinas','5'=>'Sewa/Kontrak','6'=>'Lainnya');
$op['transport']=array('1'=>'Jalan Kaki','2'=>'Sepeda','3'=>'Sepeda Motor','4'=>'Mobil Pribadi','5'=>'Antar Jemput Sekolah','6'=>'Angkutan Umum','7'=>'Perahu/Sampan','8'=>'Lainnya');
$op['m_jenis_sekolah_id'] = array('1'=>'SMP', '2'=>'MTs', '3'=>'SMP Terbuka', '4'=>'SLB', '5'=>'Paket B', '6'=>'Pesantren Salafiyah Wustha', '7'=>'SMP di Luar Negeri');
$op['m_asal_sekolah_id'] = array('1'=>'Negeri', '2'=>'Swasta');
$fl = array(
    'class'=> 'col-sm-4 control-label'
);
$fc =array(
    'class'=> 'form-control',
    'type'=>'text',
    'autocomple'=>'off'
);
$fd = array(
    'class'=> 'datepicker form-control',
    'placeholder' => 'dd-mm-yyyy',
    'autocomplete' => 'off'
);
$fn = array(
    'class'=> 'form-control',
    'type'=>'number',
    'autocomplete' => 'off'
);
$fnd = array(
  'class'=> 'form-control',
  'type' => 'number',
  'step' => '0.01',
  'autocomplete' => 'off'
);
$fh=array(
  'class'=> 'form-control',
    'style'=>'display:none'
);
$op['kelasmts']=array(
    ''=>'','A'=>'IX A', 'B'=>'IX B', 'C'=>'IX C', 'D'=>'IX D', 'E'=>'IX E', 'F'=>'IX F', 'G'=>'IX G', 'H'=>'IX H', 'I'=>'IX I', 'J'=>'IX J', 'K'=>'IX K', 'L'=>'IX L', 'M'=>'IX M', 'N'=>'IX N', 'O'=>'IX O'
);
$attr['wil']=array(
    'onchange'=>'wilayah('
);
$nama_lengkap=$detail['nama_lengkap'];$nis_lokal=$detail['nis_lokal'];$nisn=$detail['nisn'];$nik=$detail['nik'];$tempat_lahir=$detail['tempat_lahir'];$tanggal_lahir=date('d-m-Y',strtotime($detail['tanggal_lahir']));$m_hobi_id=$detail['m_hobi_id'];$m_citacita_id=$detail['m_citacita_id'];$jml_saudara=$detail['jml_saudara'];$tanggal_masuk=$detail['tanggal_masuk'];$m_asal_sekolah_id=$detail['m_asal_sekolah_id'];$tahun_ajaran=$detail['tahun_ajaran'];$npsn_sekolah_asal=$detail['npsn_sekolah_asal'];$nama_sekolah_asal=$detail['nama_sekolah_asal'];$alamat_sekolah_asal=$detail['alamat_sekolah_asal'];$tuna_rungu=$detail['tuna_rungu'];$tuna_netra=$detail['tuna_netra'];$tuna_daksa=$detail['tuna_daksa'];$tuna_grahita=$detail['tuna_grahita'];$tuna_laras=$detail['tuna_laras'];$lamban_belajar=$detail['lamban_belajar'];$sulit_belajar=$detail['sulit_belajar'];$gangguan_komunikasi=$detail['gangguan_komunikasi'];$bakat_luar_biasa=$detail['bakat_luar_biasa'];$m_jenis_rumah_id=$detail['m_jenis_rumah_id'];$alamat_siswa=$detail['alamat_siswa'];$propinsi_siswa=$detail['propinsi_siswa'];$kabupaten_siswa=$detail['kabupaten_siswa'];$kecamatan_siswa=$detail['kecamatan_siswa'];$kelurahan_siswa=$detail['kelurahan_siswa'];$kode_pos_siswa=$detail['kode_pos_siswa'];$m_jarak_id=$detail['m_jarak_id'];$m_transport_id=$detail['m_transport_id'];$nama_pondok=$detail['nama_pondok'];$pimpinan_pondok=$detail['pimpinan_pondok'];$alamat_pondok=$detail['alamat_pondok'];$hp_pondok=$detail['hp_pondok'];$nomor_kk=$detail['nomor_kk'];$nama_kepala_keluarga=$detail['nama_kepala_keluarga'];$nama_ayah_kandung=$detail['nama_ayah_kandung'];$tahun_lahir_ayah_kandung=date('d-m-Y',strtotime($detail['tahun_lahir_ayah_kandung']));$m_kondisi_ayah_kandung_id=$detail['m_kondisi_ayah_kandung_id'];$nik_ayah_kandung=$detail['nik_ayah_kandung'];$m_pendidikan_ayah_kandung_id=$detail['m_pendidikan_ayah_kandung_id'];$m_pekerjaan_ayah_kandung_id=$detail['m_pekerjaan_ayah_kandung_id'];$nama_ibu_kandung=$detail['nama_ibu_kandung'];$tahun_lahir_ibu_kandung=date('d-m-Y',strtotime($detail['tahun_lahir_ibu_kandung']));$m_kondisi_ibu_kandung_id=$detail['m_kondisi_ibu_kandung_id'];$nik_ibu_kandung=$detail['nik_ibu_kandung'];$m_pendidikan_ibu_kandung_id=$detail['m_pendidikan_ibu_kandung_id'];$m_pekerjaan_ibu_kandung_id=$detail['m_pekerjaan_ibu_kandung_id'];$nama_wali=$detail['nama_wali'];$tahun_lahir_wali=date('d-m-Y',strtotime($detail['tahun_lahir_wali']));$nik_wali=$detail['nik_wali'];$m_pendidikan_wali_id=$detail['m_pendidikan_wali_id'];$m_pekerjaan_wali_id=$detail['m_pekerjaan_wali_id'];$penghasilan_bulan=$detail['penghasilan_bulan'];$nomor_kks=$detail['nomor_kks'];$nomor_pkh=$detail['nomor_pkh'];$nomor_kip=$detail['nomor_kip'];$m_alasan_id=$detail['m_alasan_id'];$besar_uang=$detail['besar_uang'];$m_status_rumah_id=$detail['m_status_rumah_id'];$alamat_ortu=$detail['alamat_ortu'];$propinsi_ortu=$detail['propinsi_ortu'];$kabupaten_ortu=$detail['kabupaten_ortu'];$kecamatan_ortu=$detail['kecamatan_ortu'];$kelurahan_ortu=$detail['kelurahan_ortu'];$kode_pos_ortu=$detail['kode_pos_ortu'];$rt=$detail['rt'];$rw=$detail['rw'];$nama_arab=$detail['nama_arab'];$alamat_arab=$detail['alamat_arab'];$ayah_arab=$detail['ayah_arab'];$hp_siswa=$detail['hp_siswa'];$hp_ayah=$detail['hp_ayah'];$hp_ibu=$detail['hp_ibu'];$email=$detail['email'];$kelas_mts=$detail['kelas_mts'];$absen=$detail['absen'];$noreg=$detail['noreg'];$pil_jurusan=$detail['pil_jurusan'];$kelas=$detail['kelas'];$jurusan=$detail['jurusan'];$paralel=$detail['paralel'];$m_jenis_sekolah_id=$detail['m_jenis_sekolah_id'];
if($nama_lengkap==null) $nama_lengkap=$ppdb['namasiswa'];
if($nisn==null) $nisn=$this->session->userdata('username');
if($nik==null) $nik=$ppdb['nik'];
if($tempat_lahir==null) $tempat_lahir=$ppdb['ttlsiswa'];
if($tanggal_lahir==null) $tanggal_lahir=date('d-m-Y',strtotime($ppdb['tglsiswa']));
if($hp_siswa==null) $hp_siswa=$ppdb['hpsiswa'];
if($email==null) $email=$ppdb['emailsiswa'];
if($pil_jurusan==null) $pil_jurusan=$ppdb['jrssiswa'];
if($kelas_mts==null) $kelas_mts=$ppdb['kelasmts'];
if($nama_sekolah_asal==null) $nama_sekolah_asal=$ppdb['aslsb'];
$op['provs']=null;
$op['kabs']=null;
$op['kecs']=null;
$op['kels']=null;
if(isset($provs)) foreach($provs as $o) $op['provs'][$o['code']]=$o['name'];
if(isset($kabs)) foreach($kabs as $o) $op['kabs'][$o['code']]=$o['name'];
if(isset($kecs)) foreach($kecs as $o) $op['kecs'][$o['code']]=$o['name'];
if(isset($kels)) foreach($kels as $o) $op['kels'][$o['code']]=$o['name'];
$op['provo']=null;
$op['kabo']=null;
$op['keco']=null;
$op['kelo']=null;
if(isset($kabo)) foreach($kabo as $o) $op['kabo'][$o['code']]=$o['name'];
if(isset($keco)) foreach($keco as $o) $op['keco'][$o['code']]=$o['name'];
if(isset($kelo)) foreach($kelo as $o) $op['kelo'][$o['code']]=$o['name'];


?>
<div class="col-lg-12">
    <div class="portlet">
        <div class="portlet-heading bg-teal">
            <h3 class="portlet-title">
                Petunjuk Umum
            </h3>
            <div class="portlet-widgets">
                <a data-toggle="collapse" data-parent="#accordion1" href="#bg-teal"><i class="ion-minus-round"></i></a>
                <span class="divider"></span>
                <a href="#" data-toggle="remove"><i class="ion-close-round"></i></a>
            </div>
            <div class="clearfix"></div>
        </div>
        <div id="bg-teal" class="panel-collapse collapse in">
            <div class="portlet-body">
                <ul>
                    <li>Isilah Data Anda dengan berpedoman pada data Ijazah dan KK.</li>
                    <li>Gunakanlah huruf kapital dalam pengisian data. Contoh: Muhammad Abdur Rohman</li>
                    <li>Isilah Data Anda dengan lengkap. Pengisian data yang tidak lengkap bisa mengakibatkan nama Anda tidak tercatat di pusat data Nasional.</li>
                    <li>Untuk nama arab boleh dikosongi, dengan catatan tidak akan protes apabila panitia keliru dalam menuliskan nama arab Anda dan Ayah Anda.</li>
                    <li>Harap bersabar ketika mengisi kolom kabupaten, kecamatan, dan kelurahan/desa. Tunggu sampai muncul pilihan.</li>
                    <li>Apabila Desa/Kelurahan Anda tidak tersedia dalam pilihan, silakan isi manual di kolom alamat.</li>
                    <li>Yang boleh dikosongi hanya kolom pondok pesantren yang berjumlah 4 kolom isian</li>
                    <li>Ada 4 tombol Simpan, klik satu-persatu setiap selesai mengisi data</li>
                    <li style="color:red">RISIKO BAGI YANG TIDAK MENGISI DATA DENGAN LENGKAP:
                        <ol>
                            <li>Tidak mendapatkan dana bantuan BOS dari pemerintah</li>
                            <li>Tidak mendapatkan raport ARD untuk mendaftar Perguruan Tinggi</li>
                            <li>Menyusahkan Bapak-Bapak Guru</li>
                            <li>Dimarahi Bapak-Bapak Guru -_-</li>
                            <li>Fitur-fitur tidak bisa diakses</li>
                        </ol>
                    </li>
                </ul>
                <h4 style="color:red">Anda telah mengisi data <span id="lengkap"></span>. Anda harus mengisi minimal 50 data untuk membuka akses pembelajaran.</h4>
                <a class="btn btn-teal" href="<?echo base_url('student/index'); ?>">Ke Beranda</a>
            </div>
        </div>
    </div>
</div>
<div class="bg-white">
    <ul class="nav nav-pills nav-justified teal">
        <li class="active"><a data-toggle="pill" href="#pribadi">Data Pribadi</a></li>
        <li><a data-toggle="pill" href="#ortu">Orang Tua/Wali</a></li>
        <li><a data-toggle="pill" href="#alamat">Alamat</a></li>
        <li><a data-toggle="pill" href="#riwayat">Riwayat Pendidikan</a></li>
    </ul>
    
    <div class="tab-content">
        <div id="pribadi" class="tab-pane fade in active">
            <?php
            echo form_open(base_url('student/simpanfull'),'name="private" id="private" class="form-horizontal" style="background:white"')
            	.dvo('panel panel-color panel-teal')
            		.dvo('panel-heading')
            			.heading('Silakan masukkan data pribadi Anda', 4, 'class="panel-title"')
            		.dvc()
            		.dvo('panel-body')
            			.dvo('row')
                			.dvo('col-md-6','','border-right: 2px solid lightgrey')
                				.dvo('form-group')
                					.form_label($a['nisn'], 'nisn', $fl)
                					.dvo('col-sm-8')
                						.form_input('nisn', $nisn, $fc)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($a['nik'], 'nik', $fl)
                					.dvo('col-sm-8')
                						.form_input('nik', $nik, $fn)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($a['nama_lengkap'], 'nama_lengkap', $fl)
                					.dvo('col-sm-8')
                						.form_input('nama_lengkap', $nama_lengkap, $fc)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($a['nama_arab'], 'nama_arab', $fl)
                					.dvo('col-sm-8')
                						.form_input('nama_arab', $nama_arab, $fc)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($a['tempat_lahir'], 'tempat_lahir', $fl)
                					.dvo('col-sm-8')
                						.form_input('tempat_lahir', $tempat_lahir, $fc)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($a['tanggal_lahir'], 'tanggal_lahir', $fl)
                					.dvo('col-sm-8')
                						.form_input('tanggal_lahir', $tanggal_lahir, $fd)
                					.dvc()
                				.dvc()
            				.dvc()
                			.dvo('col-md-6','','border-right: 2px solid lightgrey')
                				.dvo('form-group')
                					.form_label($a['jml_saudara'], 'jml_saudara', $fl)
                					.dvo('col-sm-8')
                						.form_input('jml_saudara', $jml_saudara, $fn)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($a['email'], 'email', $fl)
                					.dvo('col-sm-8')
                						.form_input('email', $email, $fc)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($a['hp_siswa'], 'hp_siswa', $fl)
                					.dvo('col-sm-8')
                						.form_input('hp_siswa', $hp_siswa, $fn)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($a['m_hobi_id'], 'm_hobi_id', $fl)
                					.dvo('col-sm-8')
                						.form_dropdown('m_hobi_id', $op['hobi'], $m_hobi_id)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($a['m_citacita_id'], 'm_citacita_id', $fl)
                					.dvo('col-sm-8')
                						.form_dropdown('m_citacita_id', $op['citacita'], $m_citacita_id)
                					.dvc()
                				.dvc()
                			.dvc()
            			.dvc()
            		.dvc()
            	.dvc()
            	.form_button('','Simpan','btn btn-rounded btn-danger waves-effect waves-light btn-lg btn-block')
            .form_close();
            ?>
        </div>
        <div id="ortu" class="tab-pane fade">
            <?php
            echo form_open(base_url('student/simpanfull'),'name="parents" id="parents" class="form-horizontal" style="background:white"')
            	.dvo('panel panel-color panel-teal')
            		.dvo('panel-heading')
            			.heading('Data Kartu Keluarga', 4, 'class="panel-title"')
            		.dvc()
            		.dvo('panel-body')
            			.dvo('row')
                			.dvo('col-md-6','','border-right: 2px solid lightgrey')
                				.dvo('form-group')
                					.form_label($e['nomor_kk'], 'nomor_kk', $fl)
                					.dvo('col-sm-8')
                						.form_input('nomor_kk', $nomor_kk, $fn)
                						.form_input('nisn', $nisn, $fh)
                					.dvc()
                				.dvc()
            				.dvc()
                			.dvo('col-md-6','','border-right: 2px solid lightgrey')
                				.dvo('form-group')
                					.form_label($e['nama_kepala_keluarga'], 'nama_kepala_keluarga', $fl)
                					.dvo('col-sm-8')
                						.form_input('nama_kepala_keluarga', $nama_kepala_keluarga, $fc)
                					.dvc()
                				.dvc()
                			.dvc()
            			.dvc()
            		.dvc()
        		.dvc()
            	.dvo('panel panel-color panel-teal')
            		.dvo('panel-heading')
            			.heading('Data Ayah Kandung', 4, 'class="panel-title"')
            		.dvc()
            		.dvo('panel-body')
            			.dvo('row')
                			.dvo('col-md-6','','border-right: 2px solid lightgrey')
                				.dvo('form-group')
                					.form_label($e['nama_ayah_kandung'], 'nama_ayah_kandung', $fl)
                					.dvo('col-sm-8')
                						.form_input('nama_ayah_kandung', $nama_ayah_kandung, $fc)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($e['ayah_arab'], 'ayah_arab', $fl)
                					.dvo('col-sm-8')
                						.form_input('ayah_arab', $ayah_arab, $fc)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($e['nik_ayah_kandung'], 'nik_ayah_kandung', $fl)
                					.dvo('col-sm-8')
                						.form_input('nik_ayah_kandung', $nik_ayah_kandung, $fn)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($e['hp_ayah'], 'hp_ayah', $fl)
                					.dvo('col-sm-8')
                						.form_input('hp_ayah', $hp_ayah, $fn)
                					.dvc()
                				.dvc()
            				.dvc()
                			.dvo('col-md-6','','border-right: 2px solid lightgrey')
                				.dvo('form-group')
                					.form_label($e['tahun_lahir_ayah_kandung'], 'tahun_lahir_ayah_kandung', $fl)
                					.dvo('col-sm-8')
                						.form_input('tahun_lahir_ayah_kandung', $tahun_lahir_ayah_kandung, $fd)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($e['m_kondisi_ayah_kandung_id'], 'm_kondisi_ayah_kandung_id', $fl)
                					.dvo('col-sm-8')
                						.form_dropdown('m_kondisi_ayah_kandung_id', $op['status'], $m_kondisi_ayah_kandung_id)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($e['m_pendidikan_ayah_kandung_id'], 'm_pendidikan_ayah_kandung_id', $fl)
                					.dvo('col-sm-8')
                						.form_dropdown('m_pendidikan_ayah_kandung_id', $op['pdd'], $m_pendidikan_ayah_kandung_id)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($e['m_pekerjaan_ayah_kandung_id'], 'm_pekerjaan_ayah_kandung_id', $fl)
                					.dvo('col-sm-8')
                						.form_dropdown('m_pekerjaan_ayah_kandung_id', $op['kerja'], $m_pekerjaan_ayah_kandung_id)
                					.dvc()
                				.dvc()
                			.dvc()
            			.dvc()
            		.dvc()
        		.dvc()
            	.dvo('panel panel-color panel-teal')
            		.dvo('panel-heading')
            			.heading('Data Ibu Kandung', 4, 'class="panel-title"')
            		.dvc()
            		.dvo('panel-body')
            			.dvo('row')
                			.dvo('col-md-6','','border-right: 2px solid lightgrey')
                				.dvo('form-group')
                					.form_label($e['nama_ibu_kandung'], 'nama_ibu_kandung', $fl)
                					.dvo('col-sm-8')
                						.form_input('nama_ibu_kandung', $nama_ibu_kandung, $fc)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($e['tahun_lahir_ibu_kandung'], 'tahun_lahir_ibu_kandung', $fl)
                					.dvo('col-sm-8')
                						.form_input('tahun_lahir_ibu_kandung', $tahun_lahir_ibu_kandung, $fd)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($e['nik_ibu_kandung'], 'nik_ibu_kandung', $fl)
                					.dvo('col-sm-8')
                						.form_input('nik_ibu_kandung', $nik_ibu_kandung, $fn)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($e['hp_ibu'], 'hp_ibu', $fl)
                					.dvo('col-sm-8')
                						.form_input('hp_ibu', $hp_ibu, $fn)
                					.dvc()
                				.dvc()
            				.dvc()
                			.dvo('col-md-6','','border-right: 2px solid lightgrey')
                				.dvo('form-group')
                					.form_label($e['m_kondisi_ibu_kandung_id'], 'm_kondisi_ibu_kandung_id', $fl)
                					.dvo('col-sm-8')
                						.form_dropdown('m_kondisi_ibu_kandung_id', $op['status'], $m_kondisi_ibu_kandung_id)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($e['m_pendidikan_ibu_kandung_id'], 'm_pendidikan_ibu_kandung_id', $fl)
                					.dvo('col-sm-8')
                						.form_dropdown('m_pendidikan_ibu_kandung_id', $op['pdd'], $m_pendidikan_ibu_kandung_id)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($e['m_pekerjaan_ibu_kandung_id'], 'm_pekerjaan_ibu_kandung_id', $fl)
                					.dvo('col-sm-8')
                						.form_dropdown('m_pekerjaan_ibu_kandung_id', $op['kerja'], $m_pekerjaan_ibu_kandung_id)
                					.dvc()
                				.dvc()
                			.dvc()
            			.dvc()
            		.dvc()
        		.dvc()
            	.dvo('panel panel-color panel-teal')
            		.dvo('panel-heading')
            			.heading('Data Wali (Yang membiayai pendidikan)', 4, 'class="panel-title"')
            		.dvc()
            		.dvo('panel-body')
            			.dvo('row')
                			.dvo('col-md-6','','border-right: 2px solid lightgrey')
                				.dvo('form-group')
                					.form_label($e['nama_wali'], 'nama_wali', $fl)
                					.dvo('col-sm-8')
                						.form_input('nama_wali', $nama_wali, $fc)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($e['tahun_lahir_wali'], 'tahun_lahir_wali', $fl)
                					.dvo('col-sm-8')
                						.form_input('tahun_lahir_wali', $tahun_lahir_wali, $fd)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($e['nik_wali'], 'nik_wali', $fl)
                					.dvo('col-sm-8')
                						.form_input('nik_wali', $nik_wali, $fn)
                					.dvc()
                				.dvc()
            				.dvc()
                			.dvo('col-md-6','','border-right: 2px solid lightgrey')
                				.dvo('form-group')
                					.form_label($e['m_pendidikan_wali_id'], 'm_pendidikan_wali_id', $fl)
                					.dvo('col-sm-8')
                						.form_dropdown('m_pendidikan_wali_id', $op['pdd'], $m_pendidikan_wali_id)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($e['m_pekerjaan_wali_id'], 'm_pekerjaan_wali_id', $fl)
                					.dvo('col-sm-8')
                						.form_dropdown('m_pekerjaan_wali_id', $op['kerja'], $m_pekerjaan_wali_id)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($e['penghasilan_bulan'], 'penghasilan_bulan', $fl)
                					.dvo('col-sm-8')
                						.form_dropdown('penghasilan_bulan', $op['hasil'], $penghasilan_bulan)
                					.dvc()
                				.dvc()
                			.dvc()
            			.dvc()
            		.dvc()
            	.dvc()
            	.form_button('','Simpan','btn btn-rounded btn-warning waves-effect waves-light btn-lg btn-block')
            .form_close();
            ?>
        </div>
        <div id="alamat" class="tab-pane fade">
            <?php
            echo form_open(base_url('student/simpanfull'),'name="domicile" id="domicile" class="form-horizontal" style="background:white"')
            	.dvo('panel panel-color panel-teal')
            		.dvo('panel-heading')
            			.heading('Pondok Pesantren', 4, 'class="panel-title"')
            		.dvc()
            		.dvo('panel-body')
            			.dvo('row')
                			.dvo('col-md-6','','border-right: 2px solid lightgrey')
                				.dvo('form-group')
                					.form_label($d['nama_pondok'], 'nama_pondok', $fl)
                					.dvo('col-sm-8')
                						.form_dropdown('nama_pondok',array($nama_pondok=>$detail['nama_pondok2']), $nama_pondok)
                						.form_input('nama_pondok2',$detail['nama_pondok2'],$fh)
                						.form_input('nisn', $nisn, $fh)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($d['pimpinan_pondok'], 'pimpinan_pondok', $fl)
                					.dvo('col-sm-8')
                						.form_input('pimpinan_pondok', $pimpinan_pondok, $fc)
                					.dvc()
                				.dvc()
            				.dvc()
                			.dvo('col-md-6','','border-right: 2px solid lightgrey')
                				.dvo('form-group')
                					.form_label($d['alamat_pondok'], 'alamat_pondok', $fl)
                					.dvo('col-sm-8')
                						.form_input('alamat_pondok', $alamat_pondok, $fc)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($d['hp_pondok'], 'hp_pondok', $fl)
                					.dvo('col-sm-8')
                						.form_input('hp_pondok', $hp_pondok, $fn)
                					.dvc()
                				.dvc()
                			.dvc()
            			.dvc()
            		.dvc()
            	.dvc()
            	.dvo('panel panel-color panel-teal')
            		.dvo('panel-heading')
            			.heading('Alamat Tempat Tinggal/Pondok Pesantren', 4, 'class="panel-title"')
            		.dvc()
            		.dvo('panel-body')
            			.dvo('row')
                			.dvo('col-md-6','','border-right: 2px solid lightgrey')
                				.dvo('form-group')
                					.form_label($d['m_jenis_rumah_id'], 'm_jenis_rumah_id', $fl)
                					.dvo('col-sm-8')
                						.form_dropdown('m_jenis_rumah_id', $op['jenisrumah'], $m_jenis_rumah_id)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($d['propinsi_siswa'], 'propinsi_siswa', $fl)
                					.dvo('col-sm-8')
                						.form_dropdown('propinsi_siswa',$op['provs'], $propinsi_siswa,'onchange=wilayah(0,"siswa",$(this).val())')
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($d['kabupaten_siswa'], 'kabupaten_siswa', $fl)
                					.dvo('col-sm-8')
                						.form_dropdown('kabupaten_siswa',$op['kabs'], $kabupaten_siswa,'onchange=wilayah(1,"siswa",$(this).val())')
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($d['kecamatan_siswa'], 'kecamatan_siswa', $fl)
                					.dvo('col-sm-8')
                						.form_dropdown('kecamatan_siswa',$op['kecs'], $kecamatan_siswa,'onchange=wilayah(2,"siswa",$(this).val())')
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($d['kelurahan_siswa'], 'kelurahan_siswa', $fl)
                					.dvo('col-sm-8')
                						.form_dropdown('kelurahan_siswa',$op['kels'], $kelurahan_siswa)
                					.dvc()
                				.dvc()
            				.dvc()
                			.dvo('col-md-6','','border-right: 2px solid lightgrey')
                				.dvo('form-group')
                					.form_label($d['kode_pos_siswa'], 'kode_pos_siswa', $fl)
                					.dvo('col-sm-8')
                						.form_input('kode_pos_siswa', $kode_pos_siswa, $fn)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($d['m_jarak_id'], 'm_jarak_id', $fl)
                					.dvo('col-sm-8')
                						.form_dropdown('m_jarak_id', $op['jarak'], $m_jarak_id)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($d['m_transport_id'], 'm_transport_id', $fl)
                					.dvo('col-sm-8')
                						.form_dropdown('m_transport_id', $op['transport'], $m_transport_id)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($d['alamat_siswa'], 'alamat_siswa', $fl)
                					.dvo('col-sm-8')
                						.form_textarea(['id'=>'alamat_siswa','name'=>'alamat_siswa','rows'=>'2'], $alamat_siswa, $fc)
                					.dvc()
                				.dvc()


                			.dvc()
            			.dvc()
            		.dvc()
            	.dvc()

            	.dvo('panel panel-color panel-teal')
            		.dvo('panel-heading')
            			.heading('Alamat Orang Tua (Untuk keperluan Kirim Surat/Kunjungan)', 4, 'class="panel-title"')
            		.dvc()
            		.dvo('panel-body')
            			.dvo('row')
                			.dvo('col-md-6','','border-right: 2px solid lightgrey')
                				.dvo('form-group')
                					.form_label($d['m_status_rumah_id'], 'm_status_rumah_id', $fl)
                					.dvo('col-sm-8')
                						.form_dropdown('m_status_rumah_id', $op['statusrumah'], $m_status_rumah_id)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($d['propinsi_ortu'], 'propinsi_ortu', $fl)
                					.dvo('col-sm-8')
                						.form_dropdown('propinsi_ortu',$op['provs'], $propinsi_ortu,'onchange=wilayah(0,"ortu",$(this).val())')
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($d['kabupaten_ortu'], 'kabupaten_ortu', $fl)
                					.dvo('col-sm-8')
                						.form_dropdown('kabupaten_ortu',$op['kabo'], $kabupaten_ortu,'onchange=wilayah(1,"ortu",$(this).val())')
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($d['kecamatan_ortu'], 'kecamatan_ortu', $fl)
                					.dvo('col-sm-8')
                						.form_dropdown('kecamatan_ortu',$op['keco'], $kecamatan_ortu,'onchange=wilayah(2,"ortu",$(this).val())')
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($d['kelurahan_ortu'], 'kelurahan_ortu', $fl)
                					.dvo('col-sm-8')
                						.form_dropdown('kelurahan_ortu',$op['kelo'], $kelurahan_ortu)
                					.dvc()
                				.dvc()
            				.dvc()
                			.dvo('col-md-6','','border-right: 2px solid lightgrey')
                				.dvo('form-group')
                					.form_label($d['kode_pos_ortu'], 'kode_pos_ortu', $fl)
                					.dvo('col-sm-8')
                						.form_input('kode_pos_ortu', $kode_pos_ortu, $fn)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($d['rt'], 'rt', $fl)
                					.dvo('col-sm-8')
                						.form_input('rt', $rt, $fn)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($d['rw'], 'rw', $fl)
                					.dvo('col-sm-8')
                						.form_input('rw', $rw, $fn)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($d['alamat_ortu'], 'alamat_ortu', $fl)
                					.dvo('col-sm-8')
                						.form_textarea(['id'=>'alamat_ortu','name'=>'alamat_ortu','rows'=>'2'], $alamat_ortu, $fc)
                					.dvc()
                				.dvc()
                			.dvc()
            			.dvc()
            		.dvc()
            	.dvc()
            	.form_button('','Simpan','btn btn-rounded btn-primary waves-effect waves-light btn-lg btn-block')
            .form_close();
            ?>
        </div>
        <div id="riwayat" class="tab-pane fade">
            <?php
            echo form_open(base_url('student/simpanfull'),'name="previous" id="previous" class="form-horizontal" style="background:white"')
            	.dvo('panel panel-color panel-teal')
            		.dvo('panel-heading')
            			.heading('Sekolah Asal', 4, 'class="panel-title"')
            		.dvc()
            		.dvo('panel-body')
            			.dvo('row')
                			.dvo('col-md-6','','border-right: 2px solid lightgrey')
                				.dvo('form-group')
                					.form_label($b['nama_sekolah_asal'], 'nama_sekolah_asal', $fl)
                					.dvo('col-sm-8')
                						.form_input('nama_sekolah_asal', $nama_sekolah_asal, $fc)
                						.form_input('nisn', $nisn, $fh)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($b['m_jenis_sekolah_id'], 'm_jenis_sekolah_id', $fl)
                					.dvo('col-sm-8')
                						.form_dropdown('m_jenis_sekolah_id',$op['m_jenis_sekolah_id'], $m_jenis_sekolah_id)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($b['m_asal_sekolah_id'], 'm_asal_sekolah_id', $fl)
                					.dvo('col-sm-8')
                						.form_dropdown('m_asal_sekolah_id',$op['m_asal_sekolah_id'], $m_asal_sekolah_id)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($b['npsn_sekolah_asal'], 'npsn_sekolah_asal', $fl)
                					.dvo('col-sm-8')
                						.form_input('npsn_sekolah_asal', $npsn_sekolah_asal, $fn)
                					.dvc()
                				.dvc()
            				.dvc()
                			.dvo('col-md-6','','border-right: 2px solid lightgrey')
                				.dvo('form-group')
                					.form_label($b['alamat_sekolah_asal'], 'alamat_sekolah_asal', $fl)
                					.dvo('col-sm-8')
                						.form_textarea(['id'=>'alamat_sekolah_asal','name'=>'alamat_sekolah_asal','rows'=>'2'], $alamat_sekolah_asal, $fc)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label($b['tahun_ajaran'], 'tahun_ajaran', $fl)
                					.dvo('col-sm-8')
                						.form_input('tahun_ajaran', $tahun_ajaran, $fn)
                					.dvc()
                				.dvc()
                			.dvc()
            			.dvc()
            		.dvc()
            	.dvc()
            	.form_button('','Simpan','btn btn-rounded btn-orange waves-effect waves-light btn-lg btn-block')
            .form_close();
            ?>
        </div>
    </div>
</div>
<?php echo JS_SWAL.JS_TOAST; ?>
<link href="<?php echo base_url()?>assets/plugins/datepicker/bootstrap-datepicker.min.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/select2/select2.min.css">
<script src="<?php echo base_url(); ?>assets/plugins/select2/js/select2.full.min.js"></script>
<script src="<?php echo base_url()?>assets/plugins/datepicker/bootstrap-datepicker.min.js"></script>
<script>
    $(document).ready(function(){
        $(".page-title").text("Biodata Siswa");
        $("#judul_hlm").text("Biodata");
        $("#nisn").attr("readonly",1);
    	$.post("<?php  echo base_url('student/listpondok'); ?>","",function(data){
    	    pondok=data;
		    $.each(data, function(){
                $('#nama_pondok').append('<option value="'+this.id+'">'+this.nama+'</option>');
            });
        },'json');
        $("select").select2();
        if($("#nama_pondok").val()!="99") $("#nama_pondok2").hide().attr("placeholder","sebutkan");
        $( "input, select" ).each( function(){
            if($(this).val()=='') $(this).css('background-color','lightpink');
        })
        ceklengkap();
        $("button").attr("disabled",true);
    });
    var pondok;
    $("#nama_pondok").change(function(){
        var item = pondok.find(item => item.id ===$("#nama_pondok").val());
        $('#nama_pondok2').val(item.nama);
        $("#pimpinan_pondok").val(item.pengasuh);
        $("#alamat_pondok").val(item.alamat);
        $("#hp_pondok").val(item.hp);
        if($(this).val()=="99") $('#nama_pondok2').val('').show().focus();
        else $('#nama_pondok2').hide();
    });
    var alms=$("#alamat_siswa").val();
    var almo= $("#alamat_ortu").val();
    $("#kabupaten_ortu,#kecamatan_ortu,#kelurahan_ortu,#rt,#rw,#kode_pos_ortu").change(function(){
        if(almo=="") $("#alamat_ortu").val($("#kelurahan_ortu option:selected").html()+" "+" RT: "+$("#rt").val()+"/RW: "+$("#rw").val()+" "+$("#kecamatan_ortu option:selected").html()+" "+$("#kabupaten_ortu option:selected").html()+" "+$("#kode_pos_ortu").val());
    });
    $("#kabupaten_siswa,#kecamatan_siswa,#kelurahan_siswa,#kode_pos_siswa").change(function(){
        if(alms=="") $("#alamat_siswa").val($("#kelurahan_siswa option:selected").html()+" "+$("#kecamatan_siswa option:selected").html()+" "+$("#kabupaten_siswa option:selected").html()+" "+$("#kode_pos_siswa").val());
    });
    var parent;
    function wilayah(a,b,c){
        var wil=[];
        wil[-1]="propinsi";
        wil[0]="propinsi";
        wil[1]="kabupaten";
        wil[2]="kecamatan";
        wil[3]="kelurahan";
        $("#"+wil[a+1]+"_"+b).empty();
        $.post("<?php  echo base_url('listprov?parent='); ?>"+c,"",function(data){
	        $("#"+wil[a+1]+"_"+b).append('<option value=""></option>');
		    $.each(data, function(){
		        $("#"+wil[a+1]+"_"+b).append('<option value="'+this.code+'">'+this.name+'</option>');
            });
        },'json');
    };
    $(".datepicker").datepicker({
    	format: "dd-mm-yyyy",
    	defaultViewDate: {year:2000, month:0, day:1},
    	startView: 2,
    	autoclose: "true",
    });
    $("form").submit(function(e){
        e.preventDefault();
    //     $("#tanggal_lahir").val($("#tanggal_lahir").val().split("-").reverse().join("-"));
    //     $("#tahun_lahir_ayah_kandung").val($("#tahun_lahir_ayah_kandung").val().split("-").reverse().join("-"));
    //     $("#tahun_lahir_ibu_kandung").val($("#tahun_lahir_ibu_kandung").val().split("-").reverse().join("-"));
    //     $("#tahun_lahir_wali").val($("#tahun_lahir_wali").val().split("-").reverse().join("-"));
    //     var values=$(this).serialize();
    //     $("#tanggal_lahir").val($("#tanggal_lahir").val().split("-").reverse().join("-"));
    //     $("#tahun_lahir_ayah_kandung").val($("#tahun_lahir_ayah_kandung").val().split("-").reverse().join("-"));
    //     $("#tahun_lahir_ibu_kandung").val($("#tahun_lahir_ibu_kandung").val().split("-").reverse().join("-"));
    //     $("#tahun_lahir_wali").val($("#tahun_lahir_wali").val().split("-").reverse().join("-"));
    //     swal({
    //     	title:"Menyimpan...", 
    //     	text:"Mohon tunggu sebentar. Jika tidak ada notifikasi sukses, silakan coba lagi",
    //     	type:"warning",
    //     	timer: 10000,
    //     	closeOnCancel: false
    // 	});
    //     $.post("<?php echo base_url("student/simpanfull"); ?>",values,function(){
    //         swal.close();
    //         toastr.success("Data Anda berhasil disimpan","Sukses!");
    //     });
    //     ceklengkap();
    });
    function ceklengkap(){
        $.get("<?php echo base_url("student/ceklengkap"); ?>",function(data){
            $("#lengkap").text(data.i);
            if(parseInt(data.i)>=50) $("#sidebar-menu").show();
        },"json");
    }
	$(':input[type=number]').on('wheel',function(e){ e.preventDefault(); });
	$('input').on('blur',function(){
	    if($(this).val()=='') $(this).css('background-color','lightpink');
	})
	$('input').on('focus',function(){
	    $(this).css('background-color','transparent');
	})
	$("#sidebar-menu").hide();
    history.pushState(null, null, location.href);
    window.onpopstate = function () {
        swal({
        	title:"Konfirmasi", 
        	text:"Ingin meninggalkan halaman?",
        	type:"warning",
        	showCancelButton:true,
            confirmButtonText: "Ya",
            cancelButtonText: "Tidak",
    	}, function(a){
    	    if(a) history.go(-1);
    	    else history.pushState(null, null, location.href);
    	})
    };
</script>