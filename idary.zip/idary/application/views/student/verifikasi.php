<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$fl = array(
  'class'=> 'col-sm-4 control-label'
);
$fc =array(
    'class'=> 'form-control',
    'type'=>'text',
    'autocomplete'=>'off'
);
$op['kelas']=array(
    'MPA'=>array('MPA'=>'MPA'),
    'X (Sepuluh)'=>array('X A'=>'X A / IPA 1', 'X B'=>'X B / IPA 2', 'X C'=>'X C / IPA 3', 'X D'=>'X D / BHS', 'X E'=>'X E / IPS 1', 'X F'=>'X F / IPS 2', 'X G'=>'X G / IPS 3', 'X H'=>'X H / IPS 4', 'X I'=>'X I / IPS 5', 'X J'=>'X J / IPS 6', 'X K'=>'X K / PK 1', 'X L'=>'X L / PK 2', 'X M'=>'X M / PK 3', 'X N'=>'X N / PK 3'),
    'XI (Sebelas)'=>array('XI A'=>'XI A / IPA 1', 'XI B'=>'XI B / IPA 2', 'XI C'=>'XI C / IPA 3', 'XI D'=>'XI D / BHS', 'XI E'=>'XI E / IPS 1', 'XI F'=>'XI F / IPS 2', 'XI G'=>'XI G / IPS 3', 'XI H'=>'XI H / IPS 4', 'XI I'=>'XI I / IPS 5', 'XI J'=>'XI J / IPS 6', 'XI K'=>'XI K / PK 1', 'XI L'=>'XI L / PK 2', 'XI M'=>'XI M / PK 3', 'XI N'=>'XI N / PK 3'),
    'XII (Dua Belas)'=>array('XII A'=>'XII A / IPA 1', 'XII B'=>'XII B / IPA 2', 'XII C'=>'XII C / IPA 3', 'XII D'=>'XII D / BHS 1', 'XII E'=>'XII E / BHS 2', 'XII F'=>'XII F / IPS 1', 'XII G'=>'XII G / IPS 2', 'XII H'=>'XII H / IPS 3', 'XII I'=>'XII I / IPS 4', 'XII J'=>'XII J / IPS 5', 'XII K'=>'XII K / PK 1', 'XII L'=>'XII L / PK 2', 'XII M'=>'XII M / PK 3')
);
$op['jurusan']=array(
     '0'=>'MPA','1'=>'IPA','2'=>'IPS','3'=>'Bahasa','4'=>'Keagamaan'
);
$aturan=array(
    'Gunakan NISN dan nama sesuai ijazah terakhir Anda',
    'Isilah data dengan benar',
    '<b>NISN yang ngawur akan dihapus, beserta seluruh data yang ada</b>. Anda punya 1 pekan untuk memastikan NISN Anda sudah benar',
    'Gunakan password yang mudah diingat, jangan sampai lupa!'
);
if(!isset($nisn)) $nisn=$this->session->userdata('username');
if(!isset($nama_lengkap)) $nama_lengkap=$this->session->userdata('user_fullname');
if(!isset($kelas)) $kelas=null;
if(!isset($jurusan)) $jurusan=null;
if(!isset($absen)) $absen=null;

echo dvo('panel panel-color panel-teal','d0')
	.dvo('panel-heading')
		.heading('Verifikasi Data', 4, 'class="panel-title" id="judul"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		        .po('Selamat datang <b>'.$nama_lengkap.'</b>. Sebelum kita memulai pembelajaran dalam jaringan (daring) atau online, silakan lengkapi data di bawah. Yang perlu Anda perhatikan:')
		        .ol($aturan)
		        .pc()
		        .form_open(base_url('cekjs'),'name="form" id="form" class="form-horizontal" style="background:white"')
    				.dvo('form-group')
    					.form_label('NISN', 'nisn_lama', 'style="display:none"')
    					.dvo('col-sm-8')
        					.form_input('nisn_lama', $nisn, 'style="display:none"')
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('NISN', 'nisn', $fl)
    					.dvo('col-sm-8')
        					.form_input('nisn', $nisn, $fc)
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Nama Lengkap', 'nama_lengkap', $fl)
    					.dvo('col-sm-8')
        					.form_input('nama_lengkap', $nama_lengkap, $fc)
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Password Baru', 'pass_lama', $fl)
    					.dvo('col-sm-8')
        					.form_input('pass_lama', '', 'class="form-control" type="password" required')
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Ulangi Password Baru', 'pass_baru', $fl)
    					.dvo('col-sm-8')
        					.form_input('pass_baru', '', 'class="form-control" type="password" required')
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Kelas', 'kelas', $fl)
    					.dvo('col-sm-8')
        					.form_dropdown('kelas', $op['kelas'],$kelas)
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Jurusan', 'jurusan', $fl)
    					.dvo('col-sm-8')
        					.form_dropdown('jurusan', $op['jurusan'],$jurusan)
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('No. Absen', 'absen', $fl)
    					.dvo('col-sm-8')
        					.form_input('absen', $absen, $fc)
    					.dvc()
    				.dvc()
                	.form_button('simpan','Simpan','btn btn-rounded btn-teal waves-effect waves-light btn-lg btn-block')
                .form_close();
		    echo dvc()
	    .dvc()
    .dvc()
.dvc();
echo JS_SWAL.JS_TOAST;
?>

<script>
    $("#form").submit(function(e){
        e.preventDefault();
        if($("#pass_lama").val()!=$("#pass_baru").val()) {
            swal('Upss....','Password tidak sama. Silakan ulangi','warning');
            $("#pass_lama").focus();
        }
        else if($("#pass_lama").val().length<=7) {
            swal('Upss....','Password minimal 8 karakter. Silakan ulangi','warning');
            $("#pass_lama").focus();
        }
        else if($("#pass_lama").val()=="ungguliptek") {
            swal('Upss....','Ganti password yang lain. Silakan ulangi','warning');
            $("#pass_lama").focus();
        }
        else{
            var values=$(this).serialize();
            swal({
            	title:"Menyimpan...", 
            	text:"Mohon tunggu sebentar. Jika tidak ada notifikasi sukses, silakan coba lagi",
            	type:"warning",
            	timer: 10000,
            	showConfirmButton:false,
            	closeOnCancel: false
        	});
            $.post("<?php echo base_url("student/verifikasi"); ?>",values,function(data){
                swal.close();
                toastr.success('Data berhasil disimpan', 'Sukses!');
                window.location.href="<?php echo base_url('logout');?>";
            });
        }
    });
</script>