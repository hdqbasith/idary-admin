<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// $aturan=array(
//     'Tabel di bawah menunjukkan daftar mapel yang Anda ajukan untuk susulan',
//     'Jika mapel yang Anda cari tidak ada, berarti pengajuan Anda belum diterima oleh Admin atau pengajuan Anda tidak sesuai format yang disediakan',

//     );
$aturan=array(
    'Tabel di bawah menunjukkan daftar mapel yang sudah Anda ikuti',
    'Silakan pastikan bahwa di samping setiap mapel sudah ada tulisan "sudah dikerjakan"',
    'Jika terdapat mapel yang belum dikerjakan/jawaban belum terkirim, silakan klik tombol "Ajukan Susulan"',
    'Setelah mengeklik semua tombol, silakan buat laporan di grup kelas dengan format Nama-NISN-Mapel seperti berikut'.
    '<br/><br/><b>Pengajuan susulan kelas X D</b>'.
    '<br/>1. Muhammad Fakhri-0045858673-Bahasa Indonesia, Antroplogi'.
    '<br/>2. Ahmad Aziz-0048374641-Tafsir, Matematika'.
    '<br/>3. dst<br/><br/>',
    'Kirimkan list pengajuan ke nomor WA Wali Kelas maksimal hari Rabu, 9 Desember 2020 pukul 20.00',
    'Apabila Anda tidak mengirim list mapel ke Wali Kelas, maka link tidak akan diberikan',
    'Pelaksanaan Susulan adalah hari Kamis, 10 Desember 2020 pukul 07.00-20.00',
    'Manfaatkan kesempatan ini dengan baik, karena kesempatan tidak selamanya datang dua kali',
    'Selamat belajar, semoga Anda mendapatkan ilmu yang barokah dan bermanfaat'
	);
echo dvo('panel panel-color panel-orange','d0')
	.dvo('panel-heading')
		.heading('Susulan Penilaian Akhir Semester Gasal 2020', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
    		    .po('Silakan baca dan pahami baik-baik peraturan Susulan Penilaian Akhir Semester Gasal 2020 berikut.')
    		    .ul($aturan)
    		    .pc()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();
echo dvo('panel panel-color panel-teal','d1')
	.dvo('panel-heading')
        // .heading('Daftar Mapel PAS Susulan yang Anda Ajukan', 4, 'class="panel-title"')
		.heading('Daftar Mapel PAS yang sudah Anda kerjakan', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
                .tableo('list','','width=100%')
                    .theado()
                        .tro()
                            .th('Kelas')
                            .th('Mapel')
                            // .th('Token')
                            // .th('Link')
                            .th('Ajukan Susulan')
                            .th('Status')
                        .trc()
                    .theadc()
                    .tbodyo()
                    .tbodyc()
                .tablec()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();
echo JS_SWAL;
?>

<link href="<?php echo base_url()?>assets/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url()?>assets/plugins/datatables/datatables.min.js"></script>
<script>
    $(document).ready(function(){
        $("table").DataTable({
            scrollX:true,
            order: [[ 0, 'asc' ]]
        });
    });
    var kode=<?php echo json_encode($kode);?>;
    var mapel=<?php echo json_encode($mapel);?>;
    var sudahpas=<?php echo json_encode($sudahpas);?>;
    var table='';
    $.each(mapel,function(i,v){
        var statusajuan=0;
        if(kode!=null && kode[v.kode]=="9"){
                sudahpas[v.kode]="<span class=\"text-teal\">Sudah mengajukan susulan. Silakan konfirmasi ke grup WA kelas</span>"; 
                statusajuan=1;
        }
    	else if(sudahpas[v.kode]==null) sudahpas[v.kode]="-"; 
    	else if(sudahpas[v.kode]["waktu_selesai"]!=null) sudahpas[v.kode]="Sudah dikerjakan";
    	else sudahpas[v.kode]='<span class="text-orange">Sedang dikerjakan, belum mengeklik tombol kirim jawaban</span>';
        // table+="<tr><td>"+v.kelas+"</td><td>"+v.pelajaran+"</td><td>"+v.token+"</td><td><a class=\"btn btn-teal\" onclick=\"swall()\" href=\"<?php echo base_url('student/ulangan?mapel=');?>"+v.kode+"\">Klik</a></td><td>"+sudahpas[v.kode]+"</td></tr>";
        if(sudahpas[v.kode]=="Sudah dikerjakan") table+="<tr><td>"+v.kelas+"</td><td>"+v.pelajaran+"</td><td></td><td>"+sudahpas[v.kode]+"</td></tr>";
        else if(statusajuan==0) table+="<tr><td>"+v.kelas+"</td><td>"+v.pelajaran+"</td><td><a class=\"btn btn-teal\" onclick=\"ajukan(\'"+v.kode+"\')\">Ajukan</a></td><td>"+sudahpas[v.kode]+"</td></tr>";
        else table+="<tr><td>"+v.kelas+"</td><td>"+v.pelajaran+"</td><td><a class=\"btn btn-orange\" onclick=\"batalkan(\'"+v.kode+"\')\">Batalkan</a></td><td>"+sudahpas[v.kode]+"</td></tr>";
    })
    $("#list tbody").html(table);
    function ajukan(ajuan){
        perhatian();
        $.get("<?php echo base_url('student/ajukan?mapel='); ?>"+ajuan,function(data){
            if(data=='ok'){
                window.location.reload();
            }
        });
    }
    function batalkan(ajuan){
        perhatian();
        $.get("<?php echo base_url('student/batalkan?mapel='); ?>"+ajuan,function(data){
            if(data=='ok'){
                window.location.reload();
            }
        });
    }
    function perhatian(){
        swal({
            title:"Memproses...", 
            text:"Mohon tunggu sebentar. Jika halaman tidak dialihkan, silakan coba lagi",
            type:"info",
            timer: 20000,
            showConfirmButton:false,
            closeOnCancel: false,
        });
    }
</script>