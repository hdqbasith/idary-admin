<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$fl = array(
  'class'=> 'col-sm-4 control-label'
);
$fc =array(
    'class'=> 'form-control',
    'type'=>'text',
    'autocomplete'=>'off'
);
$op['kelas']=array(
    'MPA'=>array('MPA'=>'MPA'),
    'X (Sepuluh)'=>array('X A'=>'X A / IPA 1', 'X B'=>'X B / IPA 2', 'X C'=>'X C / IPA 3', 'X D'=>'X D / BHS', 'X E'=>'X E / IPS 1', 'X F'=>'X F / IPS 2', 'X G'=>'X G / IPS 3', 'X H'=>'X H / IPS 4', 'X I'=>'X I / IPS 5', 'X J'=>'X J / IPS 6', 'X K'=>'X K / PK 1', 'X L'=>'X L / PK 2', 'X M'=>'X M / PK 3', 'X N'=>'X N / PK 4'),
    'XI (Sebelas)'=>array('XI A'=>'XI A / IPA 1', 'XI B'=>'XI B / IPA 2', 'XI C'=>'XI C / IPA 3', 'XI D'=>'XI D / BHS', 'XI E'=>'XI E / IPS 1', 'XI F'=>'XI F / IPS 2', 'XI G'=>'XI G / IPS 3', 'XI H'=>'XI H / IPS 4', 'XI I'=>'XI I / IPS 5', 'XI J'=>'XI J / IPS 6', 'XI K'=>'XI K / PK 1', 'XI L'=>'XI L / PK 2', 'XI M'=>'XI M / PK 3', 'XI N'=>'XI N / PK 3'),
    'XII (Dua Belas)'=>array('XII A'=>'XII A / IPA 1', 'XII B'=>'XII B / IPA 2', 'XII C'=>'XII C / IPA 3', 'XII D'=>'XII D / BHS 1', 'XII E'=>'XII E / BHS 2', 'XII F'=>'XII F / IPS 1', 'XII G'=>'XII G / IPS 2', 'XII H'=>'XII H / IPS 3', 'XII I'=>'XII I / IPS 4', 'XII J'=>'XII J / IPS 5', 'XII K'=>'XII K / PK 1', 'XII L'=>'XII L / PK 2', 'XII M'=>'XII M / PK 3')
);
$op['mapel']=null;
foreach($mapel as $m){
    $op['mapel'][$m['id']]=$m['pelajaran'].' '.$m['kelas'].' '.date('d M',strtotime($m['date_end']));
}
echo dvo('panel panel-color panel-teal','d1')
	.dvo('panel-heading')
		.heading('Pilih Kelas dan Mapel', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
    	        .form_open(base_url('teacher/presensi'),'method="get" name="form" id="form" class="form-horizontal"')
    				.dvo('form-group')
    					.form_label('Kelas', 'kelas', $fl)
    					.dvo('col-sm-8')
        					.form_dropdown('kelas', $op['kelas'],$kelas)
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Materi', 'id', $fl)
    					.dvo('col-sm-8')
        					.form_dropdown('id', $op['mapel'],$notif_title)
    					.dvc()
    				.dvc()
    				.form_button('simpan','Lihat','btn btn-rounded btn-teal waves-effect waves-light btn-lg btn-block')
                .form_close()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();
echo dvo('panel panel-color panel-orange','d2')
	.dvo('panel-heading')
		.heading('Keaktifan Siswa', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		        .tableo('list','','width=100%')
    		        .theado()
    		            .tro()
    		                .th('NISN')
    		                .th('Nama Siswa')
    		                .th('Kelas')
    		                .th('Presensi')
    		            .trc()
                    .theadc()
                    .tbodyo()
                    .tbodyc()
		        .tablec()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();
?>

<link href="<?php echo base_url()?>assets/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url()?>assets/plugins/datatables/datatables.min.js"></script>

<script>
    $(document).ready(function(){
        $('#list').DataTable({
            scrollX:true,
        });
    });
    var presensi=<?php echo json_encode($presensi);?>;
    var table='';
    $.each(presensi,function(i,v){
        table+="<tr><td>"+v.nisn+"</td><td>"+v.nama_lengkap+"</td><td>"+v.kelas+"</td><td>"+v.notif_status+"</td></tr>";
    })
    $("#list tbody").html(table);
</script>