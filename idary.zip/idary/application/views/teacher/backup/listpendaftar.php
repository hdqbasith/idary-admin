<?php
defined('BASEPATH') OR exit('No direct script access allowed');
echo dvo('panel panel-color panel-teal','d1')
	.dvo('panel-heading')
		.heading('List Pengisi Formulir Pendaftaran', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		        .tableo('list')
    		        .theado()
    		            .tro()
    		                .th('NISN')
    		                .th('Nama')
    		                .th('Asal Sekolah')
    		                .th('Kelas')
    		                .th('Alamat')
    		                .th('No. HP')
    		            .trc()
                    .theadc()
                    .tbodyo();
    		            foreach($listpendaftar as $l){
    		                if($l['hp_ayah']!=null) $l['hp_ayah']=' / '.$l['hp_ayah'];
    		                echo tro().td($l['nisn']).td($l['namasiswa']).td($l['aslsb']).td($l['kelasmts']).td($l['almlengkap']).td($l['hpsiswa'].$l['hp_ayah']).trc();
    		            }
		        echo tbodyc()
		        .tablec()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();
?>
<link href="<?php echo base_url()?>assets/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url()?>assets/plugins/datatables/datatables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.colVis.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/fixedcolumns/3.3.1/js/dataTables.fixedColumns.min.js"></script>
<script>
    $(document).ready(function(){
        $('#list').DataTable({
            scrollX:true,
            pageLength: 50,
            dom: 'Bfrtip',
            buttons: [
            'copy', 'excel', 'pdf','colvis'],
        });
    });
</script>












