<?php

$op['mapel']=array(
    'TPA1'=>'Simulasi'
);
$op['kelas']=array(
    'MPA 1'=>'MPA 1', 'MPA 2'=>'MPA 2', 'X A'=>'X A', 'X B'=>'X B', 'X C'=>'X C', 'X D'=>'X D', 'X E'=>'X E', 'X F'=>'X F', 'X E'=>'X E', 'X F'=>'X F', 'X G'=>'X G', 'X H'=>'X H', 'X I'=>'X I', 'X J'=>'X J', 'X K'=>'X K', 'X L'=>'X L', 'X M'=>'X M', 'X N'=>'X N', 'XI A'=>'XI A', 'XI B'=>'XI B', 'XI C'=>'XI C', 'XI D'=>'XI D', 'XI E'=>'XI E', 'XI F'=>'XI F', 'XI G'=>'XI G', 'XI H'=>'XI H', 'XI I'=>'XI I', 'XI J'=>'XI J', 'XI K'=>'XI K', 'XI L'=>'XI L', 'XI M'=>'XI M'
);
$mapel=$this->input->get('mapel');
$kelas=$this->input->get('kelas');
$fl = array(
    'class'=> 'col-sm-4 control-label'
);
$fc =array(
    'class'=> 'form-control',
    'required'=>'required',
    'type'=>'text',
    'autocomple'=>'off'
);
?>
<div id="d1" style="">
    <div class="col-lg-12">
        <div class="portlet">
            <div class="portlet-heading bg-teal">
                <h3 class="portlet-title">
                    Cek NISN Siswa
                </h3>
                <div class="clearfix"></div>
            </div>
            <div id="bg-teal" class="panel-collapse collapse in">
                <div class="portlet-body">
                    <a class="btn btn-lg btn-orange" href="<?php echo base_url('nisn'); ?>">Klik di sini</a>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="d2" style="">
    <div class="col-lg-12">
        <div class="portlet">
            <div class="portlet-heading bg-teal">
                <h3 class="portlet-title">
                    Cek Absensi Siswa
                </h3>
                <div class="clearfix"></div>
            </div>
            <div id="bg-teal" class="panel-collapse collapse in">
                <div class="portlet-body">
                    <h5>Pilih kelas</h5>
                    <?php
                    echo form_open(base_url('teacher/pat2020'),'class="form-horizontal" method="get"')
        				.dvo('form-group')
        					.form_label('Kelas', 'kelas', $fl)
        					.dvo('col-sm-8')
            					.form_dropdown('kelas', $op['kelas'],$kelas)
        					.dvc()
        				.dvc()
                    	.form_button('','Cek','btn btn-rounded btn-teal waves-effect waves-light btn-lg btn-block')
                    .form_close();
                    ?>
                    <table id="list" class="table">
                        <thead>
                            <tr>
                                <th>Kelas</th>
                                <th>No. Absen</th>
                                <th>Nama</th>
                            </tr>
                        </thead>
                        <tbody id="bt">
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="d3" style="">
    <div class="col-lg-12">
        <div class="portlet">
            <div class="portlet-heading bg-teal">
                <h3 class="portlet-title">
                    Lihat Nilai
                </h3>
                <div class="clearfix"></div>
            </div>
            <div id="bg-teal" class="panel-collapse collapse in">
                <div class="portlet-body">
                    <h5>Pilih kelas</h5>
                    <?php
                    echo form_open(base_url('teacher/pat2020'),'class="form-horizontal" method="get"')
        				.dvo('form-group')
        					.form_label('Kelas', 'kelas', $fl)
        					.dvo('col-sm-8')
            					.form_dropdown('kelas2', $op['kelas'],$kelas)
        					.dvc()
        				.dvc()
        				.dvo('form-group')
        					.form_label('Mapel', 'mapel', $fl)
        					.dvo('col-sm-8')
            					.form_dropdown('mapel', $op['mapel'],$mapel)
        					.dvc()
        				.dvc()
                    	.form_button('','Lihat','btn btn-rounded btn-teal waves-effect waves-light btn-lg btn-block')
                    .form_close();
                    ?>
                    <table id="list2" class="table">
                        <thead>
                            <tr>
                                <th>Kelas</th>
                                <th>No. Absen</th>
                                <th>Nama</th>
                                <th>Nilai</th>
                            </tr>
                        </thead>
                        <tbody id="bt2">
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<link href="<?php echo base_url()?>assets/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url()?>assets/plugins/datatables/datatables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.colVis.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.print.min.js"></script>
<script>
    $(document).ready(function(){
        if("<?echo $this->input->get('mapel'); ?>"==""){
            var data=<?php echo $absen;?>;
            var table='';
            $.each(data,function(index,value){
                table+="<tr><td>"+this.kelas+"</td><td>"+this.absen+"</td><td>"+this.nama+"</td></tr>";
            })
            $("#bt").html(table);
            $('#list').DataTable({});
        } else{
            var data=<?php echo $absen;?>;
            var table='';
            $.each(data,function(index,value){
                table+="<tr><td>"+this.kelas+"</td><td>"+this.absen+"</td><td>"+this.nama+"</td><td>"+this.nilai+"</td></tr>";
            })
            $("#bt2").html(table);
            $('#list2').DataTable({
                "dom": 'Bfrtip',
                "buttons": [
                    'copy', 'excel', 'pdf','colvis'
                ],
            });
        }
    });
</script>