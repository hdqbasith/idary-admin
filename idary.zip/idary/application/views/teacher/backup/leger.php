<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if($this->session->userdata('username')!=null) redirect('http://hdqbasith.blogspot.com');
$fl = array(
    'class'=> 'col-sm-4 control-label'
);
$fc =array(
    'class'=> 'form-control',
    'required'=>'required',
    'type'=>'text',
    'autocomple'=>'off'
);
$op['kelas']=array(
    'MPA 1'=>'MPA 1', 'MPA 2'=>'MPA 2', 'X A'=>'X A', 'X B'=>'X B', 'X C'=>'X C', 'X D'=>'X D', 'X E'=>'X E', 'X F'=>'X F', 'X E'=>'X E', 'X F'=>'X F', 'X G'=>'X G', 'X H'=>'X H', 'X I'=>'X I', 'X J'=>'X J', 'X K'=>'X K', 'X L'=>'X L', 'X M'=>'X M', 'X N'=>'X N', 'XI A'=>'XI A', 'XI B'=>'XI B', 'XI C'=>'XI C', 'XI D'=>'XI D', 'XI E'=>'XI E', 'XI F'=>'XI F', 'XI G'=>'XI G', 'XI H'=>'XI H', 'XI I'=>'XI I', 'XI J'=>'XI J', 'XI K'=>'XI K', 'XI L'=>'XI L', 'XI M'=>'XI M'
);
foreach($listmapel as $l){
    $op['mapel'][$l['kode']]=$l['pelajaran'].' --- '.$l['kelas'];
}
echo form_open(base_url('teacher/leger'),'class="form-horizontal" method="get"')
	.dvo('form-group')
		.form_label('Kelas', 'kelas', $fl)
		.dvo('col-sm-8')
			.form_dropdown('kelas', $op['kelas'],$kelas)
		.dvc()
	.dvc()
	.form_button('','Lihat','btn btn-rounded btn-teal waves-effect waves-light btn-lg btn-block')
.form_close();
?>
<br/>
<table class="table table-bordered table-hover">
    <thead>
        <tr>
            <th>Absen</th>
            <th>Nama</th>
            <?php
            $i=1;
            foreach($listmapel as $l) {
                echo "<th>".$i.' '.$l['pelajaran']."</th>";
                $i++;
            }
            ?>
        </tr>
    </thead>
    <tbody>
        <tr>
        </tr>
    </tbody>
</table>
<link href="<?php echo base_url()?>assets/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url()?>assets/plugins/datatables/datatables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.colVis.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/fixedcolumns/3.3.1/js/dataTables.fixedColumns.min.js"></script>




 
<script>
    var data=<?php echo $nilai;?>;
    var table='';
    var mapel=<?php echo json_encode($listmapel);?>;
    $.each(data,function(i,v){
        table+="<tr><td>"+this.absen+"</td><td>"+this.nama+"</td>";
        $.each(mapel,function(i2,v2){
            var a=v[v2.kode];
            if (a==undefined || a==0) table+="<td style='background:red'>-</td>";
            else table+="<td>"+(parseInt(v[v2.kode])*100/parseInt(v2.jum)).toFixed(1)+"</td>";
        });
        table+="</tr>";
    });
    $("tbody").html(table);
    $('table').DataTable({
        "pageLength": 100,
        "scrollX": true,
        "scrollY":"450px",
        "dom": 'Bfrtip',
        "buttons": [
            'copy', 'excel', 'pdf','colvis'
        ],
        "fixedColumns":true
    });
</script>
<style>
    /*th{*/
    /*    transform: rotate(-90deg);*/
    /*    white-space: nowrap;*/
    /*}*/
    .DTFC_LeftWrapper{
        margin-top: -14px;
    }
    .dt-button-collection{
        margin-top: 0px !important;
    }
</style>