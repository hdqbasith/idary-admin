<?php
defined('BASEPATH') OR exit('No direct script access allowed');
echo dvo('panel panel-color panel-teal','d1')
	.dvo('panel-heading')
		.heading('Daftar Menu', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
            .'<ul>';
                foreach($sidemenus as $menu){
                    if($menu['menu_parent']==0){
                        echo '<li><a class="btn btn-teal" style="margin-bottom:5px" href="';
                        if($menu['menu_link']==null) echo '#';
                        else echo base_url($menu['menu_link']);
                        echo '">'.$menu['menu_name'].'</a></li>';
                        $n=1;
                        foreach($sidemenus as $menu2){
                            if($menu2['menu_parent']==$menu['menu_id']){
                                if($n==1) echo '<ul>';
                                echo '<li><a class="btn btn-teal" style="margin-bottom:5px" href="'.base_url($menu2['menu_link']).'">'.$menu2['menu_name'].'</a></li>';
                                $n=2;
                            }
                        }
                        if($n==2) echo '</ul>';
                    }
                };
            echo '</ul>'
		    .dvc()
	    .dvc()
    .dvc()
.dvc();
?>