<!DOCTYPE html>
<html>
<h1>Terima kasih atas kerjasamanya dalam pelaksanaan Ujian Lokal. Semoga kalian mendapat ilmu yang barokah dan manfaat. Amin...</h1>
</html>