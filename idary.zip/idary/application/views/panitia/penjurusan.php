<?php
defined('BASEPATH') OR exit('No direct script access allowed');
echo dvo('panel panel-color panel-teal','d1')
	.dvo('panel-heading')
		.heading('List Pengisi Formulir Pendaftaran', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		        .tableo('list')
    		        .theado()
    		            .tro()
    		                .th('NISN')
    		                .th('Nama')
    		                .th('Jurusan')
    		                .th('TPA')
    		                .th('MIA')
    		                .th('IIS')
    		                .th('IIB')
    		                .th('IIK')
    		                .th('Jumlah')
    		                .th('Kecurangan')
    		            .trc()
                    .theadc()
                    .tbodyo();
                    $table=null;
                    foreach($hasil["TPA"] as $h){
                        $table[$h['nisn']]['TPA']=$h['nilai'];
                        $table[$h['nisn']]['nama_lengkap']=$h['nama_lengkap'];
                        $table[$h['nisn']]['c1']=$h['pelanggaran'];
                        $table[$h['nisn']]['jurusan']=$h['pil_jurusan'];
                    }
                    foreach($hasil["MIA"] as $h){
                        $table[$h['nisn']]['MIA']=$h['nilai'];
                        $table[$h['nisn']]['nama_lengkap']=$h['nama_lengkap'];
                        $table[$h['nisn']]['c2']=$h['pelanggaran'];
                        $table[$h['nisn']]['jurusan']=$h['pil_jurusan'];
                    }
                    foreach($hasil["IIS"] as $h){
                        $table[$h['nisn']]['IIS']=$h['nilai'];
                        $table[$h['nisn']]['nama_lengkap']=$h['nama_lengkap'];
                        $table[$h['nisn']]['c3']=$h['pelanggaran'];
                        $table[$h['nisn']]['jurusan']=$h['pil_jurusan'];
                    }
                    foreach($hasil["IIB"] as $h){
                        $table[$h['nisn']]['IIB']=$h['nilai'];
                        $table[$h['nisn']]['nama_lengkap']=$h['nama_lengkap'];
                        $table[$h['nisn']]['c4']=$h['pelanggaran'];
                        $table[$h['nisn']]['jurusan']=$h['pil_jurusan'];
                    }
                    foreach($hasil["IIK"] as $h){
                        $table[$h['nisn']]['IIK']=$h['nilai'];
                        $table[$h['nisn']]['nama_lengkap']=$h['nama_lengkap'];
                        $table[$h['nisn']]['c5']=$h['pelanggaran'];
                        $table[$h['nisn']]['jurusan']=$h['pil_jurusan'];
                    }
                    foreach($table as $k=>$t){
                        if(!isset($t['TPA'])) $t['TPA']='0';
                        if(!isset($t['MIA'])) $t['MIA']='0';
                        if(!isset($t['IIS'])) $t['IIS']='0';
                        if(!isset($t['IIB'])) $t['IIB']='0';
                        if(!isset($t['IIK'])) $t['IIK']='0';
                        if(!isset($t['c1'])) $t['c1']='-';
                        if(!isset($t['c2'])) $t['c2']='-';
                        if(!isset($t['c3'])) $t['c3']='-';
                        if(!isset($t['c4'])) $t['c4']='-';
                        if(!isset($t['c5'])) $t['c5']='-';
                        echo tro()
                                .td($k)
                                .td($t['nama_lengkap'])
                                .td($t['jurusan'])
                                .td($t['TPA'])
                                .td($t['MIA'])
                                .td($t['IIS'])
                                .td($t['IIB'])
                                .td($t['IIK'])
                                .td($t['TPA']+$t['MIA']+$t['IIS']+$t['IIB']+$t['IIK'])
                                .td($t['c1'].' '.$t['c2'].' '.$t['c3'].' '.$t['c4'].' '.$t['c5'])
                            .trc();
                    }
		        echo tbodyc()
		        .tablec()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();
?>
<link href="<?php echo base_url()?>assets/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url()?>assets/plugins/datatables/datatables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.colVis.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/fixedcolumns/3.3.1/js/dataTables.fixedColumns.min.js"></script>
<script>
    $(document).ready(function(){
        $('#list').DataTable({
            scrollX:true,
            pageLength: 40,
            dom: 'Bfrtip',
            buttons: [
            'copy', 'excel'],
        });
    });
</script>

<style>
    .dt-button-collection{
        margin-top: 0px !important;
    }
</style>