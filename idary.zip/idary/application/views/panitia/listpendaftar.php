<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$fl = array(
    'class'=> 'col-sm-4 control-label'
);
$fc =array(
    'class'=> 'form-control',
    'required'=>'',
    'type'=>'text',
    'autocomplete'=>'off'
);
$fv=array(
    'class'=> 'form-control',
    'readonly'=>1,
    'style'=>'background-color:white'
);
$op['kelompok']=array(
    ''=>'','1'=>'1','2'=>'2','3'=>'3','4'=>'4','5'=>'5','6'=>'6','7'=>'7','8'=>'8','9'=>'9','10'=>'10','11'=>'11','12'=>'12','13'=>'13','14'=>'14'
);
$kelompok=null;

echo dvo('panel panel-color panel-teal','d1')
	.dvo('panel-heading')
		.heading('List Pengisi Formulir Pendaftaran', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		        .tableo('list')
    		        .theado()
    		            .tro()
    		                .th('NISN')
    		                .th('Nama')
    		                .th('Asal Sekolah')
    		                .th('Kelas')
    		                .th('Alamat')
    		                .th('No. HP')
    		                .th('No. HP baru')
    		                .th('Kel')
    		                .th('')
    		            .trc()
                    .theadc()
                    .tbodyo();
                        $i=0;
    		            foreach($listpendaftar as $l){
    		                $i++;
    		              //  if($l['hp_siswa']==$l['hpsiswa']) $l['hp_siswa']=null;
    		              //  if($l['val']==null) $l['val']='';
    		              //  if($l['hp_ayah']!=null) $l['hp_ayah']=' / '.'<a href="https://wa.me/62'.substr($l['hp_ayah'],1).'">'.$l['hp_ayah'].'</a>';
    		              //  if($l['mpa']==null) echo tro().td($l['nisn']).td($l['namasiswa']).td($l['aslsb']).td($l['kelasmts']).td($l['almlengkap']).td('<a href="https://wa.me/62'.substr($l['hpsiswa'],1).'">'.$l['hpsiswa'].'</a>'.$l['hp_ayah']).td('<a href="https://wa.me/62'.substr($l['hp_siswa'],1).'">'.$l['hp_siswa'].'</a>').td($l['val']).td($l['id']).trc();
    		                if($l['mpa']==null) echo tro().td($l['nisn']).td($l['namasiswa']).td($l['aslsb']).td($l['kelasmts']).td($l['almlengkap']).td($l['hpsiswa'].'/'.$l['hp_ayah']).td($l['hp_siswa']).td($l['val']).td($l['id']).trc();
    		                
    		            }
		        echo tbodyc()
		        .tablec()
		        .$i
		    .dvc()
	    .dvc()
    .dvc()
.dvc();
echo dvo('panel panel-color panel-teal','d2')
	.dvo('panel-heading')
		.heading('Data Siswa Baru', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		        .form_open('','name="formedit" id="formedit" class="form-horizontal" style="background:white"')
    				.dvo('form-group')
    					.form_label('NISN', 'nisn', $fl)
    					.dvo('col-sm-8')
    						.form_input('nisn', '', $fv)
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Nama Siswa', 'namasiswa', $fl)
    					.dvo('col-sm-8')
    						.form_input('namasiswa', '', $fv)
    					.dvc()
    				.dvc()
    				.dvo('form-group')
    					.form_label('Kelompok', 'kelompok', $fl)
    					.dvo('col-sm-8')
        					.form_dropdown('kelompok', $op['kelompok'], $kelompok)
    					.dvc()
    				.dvc()
                	.form_button('simpan','Simpan','btn btn-rounded btn-teal waves-effect waves-light btn-lg btn-block')
                	.br(2).form_button('batal','Batal','btn btn-rounded btn-warning waves-effect waves-light btn-block')
                .form_close()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();
?>
<link href="<?php echo base_url()?>assets/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url()?>assets/plugins/datatables/datatables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.colVis.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/fixedcolumns/3.3.1/js/dataTables.fixedColumns.min.js"></script>
<script>
    $(document).ready(function(){
        $('#list').DataTable({
            scrollX:true,
            pageLength: 40,
            dom: 'Bfrtip',
            buttons: [
            'copy', 'excel', 'pdf','colvis'],
            columnDefs: [
    		    {
    		        "render": function ( data, type, row ) {
    		            var button='<button data-id="'+row[8]+'" onclick="edit($(this).data(\'id\'))" class="btn btn-primary"><i class="mdi mdi-pencil"></i></button>';
                        return button;
                    },
                    "targets": 8
    		    }]
        });
        $("#d2").hide();
    });
    function edit(id){
        $("#d1").hide();
        $("#d2").show();
    }
    var cid;
    $('#list').on( 'click', 'tr', function () {
        cid=$(this).find('td:eq(7)');
        $('#nisn').val($(this).find('td:eq(0)').text());
        $('#namasiswa').val($(this).find('td:eq(1)').text());
        $('#kelompok').val($(this).find('td:eq(7)').text());
    });
    $("#formedit").on("submit",function(e){
        e.preventDefault();
        values = $("#formedit").serialize();
	    $.post("<?php  echo base_url('panitia/matsama_kel'); ?>",values,function(){
	        $(cid).text($('#kelompok').val());
	        $('#d2').hide();
            $('#d1').show();
        });
    })
    $('#batal').click(function(){
        $('#d2').hide();
        $('#d1').show();
    });
</script>

<style>
    .dt-button-collection{
        margin-top: 0px !important;
    }
</style>