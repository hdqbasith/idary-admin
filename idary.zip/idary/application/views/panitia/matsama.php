<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
$fl = array(
    'class'=> 'col-sm-4 control-label'
);
$fc =array(
    'class'=> 'form-control',
    'required'=>'',
    'type'=>'text',
    'autocomplete'=>'off'
);
$fr =array(
    'class'=> 'form-control',
    'required'=>'',
    'readonly'=>'',
    'type'=>'text',
    'autocomplete'=>'off'
);
$peraturan=array(
    'Matsama dilaksanakan sesuai jadwal. Tontonlah video sesuai urutan yang ditentukan',
    'Kedisiplinan Anda akan dinilai secara otomatis oleh aplikasi. Jangan main-main!',
    'Tontonlah video dari awal sampai akhir dan catatlah materi yang penting',
    'Jawablah pertanyaan yang ada di dalam video, ketikkan di kolom yang disediakan di bawah video',
    'Aktivitas Anda di aplikasi akan dideteksi secara otomatis. Jadi pastikan internet Anda lancar agar aktivitas Anda terdeteksi dengan benar',
    'Bagi yang tidak bersungguh-sungguh mengikuti Matsama, panitia akan <b>MENDISKUALIFIKASI PESERTA DARI TES PENJURUSAN</b>',
    'Bagi yang sudah di pondok, silakan tulis jawaban di kertas dan serahkan kepada koordinator kelompok'
);
$no=$this->input->get('nomor');
$disp1='';$disp2='display:none';
if($no>=1 && $no<=9) {$disp1='display:none'; $disp2='';}
$video=array(
    ''=>array('link'=>'','materi'=>'Mohon Refresh Browser Anda'),
    '1'=>array('link'=>'FDCLbyEbgWs','materi'=>'Sambutan Kepala MA NU TBS Kudus'),
    '2'=>array('link'=>'3G9ol-5TonQ','materi'=>'Profil MA NU TBS Kudus'),
    '3'=>array('link'=>'odT6TsLx-5U','materi'=>'Kesiswaan dan Ekstra Kurikuler MA NU TBS Kudus'),
    '4'=>array('link'=>'I-euLuJImwU','materi'=>'Do`a Awal dan Akhir Pembelajaran MA NU TBS Kudus'),
    '5'=>array('link'=>'OU7COqmt-VE','materi'=>'Tata tertib MA NU TBS Kudus'),
    '6'=>array('link'=>'WnseVltxKGA','materi'=>'Lembaga Pengembangan Bakat MA NU TBS Kudus'),
    '7'=>array('link'=>'36xotWSzrLY','materi'=>'Seputar Persatuan Pelajar MA NU TBS Kudus'),
    '8'=>array('link'=>'S5DHCg8Cvw0','materi'=>'Ke-Aswajaan'),
    '9'=>array('link'=>'T80sTTR5kTM','materi'=>'Kurikulum MA NU TBS Kudus'),
);
echo dvo('panel panel-color panel-teal','d0',$disp1)
	.dvo('panel-heading')
		.heading('Masa Ta`aruf Siswa Madrasah (MATSAMA) 2020', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		        .heading('Peraturan Matsama',4)
		        .ol($peraturan);
		    echo dvc()
	    .dvc()
	    .dvo('col-md-12');
	        for($i=1;$i<=9;$i++){
	        echo heading('Materi '.$i,4)
	        .'<a class="btn btn-teal" href="'.base_url('panitia/matsama?nomor=').$i.'">'.$video[$i]['materi'].'</a>';
	        }
	    echo dvc()
    .dvc()
.dvc();
if($no!=null) echo '<a href="'.base_url('panitia/matsama').'" class="btn btn-lg btn-danger btn-rounded">Kembali</a>';
echo dvo('panel panel-color panel-teal','d1',$disp2)
	.dvo('panel-heading')
		.heading($video[$no]['materi'], 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		  //  .dvo('col-md-12')
		  //      .'<video id="dummy" width="160" height="120" autoplay></video>'
		  //  .dvc()
		    .dvo('col-md-12','vid')
    		    .'<iframe id="player" width="100%" src="https://www.youtube.com/embed/'.$video[$no]['link'].'?enablejsapi=1" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>'
		    .dvc()
		    .'<p id="display">Silakan putar video di atas dan isilah kolom jawaban setelah menonton</p>'
	    .dvc()
	    .dvo('col-md-12')
	        .form_open(base_url('cekjs'),'name="f1" id="f1" class="form-horizontal" style="background:white; border-top: 3px solid; margin-top:50px"')
				.dvo('form-group')
					.form_label('Materi', 'materi', $fl)
					.dvo('col-sm-8')
						.form_input('materi', $video[$no]['materi'], $fr)
					.dvc()
				.dvc()
				.dvo('form-group')
					.form_label('Persentase menonton', 'persen', $fl)
					.dvo('col-sm-8')
						.form_input('persen', '', $fr)
					.dvc()
				.dvc()
				.dvo('form-group')
					.form_label('Jawaban', 'jawaban', $fl)
					.dvo('col-sm-8')
						.form_textarea(['id'=>'jawaban','name'=>'jawaban','rows'=>'3'], 'masukkan jawaban di sini', $fc)
					.dvc()
				.dvc()
            	.form_button('simpan','Simpan','btn btn-rounded btn-teal waves-effect waves-light btn-lg btn-block')
            .form_close()
	    .dvc()
    .dvc()
.dvc();
?>
<script src="https://www.youtube.com/iframe_api"></script>
<script>
    $(document).ready(function(){
        $("#d2,#d3,#d4,#d5,#d6,#d7,#d8,#d9").hide();
    })
    $("form").on("submit",function(e){
        e.preventDefault();
        var values = $(this).serialize();
        alert(values);
        $.post("<?php  echo base_url('panitia/matsama_jawab'); ?>",values,function(){
            alert('Jawaban Anda sudah tersimpan');
        })
    });
    // var video = document.getElementById('dummy');
    // var localstream;
    // if(navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
    //     navigator.mediaDevices.getUserMedia({ video: true }).then(function(stream) {
    //         localstream=stream;
    //         video.srcObject = stream;
    //         video.play();
    //         localstream.getTracks().map(function (val) {
    //             val.stop();
    //         });
    //     });
    // }
    var player, timer, timeSpent = [], display = document.getElementById('display');

    function onYouTubeIframeAPIReady() {
    	player = new YT.Player( 'player', {
    		events: { 'onStateChange': onPlayerStateChange }
    	});
    }
    
    function onPlayerStateChange(event) {
    	if(event.data === 1) { // Started playing
            if(!timeSpent.length){
                for(var i=0, l=parseInt(player.getDuration()); i<l; i++) timeSpent.push(false);
            }
    	    timer = setInterval(record,100);
        } else {
    		clearInterval(timer);
    	}
    }
    
    function record(){
    	timeSpent[ parseInt(player.getCurrentTime()) ] = true;
    	showPercentage();
    }
    
    function showPercentage(){
        var percent = 0;
        for(var i=0, l=timeSpent.length; i<l; i++){
            if(timeSpent[i]) percent++;
        }
        percent = Math.round(percent / timeSpent.length * 100);
        display.innerHTML = "Anda telah menonton video ini sebanyak <span class=\"btn btn-teal\">"+percent + "%</span>";
        $("#persen").val(percent + "%");
    }
    $(document).on("visibilitychange", function() {
      if ( player ) {
        if ( document.hidden ) {
          player.pauseVideo();
        } else {
          player.playVideo();
        }
      }
    });
</script>

<style>
    #vid {
        position: relative;
        padding-bottom: 56.25%; /* 16:9 */
        height: 0;
    }
    #vid iframe {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
    }
</style>