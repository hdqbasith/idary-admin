<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
$fl = array(
    'class'=> 'col-sm-4 control-label'
);
$fc =array(
    'class'=> 'form-control',
    'required'=>'',
    'type'=>'text',
    'autocomplete'=>'off'
);
$op['kelompok']=array(
    ''=>'Semua','1'=>'1','2'=>'2','3'=>'3','4'=>'4','5'=>'5','6'=>'6','7'=>'7','8'=>'8','9'=>'9','10'=>'10','11'=>'11','12'=>'12','13'=>'13','14'=>'14'
);
$op['materi']=array(
    '1'=>'Sambutan Kepala MA NU TBS Kudus',
    '2'=>'Profil MA NU TBS Kudus',
    '3'=>'Kesiswaan dan Ekstra Kurikuler MA NU TBS Kudus',
    '4'=>'Do`a Awal dan Akhir Pembelajaran MA NU TBS Kudus',
    '5'=>'Tata tertib MA NU TBS Kudus',
    '6'=>'Lembaga Pengembangan Bakat MA NU TBS Kudus',
    '7'=>'Seputar Persatuan Pelajar MA NU TBS Kudus',
    '8'=>'Ke-Aswajaan',
    '9'=>'Kurikulum MA NU TBS Kudus'
);
echo dvo('panel panel-color panel-teal','d1')
	.dvo('panel-heading')
		.heading('Pilih Kelompok dan Materi', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
	        .form_open(base_url('panitia/matsama_presensi'),'method="get" name="f1" id="f1" class="form-horizontal" style="background:white; border-top: 3px solid; margin-top:50px"')
				.dvo('form-group')
					.form_label('Materi', 'materi', $fl)
					.dvo('col-sm-8')
						.form_dropdown('materi', $op['materi'], $mat)
					.dvc()
				.dvc()
				.dvo('form-group')
					.form_label('Kelompok', 'kelompok', $fl)
					.dvo('col-sm-8')
						.form_dropdown('kelompok', $op['kelompok'], $kelompok)
					.dvc()
				.dvc()
            	.form_button('lihat','Lihat','btn btn-rounded btn-teal waves-effect waves-light btn-lg btn-block')
            .form_close()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();
echo dvo('panel panel-color panel-teal','d2')
	.dvo('panel-heading')
		.heading('Keaktifan Siswa', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		        .tableo('list','','width=100%')
    		        .theado()
    		            .tro()
    		                .th('NISN')
    		                .th('Nama')
    		                .th('Waktu')
    		                .th('Jawaban Soal')
    		                .th('Keaktifan')
    		            .trc()
                    .theadc()
                    .tbodyo()
    		        .tbodyc()
		        .tablec()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();
?>
<link href="<?php echo base_url()?>assets/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url()?>assets/plugins/datatables/datatables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.colVis.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/fixedcolumns/3.3.1/js/dataTables.fixedColumns.min.js"></script>
<script>
    var pes=<?php echo $peserta; ?>;
    var peserta={};
    var presensi=<?php echo $presensi; ?>;
    var table;
    $.each(pes,function(index,value){
        peserta[value.nisn]=pes[index];
        // peserta[value.nisn]['var']='';
    })
    $.each(presensi,function(index,value){
        if(peserta[value.nisn]!=undefined){
            peserta[value.nisn]['val']=value.val;
            peserta[value.nisn]['catatan']=value.catatan;
            peserta[value.nisn]['date']=value.date;
        }
    })
    $.each(peserta,function(index,value){
        if(this.date==undefined) this.date="-";
        if(this.val==undefined) this.val="-";
        if(this.catatan==undefined) this.catatan="-";
        table+="<tr><td>"+this.nisn+"</td><td>"+this.namasiswa+"</td><td>"+this.date+"</td><td>"+this.val+"</td><td>"+this.catatan+"</td></tr>";
    })
    $("tbody").html(table);
    $('table').DataTable({
        "pageLength": 40,
        "scrollX": true,
        "dom": 'Bfrtip',
        "buttons": [
            'copy', 'excel'
        ]
    });
</script>