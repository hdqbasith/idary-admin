<link href="<?php echo base_url()?>assets/css/login.css" rel="stylesheet"/>
<div id="overlay" class="spinner-border text-success" role="status">
  <span class="sr-only">Loading...</span>
</div>
<div class="form">
  <h3>Idary Admin</h3>
  <h5>Pusat Data MA NU TBS Kudus</h5>
  <ul class="tab-group">
    <li class="tab active"><a href="#login">Masuk</a></li>
    <li class="tab"><a href="#signup">Daftar</a></li>
  </ul>
  <div class="tab-content">
    <div id="login">
      <h5>Masukkan username dan password Anda</h5>
      <form name='masuk' id='masuk' action="cekjs" method="post">
        <div class="field-wrap">
          <label class="active highlight">
            Username<span class="req">*</span>
          </label>
          <input type="text" required autocomplete="off" name='username' id='un2'></input>
        </div>
        <div class="field-wrap">
          <label class="active highlight">
            Password<span class="req">*</span>
          </label>
          <input type="password" required autocomplete="off" name='password'></input>
        </div>
        <p class="forgot"><a href="#">Lupa Password?</a></p>
        <button class="button button-block"/>Log In</button>
      </form>
    </div>
    <div id="signup">
      <h5>Masukkan NISN Anda</h5>
      <form name='daftar' id='daftar' action="cekjs" method="post">
        <div class="field-wrap">
          <label class="active highlight">
            NISN<span class="req">*</span>
          </label>
          <input type="number" required autocomplete="off" name='nisn' id='un1'></input>
        </div>
        <button type="submit" class="button button-block">Lanjut</button>
      </form>
    </div>
  </div>
</div>
<script>
$(document).ready(function() {
	$('#daftar').submit(function() {
		values = jQuery("#daftar").serialize();
		$.post("<?php  echo $hrefdaftar; ?>",values,function(data){
			if(data==''){
			    alert('NISN sudah ada. Silahkan klik "Masuk" untuk masuk ke sistem');
			} else{
			    location.href="<?php echo base_url('student/formulir_ppdb?action=new&nisn='); ?>"+data;
			}
    	});
    	return false;
	});
	$('#masuk').submit(function() {
		values = jQuery("#masuk").serialize();
		$.post("<?php echo $hrefmasuk;?>",values,function(data){
		    if(data==''){
		        alert('Ups...! Username dan password tidak cocok.'+data);
		    } else{
		        location.href=data;
		    }
    	});
    	return false;
	});
	if(location.href.split('#')[1]=='signup') $('.tab a').click();
});
$('.tab a').on('click', function (e) {
	e.preventDefault();
	$(this).parent().addClass('active');
	$(this).parent().siblings().removeClass('active');
	target = $(this).attr('href');
	$('.tab-content > div').not(target).fadeOut();
	$(target).fadeIn(600);
});
$(':input[type=number]').on('wheel', function (e) {
	$(this).blur();
});

</script>