<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Pusat Data MA NU TBS Kudus yang dikembangkan bersama HDQBasith Studio">
        <meta name="author" content="Hadziqi Basith">

        <link rel="shortcut icon" href="<?php echo base_url()?>assets/images/favicon.ico">

        <title>Master Data MA NU TBS</title>

        <!-- App css -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <link href="<?php echo base_url()?>assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url()?>assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url()?>assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url()?>assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url()?>assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url()?>assets/css/responsive.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="<?php echo base_url()?>plugins/switchery/switchery.min.css">

        <!-- HTML5 Shiv and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->
        <script src="<?php echo base_url()?>assets/js/modernizr.min.js"></script>
        <script
			  src="https://code.jquery.com/jquery-3.4.1.min.js"
			  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
			  crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

    </head>
    <body>
        <div class="row container" style="">
            <div class="col-md-12">
                <div class="card-box">
                    <a href="/" style="margin-top:50px;"><buton class="btn btn-danger btn-large btn-block">Kembali ke halaman utama</buton></a>
                    <h4 class="text-center">Ujian Lokal
                    <br/>MA NU TBS Kudus
                    <br/>Tahun Pelajaran 1440-1441 H / 2019-2020 M
                    </h4>
                    <p>Panduan pelaksanaan dan cara mengerjakan ujian Lokal sistem Daring (online)
                        <ol>
                            <li>Klik download soal dan pilih soal sesuai dengan jurusan kalian</li>
                            <li>Download soal lalu kerjakan di kertas biasa, apabila telah selesai maka isikan secara online pada Link yang tersedia</li>
                            <li>Waktu mengerjakan sesuai pada jadwal, keterlambatan bisa mengakibatkan pengurangan nilai</li>
                            <li>Jika tidak bisa mengerjakan sesuai jadwal, harap menghubungi guru fan masing-masing dengan menyertakan alasan yang sebenar-benarnya</li>
                            <li>Jangan lupa mengisi mapel, nama lengkap, kelas dan nomor absen pada lembar jawab</li>
                            <li>Cara mengisi jawaban pilihan ganda:
                                <ul>
                                    <li>Klik A/B/C/D/E pada kolom sesuai dengan nomor soal</li>
                                    <li>Jika jumlah soal hanya 40, abaikan nomor 41-50. Jika terlanjur sudah diisi, tidak masalah</li>
                                </ul>
                            </li>
                            <li>Cara mengisi jawaban esai
                                <ul>
                                    <li>Tulis jawaban sesuai kolom nomor soal</li>
                                    <li><b>Untuk jawaban yang tidak bisa diketik (rumus/tulisan arab), silakan tulis tangan, lalu upload di google drive/blogger/wordpress/facebook/instagram/twitter/situs lainnya, kemudian copy linknya dan masukkan di lembar jawab.</b></li>
                                </ul>
                            </li>
                            <li>Sebelum mengirim jawaban, pastikan semua jawaban sudah diisi dengan benar. <b>Panitia tidak menyediakan fitur update jawaban</b></li>
                        </ol>
                    </p>
                    <h5 class="text-center">Jadwal Ujian Lokal</h5>
                    <table class="table table-bordered text-center">
                        <thead>
                            <tr>
                                <th rowspan=2>No.</th>
                                <th rowspan=2>Hari/Tanggal</th>
                                <th rowspan=2>Waktu</th>
                                <th colspan=4>Mapel</th>
                            </tr>
                            <tr>
                                <th>IPA</th>
                                <th>IPS</th>
                                <th>BHS</th>
                                <th>PK</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td rowspan=2>1</td>
                                <td rowspan=2>Selasa<br/>20 Sya'ban 1441 H /<br/>14 April 2020 M</td>
                                <td rowspan=2>07.30-20.00</td>
                                <td>Qiroatul Kitab</td>
                                <td>Qiroatul Kitab</td>
                                <td>Qiroatul Kitab</td>
                                <td>Qiroatul Kitab</td>
                            </tr>
                            <tr>
                                <td>Falak</td>
                                <td>Falak</td>
                                <td>-</td>
                                <td>Falak</td>
                            </tr>
                            <tr>
                                <td rowspan=2>2</td>
                                <td rowspan=2>Rabu<br/>21 Sya'ban 1441 H /<br/>15 April 2020 M</td>
                                <td rowspan=2>07.30-20.00</td>
                                <td>Qiro`ah Sab`ah</td>
                                <td>Qiro`ah Sab`ah</td>
                                <td>Qiro`ah Sab`ah</td>
                                <td>Qiro`ah Sab`ah</td>\
                            </tr>
                            <tr>
                                <td>Ilmu Manthiq</td>
                                <td>Ilmu Manthiq</td>
                                <td>Ilmu Manthiq</td>
                                <td>Ilmu Manthiq</td>
                            </tr>
                            <tr>
                                <td rowspan=2>3</td>
                                <td rowspan=2>Kamis<br/>22 Sya'ban 1441 H /<br/>16 April 2020 M</td>
                                <td rowspan=2>07.30-20.00</td>
                                <td>Tafsir</td>
                                <td>Tafsir</td>
                                <td>Tafsir</td>
                                <td>Tafsir</td>
                            </tr>
                            <tr>
                                <td>Tauhid</td>
                                <td>Tauhid</td>
                                <td>Tauhid</td>
                                <td>Tauhid</td>
                            </tr>
                            <tr>
                                <td rowspan=2>4</td>
                                <td rowspan=2>Sabtu<br/>24 Sya'ban 1441 H /<br/>18 April 2020 M</td>
                                <td rowspan=2>07.30-20.00</td>
                                <td>Hadits</td>
                                <td>Hadits</td>
                                <td>Hadits</td>
                                <td>Hadits</td>
                            </tr>
                            <tr>
                                <td>Tasawuf</td>
                                <td>Tasawuf</td>
                                <td>Tasawuf</td>
                                <td>Tasawuf</td>
                            </tr>
                            <tr>
                                <td rowspan=2>5</td>
                                <td rowspan=2>Ahad<br/>25 Sya'ban 1441 H /<br/>19 April 2020 M</td>
                                <td rowspan=2>07.30-20.00</td>
                                <td>Balaghoh</td>
                                <td>Balaghoh</td>
                                <td>Balaghoh</td>
                                <td>Balaghoh</td>
                            </tr>
                            <tr>
                                <td>Nahwu</td>
                                <td>Nahwu</td>
                                <td>Nahwu</td>
                                <td>Nahwu</td>
                            </tr>
                            <tr>
                                <td rowspan=2>6</td>
                                <td rowspan=2>Senin<br/>26 Sya'ban 1441 H /<br/>20 April 2020 M</td>
                                <td rowspan=2>07.30-20.00</td>
                                <td>Ushul Fiqih</td>
                                <td>Ushul Fiqih</td>
                                <td>Ushul Fiqih</td>
                                <td>Qowaid Fiqih</td>
                            </tr>
                            <tr>
                                <td>Ilmu Nafsi</td>
                                <td>Ilmu Nafsi</td>
                                <td>Ilmu Nafsi</td>
                                <td>Ilmu Nafsi</td>
                            </tr>
                        </tbody>
                    </table>
                    
                    <?php 
                    
                    if(strtotime(date("Y-m-d H:i:s")) <= strtotime('2020/04/14 07:30:00')) echo '<a href="#" onClick="alert(\'Soal belum diupload, mohon tunggu...\')"><buton class="btn btn-primary btn-large btn-block">Download Soal</buton></a><br/>';
                    if(strtotime('2020/04/14 07:30:00') <= strtotime(date("Y-m-d H:i:s")) && strtotime(date("Y-m-d H:i:s")) <= strtotime('2020/04/14 20:00:00')) echo '<a href="https://drive.google.com/open?id=1F-gYCScXnnONH6v72lwf-EiZUkjwa-83" <buton class="btn btn-primary btn-large btn-block">Download Soal</buton></a><br/>';
                    if(strtotime('2020/04/15 07:30:00') <= strtotime(date("Y-m-d H:i:s")) && strtotime(date("Y-m-d H:i:s")) <= strtotime('2020/04/15 20:00:00')) echo '<a href="https://drive.google.com/open?id=1cPuUqwm66h8oQ3P_S16aWXouK2-cVtzP" <buton class="btn btn-primary btn-large btn-block">Download Soal</buton></a><br/>';
                    if(strtotime('2020/04/16 07:30:00') <= strtotime(date("Y-m-d H:i:s")) && strtotime(date("Y-m-d H:i:s")) <= strtotime('2020/04/16 20:00:00')) echo '<a href="https://drive.google.com/open?id=1275lYjv6rjoTk27JzCLFFal0bu8NglBo" <buton class="btn btn-primary btn-large btn-block">Download Soal</buton></a><br/>';
                    if(strtotime('2020/04/18 07:30:00') <= strtotime(date("Y-m-d H:i:s")) && strtotime(date("Y-m-d H:i:s")) <= strtotime('2020/04/18 20:00:00')) echo '<a href="https://drive.google.com/open?id=1SzyTQv8z7CbzrbBBs27XzbFH0n7Xdc2v" <buton class="btn btn-primary btn-large btn-block">Download Soal</buton></a><br/>';
                    if(strtotime('2020/04/19 07:30:00') <= strtotime(date("Y-m-d H:i:s")) && strtotime(date("Y-m-d H:i:s")) <= strtotime('2020/04/19 20:00:00')) echo '<a href="https://drive.google.com/open?id=1sgm-pnvOFGJzwiaRWV-ZoLizPPKrnIdP" <buton class="btn btn-primary btn-large btn-block">Download Soal</buton></a><br/>';
                    if(strtotime('2020/04/20 07:30:00') <= strtotime(date("Y-m-d H:i:s")) && strtotime(date("Y-m-d H:i:s")) <= strtotime('2020/04/20 20:00:00')) echo '<a href="https://drive.google.com/open?id=1NTQI1_Sq36FoQjVftaICQ5Ox4f9i1wn4" <buton class="btn btn-primary btn-large btn-block">Download Soal</buton></a><br/>';
                    ?>
                    <a href="https://masterdata.adminbaru.com/admin/jawab"><buton class="btn btn-success btn-large btn-block">Lembar jawab</buton></a><br/>
                    <a href="https://masterdata.adminbaru.com/admin/listterkirim"><buton class="btn btn-brown btn-large btn-block">List yang sudah mengumpulkan</buton></a>
                    
                </div>
                
            </div>
        </div>
    </body>
<script>
    var blurred = 0;
    window.onblur = function() { blurred++; };
    window.onfocus = function() { 
        if(blurred==10) location.reload();
    };
    $(document).bind('copy', function(e) {
        blurred++;
        if(blurred==10) location.reload();
    }); 
</script>
</html>
