<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Pusat Data MA NU TBS Kudus yang dikembangkan bersama HDQBasith Studio">
        <meta name="author" content="Hadziqi Basith">

        <link rel="shortcut icon" href="<?php echo base_url()?>assets/images/favicon.ico">

        <title>Master Data MA NU TBS</title>

        <!-- App css -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <link href="<?php echo base_url()?>assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url()?>assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url()?>assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url()?>assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url()?>assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url()?>assets/css/responsive.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="<?php echo base_url()?>plugins/switchery/switchery.min.css">
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css"/>
        <link href="<?php echo base_url()?>assets/plugins/bootstrap-sweetalert/sweet-alert.css" rel="stylesheet" type="text/css">

        <!-- HTML5 Shiv and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->
        <script src="<?php echo base_url()?>assets/js/modernizr.min.js"></script>
        <script
			  src="https://code.jquery.com/jquery-3.4.1.min.js"
			  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
			  crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url()?>assets/plugins/bootstrap-sweetalert/sweet-alert.min.js"></script>

    </head>
    <body>
        <div class="row container" style="">
            <div class="col-md-12">
                <div class="card-box">
                    <h4 class="text-center">List siswa yang sudah mengirimkan jawaban UM
                    </h4>
                    <form id="form1" name="form1" enctype="multipart/form-data" method="post" class="form-horizontal" action="listterkirim" onsubmit="">
    					<div class="row">
    						<div class="col-md-12">
    							<div class="form-group row">
    								<label for="mapel" class="col-sm-4 control-label">Mapel</label>
    								<div class="col-sm-8">
    									<select id="mapel" name="mapel" class="form-control">
    									    <option></option>
    									    <option>Qiroatul Kitab</option>
    									    <option>Falak</option>
    									    <option>Qiro`ah Sab`ah</option>
    									    <option>Ilmu Manthiq</option>
    									    <option>Tafsir</option>
    									    <option>Tauhid</option>
    									    <option>Hadits</option>
    									    <option>Tasawuf</option>
    									    <option>Balaghoh</option>
    									    <option>Nahwu</option>
    									    <option>Ushul Fiqih</option>
    									    <option>Ilmu Nafsi</option>
    									    <option>Qowaid Fiqih</option>
    									</select>
    								</div>
    							</div>
    							<div class="form-group row">
    								<label for="kelas" class="col-sm-4 control-label">Kelas</label>
    								<div class="col-sm-8">
    									<select id="kelas" name="kelas" class="form-control">
    									    <option></option>
    									    <option>XII A (IPA 1)</option>
    									    <option>XII B (IPA 2)</option>
    									    <option>XII C (IPA 3)</option>
    									    <option>XII D (BHS 1)</option>
    									    <option>XII E (BHS 2)</option>
    									    <option>XII F (IPS 1)</option>
    									    <option>XII G (IPS 2)</option>
    									    <option>XII H (IPS 3)</option>
    									    <option>XII I (IPS 4)</option>
    									    <option>XII J (IPS 5)</option>
    									    <option>XII K (PK 1)</option>
    									    <option>XII L (PK 2)</option>
    									    <option>XII M (PK 3)</option>
    									</select>
    								</div>
    							</div>
    						</div>
    					<button id="lihat" class="btn btn-large btn-block btn-success">Lihat</button>
                    </form>
                    <div class="col-md-12" style="margin-top:50px;">
                        <table id="tabel" class="table table-bordered">
                            <thead>
                                <tr>
                                    <td>No. Absen</td>
                                    <td>Nama</td>
                                    <td>Kelas</td>
                                    <td>Mapel</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($lihat as $l){
                                    echo '<tr>
                                        <td>'.$l->absen.'</td>
                                        <td>'.$l->nama.'</td>
                                        <td>'.$l->kelas.'</td>
                                        <td>'.$l->mapel.'</td>
                                    </tr>';
                                } 
                                ?>
                            </tbody>
                        </table>
                    <a href="/" style="margin-top:50px;"><buton class="btn btn-danger btn-large btn-block">Kembali ke halaman utama</buton></a>
                    </div>
                </div>
                
            </div>
        </div>
    </body>
    <script>
        $(document).ready(function(){
    	    $('#tabel').DataTable();
        });
    </script>
</html>

