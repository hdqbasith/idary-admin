<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Pusat Data MA NU TBS Kudus yang dikembangkan bersama HDQBasith Studio">
        <meta name="author" content="Hadziqi Basith">

        <link rel="shortcut icon" href="<?php echo base_url()?>assets/images/favicon.ico">

        <title>Master Data MA NU TBS</title>

        <!-- App css -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <link href="<?php echo base_url()?>assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url()?>assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url()?>assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url()?>assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url()?>assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url()?>assets/css/responsive.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="<?php echo base_url()?>plugins/switchery/switchery.min.css">

        <!-- HTML5 Shiv and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->
        <script src="<?php echo base_url()?>assets/js/modernizr.min.js"></script>
        <script
			  src="https://code.jquery.com/jquery-3.4.1.min.js"
			  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
			  crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

    </head>
    <body>
        <div class="row container" style="">
            <div class="col-md-12">
                <a href="/" style="margin-top:50px;"><buton class="btn btn-danger btn-large btn-block">Kembali ke halaman utama</buton></a>
                <div class="card-box">
                    <h4 class="text-center">Penilaian Tengah Semester<br/>MA NU TBS Kudus<br/>Tahun Pelajaran 1440-1441 H / 2019-2020 M</h4>
                    <ol>Panduan Pengerjaan Soal Penilaian Tengah Semester Genap
                        <li>Download soal dari <a href="https://drive.google.com/drive/folders/1SIEah24iDlr_aJ0v54LgrCtvVmDP1aN_?usp=sharing">googledrive</a></li>
                        <li>Kerjakan di kertas folio bergaris, satu mapel satu folio</li>
                        <li>Tulis Nama, Kelas, Nomor absen, dan mapel di pojok kanan kertas</li>
                        <li>Kerjakan semua soal dengan tulisan yang mudah dibaca</li>
                        <li>Foto pekerjaan kalian, pastikan bisa terbaca, lalu upload ke google classroom (caranya ada di bawah).</li>
                        <li>Simpanlah pekerjaan Asli kalian dalam stopmap</li>
                        <li>Waktu pengerjaan sampai hari Senin, 6 April 2020, bagi siswa yang telah selesai bisa melapor kepada wali kelas dengan memfoto map berisi hasil kerjaannya</li>
                        <li>Waktu pengumpulan jawaban Asli adalah hari pertama KBM (waktu ditentukan kemudian) kepada ketua kelas masing-masing</li>
                        <li>Ketua kelas bertugas mengumpulkan jawaban dan mengelompokkannya berdasarkan mapel kemudian menyerahkannya kepada guru fan masing-masing</li>
                        <li>Selama masih lockdown dan PTS telah selesai dilaksanakan, siswa akan diberikan tugas individu tambahan setiap mapel (tugas akan diberikan pada laman ini)</li>
                        <li>Apabila dalam waktu yang sudah ditentukan, KBM masih dilaksanakan mandiri di rumah, maka tugas selanjutnya akan diberitahukan pada laman ini</li>
                    </ol>
                    <ol>Panduan upload jawaban Penilaian Tengah Semester Genap
                        <li>Buka <a href="https://classroom.google.com">Google Classrom</a> atau download aplikasi <a href="https://play.google.com/store/apps/details?id=com.google.android.apps.classroom&hl=in">Google Classroom</a></li>
                        <li>Klik tanda + di sebelah kanan atas, pilih Join Class (Gabung ke kelas), masukkan kode dibawah:</li>
                        <li>Upload Pekerjaan pada menu "New Assignment / Tugas Baru"</li>
                        <table class="table table-colored-bordered table-bordered-teal">
                            <thead>
                                <tr>
                                    <th>Kelas</th>
                                    <th>Kode</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr><td>MPA 1</td><td>btp2szi</td></tr>
                                <tr><td>MPA 2</td><td>7zmcw5d</td></tr>
                                <tr><td>X A / MIA 1</td><td>qjs5xez</td></tr>
                                <tr><td>X B / MIA 2</td><td>dshsoz2</td></tr>
                                <tr><td>X C / MIA 3</td><td>y4ypzcc</td></tr>
                                <tr><td>X D / IBB</td><td>vflsnkz</td></tr>
                                <tr><td>X E / IIS 1</td><td>67ygksw</td></tr>
                                <tr><td>X F / IIS 2</td><td>4xbcd2n</td></tr>
                                <tr><td>X G / IIS 3</td><td>gloxekm</td></tr>
                                <tr><td>X H / IIS 4</td><td>eiktpif</td></tr>
                                <tr><td>X I / IIS 5</td><td>ras52dm</td></tr>
                                <tr><td>X J / IIS 6</td><td>isakvxo</td></tr>
                                <tr><td>X K / IIK 1</td><td>pw342u5</td></tr>
                                <tr><td>X L / IIK 2</td><td>akwrg2m</td></tr>
                                <tr><td>X M / IIK 3</td><td>vg7hfo7</td></tr>
                                <tr><td>X N / IIK 4</td><td>jhzugwq</td></tr>
                                <tr><td>XI A / MIA 1</td><td>5rvq4l2</td></tr>
                                <tr><td>XI B / MIA 2</td><td>uggkxav</td></tr>
                                <tr><td>XI C / MIA 3</td><td>bsxaabt</td></tr>
                                <tr><td>XI D / IBB 1</td><td>63djath</td></tr>
                                <tr><td>XI E / IBB 2</td><td>rkuoeux</td></tr>
                                <tr><td>XI F / IIS 1</td><td>nzwgewy</td></tr>
                                <tr><td>XI G / IIS 2</td><td>qal4lhw</td></tr>
                                <tr><td>XI H / IIS 3</td><td>cxjuvd6</td></tr>
                                <tr><td>XI I / IIS 4</td><td>eld7nh6</td></tr>
                                <tr><td>XI J / IIS 5</td><td>zsgmke6</td></tr>
                                <tr><td>XI K / IIK 1</td><td>dgeho6s</td></tr>
                                <tr><td>XI L / IIK 2</td><td>rghju46</td></tr>
                                <tr><td>XI M / IIK 3</td><td>awlm4zk</td></tr>
                            </tbody>
                        </table>
                        <li>Selamat Belajar #KamuDirumahAja</li>
                    </ol>
                </div>
                
            </div>
        </div>
    </body>
</html>

