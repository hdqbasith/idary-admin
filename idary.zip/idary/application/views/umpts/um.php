<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Pusat Data MA NU TBS Kudus yang dikembangkan bersama HDQBasith Studio">
        <meta name="author" content="Hadziqi Basith">

        <link rel="shortcut icon" href="<?php echo base_url()?>assets/images/favicon.ico">

        <title>Master Data MA NU TBS</title>

        <!-- App css -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <link href="<?php echo base_url()?>assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url()?>assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url()?>assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url()?>assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url()?>assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url()?>assets/css/responsive.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="<?php echo base_url()?>plugins/switchery/switchery.min.css">

        <!-- HTML5 Shiv and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->
        <script src="<?php echo base_url()?>assets/js/modernizr.min.js"></script>
        <script
			  src="https://code.jquery.com/jquery-3.4.1.min.js"
			  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
			  crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

    </head>
    <body>
        <div class="row container" style="">
            <div class="col-md-12">
                <div class="card-box">
                    <a href="/" style="margin-top:50px;"><buton class="btn btn-danger btn-large btn-block">Kembali ke halaman utama</buton></a>
                    <h4 class="text-center">Ujian Madrasah
                    <br/>MA NU TBS Kudus
                    <br/>Tahun Pelajaran 1440-1441 H / 2019-2020 M
                    </h4>
                    <p>Panduan pelaksanaan dan cara mengerjakan ujian Madrasah sistem Daring (online)
                        <ol>
                            <li>Klik download soal dan pilih soal sesuai dengan jurusan kalian</li>
                            <li>Download soal lalu kerjakan di kertas biasa, apabila telah selesai maka isikan secara online pada Link yang tersedia</li>
                            <li>Waktu mengerjakan sesuai pada jadwal, keterlambatan bisa mengakibatkan pengurangan nilai</li>
                            <li>Jika tidak bisa mengerjakan sesuai jadwal, harap menghubungi guru fan masing-masing dengan menyertakan alasan yang sebenar-benarnya</li>
                            <li>Jangan lupa mengisi mapel, nama lengkap, kelas dan nomor absen pada lembar jawab</li>
                            <li>Cara mengisi jawaban pilihan ganda:
                                <ul>
                                    <li>Klik A/B/C/D/E pada kolom sesuai dengan nomor soal</li>
                                    <li>Jika jumlah soal hanya 40, abaikan nomor 41-50. Jika terlanjur sudah diisi, tidak masalah</li>
                                </ul>
                            </li>
                            <li>Cara mengisi jawaban esai
                                <ul>
                                    <li>Tulis jawaban sesuai kolom nomor soal</li>
                                    <li><b>Untuk jawaban yang tidak bisa diketik (rumus/tulisan arab), silakan tulis tangan, lalu upload di google drive/blogger/wordpress/facebook/instagram/twitter/situs lainnya, kemudian copy linknya dan masukkan di lembar jawab.</b></li>
                                </ul>
                            </li>
                            <li>Sebelum mengirim jawaban, pastikan semua jawaban sudah diisi dengan benar. <b>Panitia tidak menyediakan fitur update jawaban</b></li>
                        </ol>
                    </p>
                    <table class="table table-bordered text-center">
                        <thead>
                            <tr>
                                <th rowspan=2>No.</th>
                                <th rowspan=2>Hari/Tanggal</th>
                                <th rowspan=2>Waktu</th>
                                <th colspan=4>Mapel</th>
                            </tr>
                            <tr>
                                <th>IPA</th>
                                <th>IPS</th>
                                <th>BHS</th>
                                <th>PK</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td rowspan=2>1</td>
                                <td rowspan=2>Senin<br/>30 Maret 2020</td>
                                <td rowspan=2>07.30-20.00</td>
                                <td>Fisika</td>
                                <td>Sejarah (Peminatan)</td>
                                <td>Sastra Inggris</td>
                                <td>Ilmu Tafsir</td>
                            </tr>
                            <tr>
                                <td>Bahasa Arab</td>
                                <td>Bahasa Arab</td>
                                <td>Bahasa Arab</td>
                                <td>Bahasa Arab</td>
                            </tr>
                            <tr>
                                <td rowspan=2>2</td>
                                <td rowspan=2>Selasa<br/>31 Maret 2020</td>
                                <td rowspan=2>07.30-20.00</td>
                                <td>Biologi</td>
                                <td>Sosiologi</td>
                                <td>B&S Indonesia</td>
                                <td>Ushul Fikih</td>
                            </tr>
                            <tr>
                                <td>Ke-NU-an</td>
                                <td>Ke-NU-an</td>
                                <td>Ke-NU-an</td>
                                <td>Ke-NU-an</td>
                            </tr>
                            <tr>
                                <td rowspan=2>3</td>
                                <td rowspan=2>Rabu<br/>1 April 2020</td>
                                <td rowspan=2>07.30-20.00</td>
                                <td>Bahasa Inggris</td>
                                <td>Bahasa Inggris</td>
                                <td>Bahasa Inggris</td>
                                <td>Bahasa Inggris</td>
                            </tr>
                            <tr>
                                <td>PPKn</td>
                                <td>PPKn</td>
                                <td>PPKn</td>
                                <td>PPKn</td>
                            </tr>
                            <tr>
                                <td>4</td>
                                <td>Kamis<br/>2 April 2020</td>
                                <td>07.30-20.00</td>
                                <td>Bahasa Jawa</td>
                                <td>Bahasa Jawa</td>
                                <td>Bahasa Jawa</td>
                                <td>Bahasa Jawa<br/>Ilmu Akhlak</td>
                            </tr>
                        </tbody>
                    </table>
                    <!--<a href="#" onClick="alert('Soal belum diupload, mohon tunggu...')"><buton class="btn btn-primary btn-large btn-block">Download Soal</buton></a><br/>-->
                    <!--<a href="https://drive.google.com/open?id=1XYG15N9Y3_7ThJQqY2NdVF-8btccG2HO"><buton class="btn btn-primary btn-large btn-block">Download Soal</buton></a><br/>-->
                    <!--<a href="https://drive.google.com/open?id=1kbdWE2rHN6gdQ6HUMck4wLaYYG4mcxWm"><buton class="btn btn-primary btn-large btn-block">Download Soal</buton></a><br/>-->
                    <!--<a href="https://drive.google.com/open?id=1XCnPRsCQ16nLHWZSJEtj9joQzrkLPQRj"><buton class="btn btn-primary btn-large btn-block">Download Soal</buton></a><br/>-->
                    <a href="https://drive.google.com/open?id=1-Vou7uapmWX7aSSh_HblpFq2LCgc3py5"><buton class="btn btn-primary btn-large btn-block">Download Soal</buton></a><br/>
                    <a href="https://masterdata.adminbaru.com/admin/jawab"><buton class="btn btn-success btn-large btn-block">Lembar jawab</buton></a><br/>
                    <a href="https://masterdata.adminbaru.com/admin/listterkirim"><buton class="btn btn-brown btn-large btn-block">List yang sudah mengumpulkan</buton></a>
                    
                </div>
                
            </div>
        </div>
    </body>
</html>

