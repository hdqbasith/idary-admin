<?php
defined('BASEPATH') OR exit('No direct script access allowed');
echo dvo('panel panel-color panel-teal','d1')
	.dvo('panel-heading')
		.heading('Under Development', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		    .'UPS, masih dalam pengembangan'
		    .dvc()
	    .dvc()
    .dvc()
.dvc();
?>