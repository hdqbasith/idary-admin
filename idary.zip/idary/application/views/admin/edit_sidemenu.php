<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs/dt-1.10.20/b-1.6.1/b-html5-1.6.1/datatables.min.css"/>
<div class="row" id="divlistmenu">
    <div class="col-md-12">
        <div class="card-box">
        	<div class="table-responsive">
<?php
echo '<table id="listmenu" class="table m-0 table-colored-bordered table-bordered-brown table-hover">'
    .'<thead>'
        .'<tr>';
            foreach($fieldmenu as $field){
                echo '<th>'.$field->type.'</th>';
            }
        echo '<th>aksi</th>';
        echo '</tr>'
    .'</thead>'
    .'<tbody>'
;
$n=1;
foreach($listmenu as $value){
    echo '<tr>';
    foreach($fieldmenu as $field){
        echo '<td>'.$value[$field->name].'</td>';
    };
    echo '<td><button onclick="edit()" class="btn  btn-primary waves-effect waves-light"><i class="mdi mdi-lead-pencil"></i></button><button onclick="del()" class="btn  btn-danger waves-effect waves-light"><i class="mdi mdi-close-circle"></i></button></td>';
    echo '</tr>';
}
echo '</tbody></table><button id="new" class="btn  btn-primary waves-effect waves-light">Tambahkan Menu Baru</button>';
?>

            </div>
        </div>
    </div>
</div>
<?php

$fl = array(
  'class'=> 'col-sm-4 control-label'
);
$pengumuman=array(
    'Klik link berikut untuk mengetahui daftar icon yang tersedia',
    '<a href="'.base_url('icons').'" target="_blank" class="btn btn-primary">Daftar Icon</a>'
    );


echo form_open(base_url('cekjs'),'name="formedit" id="formedit" class="form-horizontal" style="display:none;"')
	.dvo('panel panel-color panel-inverse')
		.dvo('panel-heading')
			.heading('Edit Menu', 4, 'class="panel-title"')
		.dvc()
							
		.dvo('panel-body')
			.dvo('row')
				.dvo('col-md-6','','border-right: 2px solid lightgrey');
				foreach($fieldmenu as $field){
				    echo dvo('form-group')
						.form_label($field->type, $field->name, $fl)
						.dvo('col-sm-8')
							.form_input($field->name, '', 'class="form-control"')
						.dvc()
					.dvc();
				};
				
	            echo form_button('simpan','Simpan','btn btn-rounded btn-success waves-effect waves-light btn-block')
	            .br(2).form_button('batal','Batal','btn btn-rounded btn-warning waves-effect waves-light btn-block')
				.dvc()
				.dvo('col-md-6','','')
				    .br(3)
				    .ul($pengumuman,'')
				.dvc()
			.dvc()
		.dvc()
	.dvc()
.form_close();



?>

<link href="<?php echo base_url()?>assets/plugins/bootstrap-sweetalert/sweet-alert.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="https://cdn.datatables.net/v/bs/dt-1.10.20/b-1.6.1/b-html5-1.6.1/datatables.min.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>assets/plugins/bootstrap-sweetalert/sweet-alert.min.js"></script>
<script>
	function edit(){
	    $('#divlistmenu').toggle('explode');
	    $('#formedit').toggle('explode');
	}
	function del(){
	    swal({
        	title:"Anda Yakin?", 
        	text:"Tidak ada fungsi undo lho ya...",
        	type:"warning",
        	showCancelButton: true,
    	},function(){
            values = jQuery("#menu_id").serialize();
    	    $.post("<?php  echo base_url('admin/del_sidemenu'); ?>",values,function(){
                location.reload();
            });
    	});
	}
	//mencegah kesalahan pencet tombol backspace
	$(document).on("keydown", function (e) {
        if (e.which === 8 && !$(e.target).is("input, textarea")) {
            e.preventDefault();
        }
    });
$(document).ready(function() {
    $('#menu_id').prop("readonly",true).prop('style','background:lightgrey');
    var table = $('#listmenu').DataTable({
        rowId: 'id',
        order: []
    });
    $('#listmenu').on( 'click', 'tr', function () {
        var id = table.row( this ).id();
        $('#menu_id').val($(this).find('td:eq(0)').text());
        $('#menu_parent').val($(this).find('td:eq(1)').text());
        $('#menu_order').val($(this).find('td:eq(2)').text());
        $('#menu_name').val($(this).find('td:eq(3)').text());
        $('#menu_link').val($(this).find('td:eq(4)').text());
        $('#user_level').val($(this).find('td:eq(5)').text());
        $('#menu_active').val($(this).find('td:eq(6)').text());
        $('#menu_icon').val($(this).find('td:eq(7)').text());
    } );
	$('#simpan').click(function(e) {
        e.preventDefault();
        swal({
            title: "Tunggu sebentar",
            text: "Sedang menyimpan data",
            timer: 10000,
            showConfirmButton: false
        });
        values = jQuery("#formedit").serialize();
        $.post("<?php  echo base_url('admin/simpan_sidemenu'); ?>",values,function(){
            location.reload();
        })
	});
	$('#batal').click(function(e) {
        e.preventDefault();
	    $('#formedit').toggle('explode');
	    $('#divlistmenu').toggle('explode');
	});
	$('#new').click(function() {
        $('#menu_id').val('');
        $('#menu_parent').val('');
        $('#menu_order').val('');
        $('#menu_name').val('');
        $('#menu_link').val('');
        $('#user_level').val('');
        $('#menu_active').val('');
        $('#menu_icon').val('');
	    $('#divlistmenu').toggle('explode');
	    $('#formedit').toggle('explode');
	});
})

</script>