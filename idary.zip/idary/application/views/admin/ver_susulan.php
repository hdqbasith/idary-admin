<?php
defined('BASEPATH') OR exit('No direct script access allowed');
echo dvo('panel panel-color panel-teal','d1')
	.dvo('panel-heading')
		.heading('Daftar Pengajuan Susulan PAS', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
                .tableo('list','','width=100%')
                    .theado()
                        .tro()
                            .th('Kelas')
                            .th('NISN')
                            .th('Nama')
                            .th('Mapel')
                            .th('Approve')
                        .trc()
                    .theadc()
                    .tbodyo()
                    .tbodyc()
                .tablec()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();
echo JS_SWAL;
?>

<link href="<?php echo base_url()?>assets/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url()?>assets/plugins/datatables/datatables.min.js"></script>
<script>
    $(document).ready(function(){
        $("table").DataTable({
            scrollX:true,
            order: [[ 0, 'asc' ]]
        });
    });
    var siswa=<?php echo json_encode($siswa);?>;
    var table='';
    $.each(siswa,function(i,v){
        if(v.approve=="9") table+="<tr><td>"+v.kelas+"</td><td>"+v.nisn+"</td><td>"+v.nama_lengkap+"</td><td>"+v.pelajaran+"</td><td><a class=\"btn btn-teal\" onclick=approve(this,\"nisn="+v.nisn+"&mapel="+v.mapel+"&approve=\")>Approve</a></td></tr>";
        else table+="<tr><td>"+v.kelas+"</td><td>"+v.nisn+"</td><td>"+v.nama_lengkap+"</td><td>"+v.pelajaran+"</td><td><a class=\"btn btn-orange\" onclick=approve(this,\"nisn="+v.nisn+"&mapel="+v.mapel+"&approve=\")>Batalkan</a></td></tr>";
    })
    $("#list tbody").html(table);
    function approve(elem,mapel){
        perhatian();
        var appr=1;
        if($(elem).html()=="Batalkan") appr=9;
        $.get("<?php echo base_url('admin/ver_susulan?'); ?>"+mapel+appr,function(data){
            swal.close();
            if(appr==1) $(elem).removeClass("btn-teal").addClass("btn-orange").html("Batalkan");
            else $(elem).removeClass("btn-orange").addClass("btn-teal").html("Approve");
        });
    }
    function perhatian(){
        swal({
            title:"Memproses...", 
            text:"Mohon tunggu sebentar. Jika halaman tidak dialihkan, silakan coba lagi",
            type:"info",
            timer: 1000,
            showConfirmButton:false,
            closeOnCancel: false,
        });
    }
</script>