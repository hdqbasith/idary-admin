<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$a['namasiswa']='Nama Lengkap'; $a['nama_arab']='Nama (arab)'; $a['nisn']='NISN'; $a['nik']='NIK'; $a['ttlsiswa']='Tempat Lahir'; $a['tglsiswa']='Tanggal Lahir'; $a['almlengkap']='Alamat Rumah'; $a['hpsiswa']='No. HP'; $a['emailsiswa']='Email'; $a['m_citacita_id']='Cita-Cita'; $a['m_hobi_id']='Hobi'; $a['jrssiswa']='Pilihan Jurusan 1'; $a['jrssiswa2']='Pilihan Jurusan 2'; $a['jrssiswa3']='Pilihan Jurusan 3'; $a['jrssiswa4']='Pilihan Jurusan 4'; 
$op['jurusan']=array(
    ''=>'','1'=>'IPA', '2'=>'IPS', '3'=>'Bahasa', '4'=>'Keagamaan'
);
$op['daritbs']=array('1'=>'Ya','0'=>'Tidak');
$fl = array(
    'class'=> 'col-sm-4 control-label'
);
$fc =array(
    'class'=> 'form-control',
    'required'=>'',
    'type'=>'text',
    'autocomplete'=>'off'
);
$fd = array(
    'class'=> 'datepicker form-control',
    'placeholder' => 'dd-mm-yyyy',
    'autocomplete' => 'off',
    'required' => ''
);
$fv=array(
    'class'=> 'form-control',
    'readonly'=>1,
    'style'=>'background-color:white'
);
$op['kelasmts']=array(
    ''=>'','MPA'=>'MPA','IX A'=>'IX A', 'IX B'=>'IX B', 'IX C'=>'IX C', 'IX D'=>'IX D', 'IX E'=>'IX E', 'IX F'=>'IX F', 'IX G'=>'IX G', 'IX H'=>'IX H', 'IX I'=>'IX I', 'IX J'=>'IX J', 'IX K'=>'IX K', 'IX L'=>'IX L', 'IX M'=>'IX M', 'IX N'=>'IX N', 'IX O'=>'IX O', 'LAMA'=>'Kelas X (Tidak Naik)'
);
echo dvo('panel panel-color panel-teal','d1')
	.dvo('panel-heading')
		.heading('List Pengisi Formulir Pendaftaran', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		        .tableo('list','','width="100%"')
    		        .theado()
    		            .tro()
    		                .th('NISN')
    		                .th('Nama')
    		                .th('Kelas')
    		                .th('Edit')
    		            .trc()
                    .theadc()
                    .tbodyo();
    		            foreach($listsiswa as $l){
    		                echo tro().td($l['nisn']).td($l['nama_lengkap']).td($l['kelas'].' / '.$l['jurusan'].' / '.sprintf("%02d", $l['absen']).' <a class="btn btn-primary" target="_blank" href="'.base_url('admin/edit_kelas?nisn=').$l['nisn'].'"><i class="mdi mdi-lead-pencil"/></a>').td('<a class="btn btn-teal" target="_blank" href="'.base_url('student/formulir_full?nisn=').$l['nisn'].'">Edit</a>').trc();
    		            }
		        echo tbodyc()
		        .tablec()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();

?>
<link href="<?php echo base_url()?>assets/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url()?>assets/plugins/datatables/datatables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.colVis.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.html5.min.js"></script>

<link href="<?php echo base_url()?>assets/plugins/bootstrap-sweetalert/sweet-alert.css" rel="stylesheet" type="text/css">

<script src="<?php echo base_url()?>assets/plugins/bootstrap-sweetalert/sweet-alert.min.js"></script>
<script>
    $(document).ready(function(){
        $('#list').DataTable({
            // responsive:true,
            scrollX:true,
            "dom": 'Blfrtip',
            "buttons": [
                'copy', 'excel', 'pdf','colvis'
            ],
        });
        window.addEventListener("keydown",function (e) {
            if (e.keyCode === 114 || (e.ctrlKey && e.keyCode === 70)){
                e.preventDefault();
                $('input[type=\"search\"]').select();
                if($('input[type=\"search\"]').is(":focus")) {
                    return true;
                } else {
                    $('input[type=\"search\"]').focus();
                }
            }
        })
    });
</script>

