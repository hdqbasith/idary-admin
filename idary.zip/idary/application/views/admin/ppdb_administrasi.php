<?php
defined('BASEPATH') OR exit('No direct script access allowed');
echo dvo('panel panel-color panel-teal','d1')
	.dvo('panel-heading')
		.heading('List Pengisi Formulir Pendaftaran', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		        .tableo('list','','width="100%"')
    		        .theado()
    		            .tro()
    		                .th('Bayar')
    		                .th('ID')
    		                .th('Nama')
    		                .th('Asal Sekolah')
    		                .th('Kelas')
    		                .th('Alamat')
    		            .trc()
                    .theadc()
                    .tbodyo();
                        $sudah_bayar=0;
    		            foreach($listpendaftar as $l){
    		                echo tro().td($l['bayar']).td($l['nisn']).td($l['namasiswa']).td($l['aslsb']).td($l['kelasmts']).td($l['almlengkap']).trc();
                            if($l['bayar']==1) $sudah_bayar++;
    		            }
		        echo tbodyc()
		        .tablec()
                .heading('Jumlah yang sudah membayar: '.'<span id="sudah_bayar">'.$sudah_bayar.'</span>', 4)
		    .dvc()
	    .dvc()
    .dvc()
.dvc();
?>
<link href="<?php echo base_url()?>assets/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url()?>assets/plugins/datatables/datatables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.colVis.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.html5.min.js"></script>

<link href="<?php echo base_url()?>assets/plugins/bootstrap-sweetalert/sweet-alert.css" rel="stylesheet" type="text/css">

<script src="<?php echo base_url()?>assets/plugins/bootstrap-sweetalert/sweet-alert.min.js"></script>
<script>
    $(document).ready(function(){
        $('#list').DataTable({
            // responsive:true,
            scrollX:true,
            pageLength: 10,
            dom: 'Bfrtip',
            buttons: [
            'copy', 'excel'],
    		columnDefs: [
    		    {
    		        "render": function ( data, type, row ) {
    		            var bayar=0;
    		            var button4='<button data-bayar="0" data-nisn="'+row[1]+'" onclick="bayar($(this).data(\'nisn\'),this)" class="btn btn-orange">'+row[0]+'<i class="mdi mdi-close"></i>Rp</button>';
    		            if (row[0]==1) button4='<button data-bayar="1" data-nisn="'+row[1]+'" onclick="bayar($(this).data(\'nisn\'),this)" class="btn btn-teal">'+row[0]+'<i class="mdi mdi-check"></i>Rp</button>';
                        return button4;
                    },
                    "targets": 0
    		    }]
        });
    });
    var sudah_bayar=parseInt($("#sudah_bayar").text());
    function bayar(nisn,btn){
        swal({
        	title:"Pembayaran", 
        	text:"Apakah calon siswa ini sudah membayar biaya administrasi?",
        	type:"warning",
        	showCancelButton:true,
            confirmButtonText: "Sudah",
            cancelButtonText: "Belum!",
            closeOnConfirm: false,
    	}, function(a){
    	    swal({
            	title:"Tunggu sebentar", 
            	text:"Sedang menyimpan data. Jika terlalu lama refresh browser...",
            	type:"info",
            	showOkButton:false
        	});
        	var bayar;
        	if($(btn).data("bayar")=='0') bayar=1;
        	else bayar=0;
    		$.get("<?php echo base_url('admin/ppdb_bayar_reg?nisn=');?>"+nisn+"&bayar="+bayar,function(data){
        	    if(a){
                    $(btn).html('1<i class="mdi mdi-check"></i>Rp').removeClass('btn-orange').addClass('btn-teal');
                    $(btn).data("bayar")=="1";
                } else if(a==false){
                    $(btn).html('0<i class="mdi mdi-close"></i>Rp').removeClass('btn-teal').addClass('btn-orange');
                    $(btn).data("bayar")=="0";
                }
        	    swal.close();
                $("#sudah_bayar").html('<button onClick="window.location.reload();" class="btn btn-teal">Refresh</button>');
    		});
    	});
    };
</script>