<?php
defined('BASEPATH') OR exit('No direct script access allowed');
echo dvo('panel panel-color panel-teal','d1')
	.dvo('panel-heading')
		.heading('Klik Tombol Approve jika siswa diterima. Menu siswa akan berubah jika login kembali', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
                .tableo('list','','width=100%')
                    .theado()
                        .tro()
                            .th('NISN')
                            .th('Nama')
                            .th('Nama Ayah')
                            .th('Alamat')
                            .th('Sekolah Asal')
                            .th('Approve')
                        .trc()
                    .theadc()
                    .tbodyo()
                    .tbodyc()
                .tablec()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();
echo JS_SWAL;
?>

<link href="<?php echo base_url()?>assets/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url()?>assets/plugins/datatables/datatables.min.js"></script>
<script>
    $(document).ready(function(){
        $("table").DataTable({
            scrollX:true,
            order: [[ 0, 'asc' ]]
        });
    });
    var siswa=<?php echo json_encode($siswa);?>;
    var table='';
    $.each(siswa,function(i,v){
        if(v.level=="9") table+="<tr><td>"+v.nisn+"</td><td>"+v.nama_lengkap+"</td><td>"+v.nama_ayah_kandung+"</td><td>"+v.alamat_siswa+"</td><td>"+v.nama_sekolah_asal+"</td><td><a class=\"btn btn-teal\" onclick=approve(this,\"nisn="+v.nisn+"&level=\")>Approve</a></td></tr>";
        else table+="<tr><td>"+v.nisn+"</td><td>"+v.nama_lengkap+"</td><td>"+v.nama_ayah_kandung+"</td><td>"+v.alamat_siswa+"</td><td>"+v.nama_sekolah_asal+"</td><td><a class=\"btn btn-orange\" onclick=approve(this,\"nisn="+v.nisn+"&level=\")>Batalkan</a></td></tr>";
    })
    $("#list tbody").html(table);
    function approve(elem,level){
        perhatian();
        var appr=8;
        if($(elem).html()=="Batalkan") appr=9;
        $.get("<?php echo base_url('admin/hasilppdb?'); ?>"+level+appr,function(data){
            swal.close();
            if(appr==8) $(elem).removeClass("btn-teal").addClass("btn-orange").html("Batalkan");
            else $(elem).removeClass("btn-orange").addClass("btn-teal").html("Approve");
        });
    }
    function perhatian(){
        swal({
            title:"Memproses...", 
            text:"Mohon tunggu sebentar. Jika halaman tidak dialihkan, silakan coba lagi",
            type:"info",
            timer: 1000,
            showConfirmButton:false,
            closeOnCancel: false,
        });
    }
</script>