<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$a['namasiswa']='Nama Lengkap'; $a['nama_arab']='Nama (arab)'; $a['nisn']='NISN'; $a['nik']='NIK'; $a['ttlsiswa']='Tempat Lahir'; $a['tglsiswa']='Tanggal Lahir'; $a['almlengkap']='Alamat Rumah'; $a['hpsiswa']='No. HP'; $a['emailsiswa']='Email'; $a['m_citacita_id']='Cita-Cita'; $a['m_hobi_id']='Hobi'; $a['jrssiswa']='Pilihan Jurusan 1'; $a['jrssiswa2']='Pilihan Jurusan 2'; $a['jrssiswa3']='Pilihan Jurusan 3'; $a['jrssiswa4']='Pilihan Jurusan 4'; 
$op['jurusan']=array(
    ''=>'','1'=>'IPA', '2'=>'IPS', '3'=>'Bahasa', '4'=>'Keagamaan'
);
$op['daritbs']=array('1'=>'Ya','0'=>'Tidak');
$fl = array(
    'class'=> 'col-sm-4 control-label'
);
$fc =array(
    'class'=> 'form-control',
    'required'=>'',
    'type'=>'text',
    'autocomplete'=>'off'
);
$fd = array(
    'class'=> 'datepicker form-control',
    'placeholder' => 'dd-mm-yyyy',
    'autocomplete' => 'off',
    'required' => ''
);
$fv=array(
    'class'=> 'form-control',
    'readonly'=>1,
    'style'=>'background-color:white'
);
$op['kelasmts']=array(
    ''=>'','MPA'=>'MPA','IX A'=>'IX A', 'IX B'=>'IX B', 'IX C'=>'IX C', 'IX D'=>'IX D', 'IX E'=>'IX E', 'IX F'=>'IX F', 'IX G'=>'IX G', 'IX H'=>'IX H', 'IX I'=>'IX I', 'IX J'=>'IX J', 'IX K'=>'IX K', 'IX L'=>'IX L', 'IX M'=>'IX M', 'IX N'=>'IX N', 'IX O'=>'IX O', 'LAMA'=>'Kelas X (Tidak Naik)'
);

echo dvo('panel panel-color panel-teal','d1')
	.dvo('panel-heading')
		.heading('List Pengisi Formulir Pendaftaran', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		        .tableo('list')
    		        .theado()
    		            .tro();
    		            foreach($fullfield as $f){
    		                echo th($f->type);
    		            }
    		            echo trc()
                    .theadc()
                    .tbodyo();
    		            foreach($fullsiswa as $k=>$l){
    		                echo tro();
    		                foreach($fullfield as $f){
        		                echo td($l[$f->name]);
    		                }
    		                echo trc();
    		            }
		        echo tbodyc()
		        .tablec()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();
echo dvo('panel panel-color panel-teal d-none','d2')
	.form_button('','Kembali','btn btn-rounded btn-danger waves-effect waves-light btn-lg btn-block btn-back')
	.dvo('panel-heading')
		.heading('Detail Pendaftar', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
                .dvo('panel panel-color panel-teal')
            		.dvo('panel-heading')
            			.heading('Biodata Calon Siswa Baru', 4, 'class="panel-title"')
            		.dvc()
            
            		.dvo('panel-body')
            			.dvo('row')
        		        .form_open('','class="form-horizontal"')
                			.dvo('col-md-6','','border-right: 2px solid lightgrey')
                				.dvo('form-group')
                					.form_label('NISN', 'nisn', $fl)
                					.dvo('col-sm-8')
                						.form_input('vnisn', '', $fv)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label('Nama Lengkap', 'namasiswa', $fl)
                					.dvo('col-sm-8')
                						.form_input('vnamasiswa', '', $fv)
                					.dvc()
                				.dvc() 
                				.dvo('form-group')
                					.form_label('NIK', 'nik', $fl)
                					.dvo('col-sm-8')
                						.form_input('vnik', '', $fv)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label('Tempat Lahir', 'ttlsiswa', $fl)
                					.dvo('col-sm-8')
                						.form_input('vttlsiswa', '', $fv)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label('Tanggal Lahir', 'tglsiswa', $fl)
                					.dvo('col-sm-8')
                						.form_input('vtglsiswa', '', $fv)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label('Alamat Rumah', 'almlengkap', $fl)
                					.dvo('col-sm-8')
                						.form_input('valmlengkap', '', $fv)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label('No. HP', 'hpsiswa', $fl)
                					.dvo('col-sm-8')
                						.form_input('vhpsiswa', '', $fv)
                					.dvc()
                				.dvc()
                			.dvc()
                			.dvo('col-md-6','','border-right: 2px solid lightgrey')
                				.dvo('form-group')
                					.form_label('Email', 'emailsiswa', $fl)
                					.dvo('col-sm-8')
                						.form_input('vemailsiswa', '', $fv)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label('Pilihan Jurusan 1', 'jrssiswa', $fl)
                					.dvo('col-sm-8')
                    					.form_input('vjrssiswa', '',$fv)
                					.dvc()
                				.dvc() 
                				.dvo('form-group')
                					.form_label('Pilihan Jurusan 2', 'jrssiswa2', $fl)
                					.dvo('col-sm-8')
                    					.form_input('vjrssiswa2', '',$fv)
                					.dvc()
                				.dvc() 
                				.dvo('form-group')
                					.form_label('Pilihan Jurusan 3', 'jrssiswa3', $fl)
                					.dvo('col-sm-8')
                    					.form_input('vjrssiswa3', '',$fv)
                					.dvc()
                				.dvc() 
                				.dvo('form-group')
                					.form_label('Pilihan Jurusan 4', 'jrssiswa4', $fl)
                					.dvo('col-sm-8')
                    					.form_input('vjrssiswa4', '',$fv)
                					.dvc()
                				.dvc()
                				.dvo('form-group')
                					.form_label('Dari MTs TBS?', 'daritbs', $fl)
                					.dvo('col-sm-8')
                    					.form_input('vdaritbs', '',$fv)
                					.dvc()
                				.dvc()
                				.dvo('form-group d-block')
                					.form_label('Kelas Asal di MTs', 'kelasmts', $fl)
                					.dvo('col-sm-8')
                    					.form_input('vkelasmts','',$fv)
                					.dvc()
                				.dvc()
                				.dvo('form-group d-none')
                					.form_label('Asal Sekolah', 'aslsb', $fl)
                					.dvo('col-sm-8')
                						.form_input('vaslsb', '', $fv)
                					.dvc()
                				.dvc()
                			.dvc()
                			.form_close()
            			.dvc()
            		.dvc()
            	.dvc()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();
echo dvo('panel panel-color panel-teal d-none','d3')
	.form_button('','Kembali','btn btn-rounded btn-danger waves-effect waves-light btn-lg btn-block btn-back')
	.dvo('panel-heading')
		.heading('Edit Pendaftar', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		        .form_open('','name="formedit" id="formedit" class="form-horizontal" style="background:white"')
                	.dvo('panel panel-color panel-teal')
                		.dvo('panel-heading')
                			.heading('Biodata Calon Siswa Baru', 4, 'class="panel-title"')
                		.dvc()
                
                		.dvo('panel-body')
                			.dvo('row')
                    			.dvo('col-md-6','','border-right: 2px solid lightgrey')
                    				.dvo('form-group')
                    					.form_label('NISN', 'nisn', $fl)
                    					.dvo('col-sm-8')
                    						.form_input('nisn', '', $fc)
                    					.dvc()
                    				.dvc()
                    				.dvo('form-group')
                    					.form_label('Nama Lengkap', 'namasiswa', $fl)
                    					.dvo('col-sm-8')
                    						.form_input('namasiswa', '', $fc)
                    					.dvc()
                    				.dvc() 
                    				.dvo('form-group')
                    					.form_label('NIK', 'nik', $fl)
                    					.dvo('col-sm-8')
                    						.form_input('nik', '', $fc)
                    					.dvc()
                    				.dvc()
                    				.dvo('form-group')
                    					.form_label('Tempat Lahir', 'ttlsiswa', $fl)
                    					.dvo('col-sm-8')
                    						.form_input('ttlsiswa', '', $fc)
                    					.dvc()
                    				.dvc()
                    				.dvo('form-group')
                    					.form_label('Tanggal Lahir', 'tglsiswa', $fl)
                    					.dvo('col-sm-8')
                    						.form_input('tglsiswa', '', $fd)
                    					.dvc()
                    				.dvc()
                    				.dvo('form-group')
                    					.form_label('Alamat Rumah', 'almlengkap', $fl)
                    					.dvo('col-sm-8')
                    						.form_input('almlengkap', '', $fc)
                    					.dvc()
                    				.dvc()
                    				.dvo('form-group')
                    					.form_label('No. HP', 'hpsiswa', $fl)
                    					.dvo('col-sm-8')
                    						.form_input('hpsiswa', '', $fc)
                    					.dvc()
                    				.dvc()
                    			.dvc()
                    			.dvo('col-md-6','','border-right: 2px solid lightgrey')
                    				.dvo('form-group')
                    					.form_label('Email', 'emailsiswa', $fl)
                    					.dvo('col-sm-8')
                    						.form_input('emailsiswa', '', $fc)
                    					.dvc()
                    				.dvc()
                    				.dvo('form-group')
                    					.form_label('Pilihan Jurusan 1', 'jrssiswa', $fl)
                    					.dvo('col-sm-8')
                        					.form_dropdown('jrssiswa', $op['jurusan'])
                    					.dvc()
                    				.dvc() 
                    				.dvo('form-group')
                    					.form_label('Pilihan Jurusan 2', 'jrssiswa2', $fl)
                    					.dvo('col-sm-8')
                        					.form_dropdown('jrssiswa2', $op['jurusan'])
                    					.dvc()
                    				.dvc() 
                    				.dvo('form-group')
                    					.form_label('Pilihan Jurusan 3', 'jrssiswa3', $fl)
                    					.dvo('col-sm-8')
                        					.form_dropdown('jrssiswa3', $op['jurusan'])
                    					.dvc()
                    				.dvc() 
                    				.dvo('form-group')
                    					.form_label('Pilihan Jurusan 4', 'jrssiswa4', $fl)
                    					.dvo('col-sm-8')
                        					.form_dropdown('jrssiswa4', $op['jurusan'])
                    					.dvc()
                    				.dvc()
                    				.dvo('form-group')
                    					.form_label('Dari MTs TBS?', 'daritbs', $fl)
                    					.dvo('col-sm-8')
                        					.form_dropdown('daritbs', $op['daritbs'])
                    					.dvc()
                    				.dvc()
                    				.dvo('form-group d-block')
                    					.form_label('Kelas Asal di MTs', 'kelasmts', $fl)
                    					.dvo('col-sm-8')
                        					.form_dropdown('kelasmts', $op['kelasmts'])
                    					.dvc()
                    				.dvc()
                    				.dvo('form-group d-none')
                    					.form_label('Asal Sekolah', 'aslsb', $fl)
                    					.dvo('col-sm-8')
                    						.form_input('aslsb', '', $fc)
                    					.dvc()
                    				.dvc()
                    			.dvc()
                			.dvc()
                		.dvc()
                	.dvc()
                	.po('Pastikan Anda sudah yakin dengan pilihan prioritas jurusan Anda. Anda tidak bisa mengubah pilihan prioritas jurusan Anda.')
                	.pc()
                	.form_button('simpan','Simpan','btn btn-rounded btn-teal waves-effect waves-light btn-lg btn-block')
                .form_close()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();


?>











<link href="<?php echo base_url()?>assets/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url()?>assets/plugins/datatables/datatables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.colVis.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/fixedcolumns/3.3.1/js/dataTables.fixedColumns.min.js"></script>

<link href="<?php echo base_url()?>assets/plugins/bootstrap-sweetalert/sweet-alert.css" rel="stylesheet" type="text/css">

<script src="<?php echo base_url()?>assets/plugins/bootstrap-sweetalert/sweet-alert.min.js"></script>
<script>
    $(document).ready(function(){
        $('#list').DataTable({
            // responsive:true,
            scrollX:true,
            pageLength: 50,
            dom: 'Bfrtip',
            buttons: [
            'copy', 'excel', 'pdf','colvis'],
        });
        $('#d2,#d3').hide();
    });
    function lihat(id){
        $('#d2').show();
        $('#d1').hide();
        $.post("<?php echo base_url('admin/detailpendaftar?id=');?>"+id,function(data){
		    $('#vnisn').val(data.nisn);
		    $('#vnamasiswa').val(data.namasiswa);
		    $('#vnik').val(data.nik);
		    $('#vttlsiswa').val(data.ttlsiswa);
		    $('#vtglsiswa').val(data.tglsiswa);
		    $('#valmlengkap').val(data.almlengkap);
		    $('#vhpsiswa').val(data.hpsiswa);
		    $('#vemailsiswa').val(data.emailsiswa);
		    $('#vjrssiswa').val(jurusan[data.jrssiswa.substr(0,1)]);
		    $('#vjrssiswa2').val(jurusan[data.jrssiswa.substr(1,1)]);
		    $('#vjrssiswa3').val(jurusan[data.jrssiswa.substr(2,1)]);
		    $('#vjrssiswa4').val(jurusan[data.jrssiswa.substr(3,1)]);
		    if(data.kelasmts==null) $('#vdaritbs').val("Ya"); else $('#vdaritbs').val("Ya");
		    if(data.kelasmts!=null) $('#vkelasmts').val("IX "+data.kelasmts);
		    $('#vaslsb').val(data.aslsb);
		},'json');
    };
    function edit(id){
        $('#d3').show();
        $('#d1').hide();
		$.get("<?php echo base_url('admin/detailpendaftar?id=');?>"+id,function(data){
		    $('#nisn').val(data.nisn);
		    $('#namasiswa').val(data.namasiswa);
		    $('#nik').val(data.nik);
		    $('#ttlsiswa').val(data.ttlsiswa);
		    $('#tglsiswa').val(data.tglsiswa);
		    $('#almlengkap').val(data.almlengkap);
		    $('#hpsiswa').val(data.hpsiswa);
		    $('#emailsiswa').val(data.emailsiswa);
		    $('#jrssiswa').val(data.jrssiswa.substr(0,1)).change();
		    $('#jrssiswa2').val(data.jrssiswa.substr(1,1)).change();
		    $('#jrssiswa3').val(data.jrssiswa.substr(2,1)).change();
		    $('#jrssiswa4').val(data.jrssiswa.substr(3,1)).change();
		    if(data.kelasmts!=null) $('#daritbs').val("1").change(); else $('#daritbs').val("0").change();
		    if(data.kelasmts!=null) $('#kelasmts').val(data.kelasmts).change();
		    $('#aslsb').val(data.aslsb);
		},'json');
    };
    function hapus(id,btn){
        swal({
        	title:"Hapus Data", 
        	text:"Anda yakin ingin menghapus data ini? Data yang sudah dihapus tidak dapat dikembalikan!",
        	type:"warning",
        	showCancelButton:true
    	}, function(){
    		$.get("<?php echo base_url('admin/aksipendaftar?id=');?>"+id+"&aksi=hapus",function(data){
        	    $('#list').DataTable().row($(btn).parents('tr')).remove().draw();
    		});
    	});
    }
    function bayar(id,btn){
        swal({
        	title:"Pembayaran", 
        	text:"Apakah calon siswa ini sudah membayar biaya administrasi?",
        	type:"warning",
        	showCancelButton:true,
            confirmButtonText: "Sudah",
            cancelButtonText: "Belum!",
            closeOnConfirm: false,
    	}, function(a){
    	    swal({
            	title:"Tunggu sebentar", 
            	text:"Sedang menyimpan data. Jika terlalu lama refresh browser...",
            	type:"info",
            	showOkButton:false
        	});
        	var nilai;
        	if($(btn).html()=='<i class="mdi mdi-check"></i>Rp') nilai=0;
        	else nilai=1;
    		$.get("<?php echo base_url('admin/aksipendaftar?id=');?>"+id+"&aksi=bayar&nilai="+nilai,function(data){
        	    if(a) $(btn).html('<i class="mdi mdi-check"></i>Rp').removeClass('btn-orange').addClass('btn-teal');
        	    else $(btn).html('<i class="mdi mdi-close"></i>Rp').removeClass('btn-teal').addClass('btn-orange');
        	    swal.close();
    		});
    	});
    };
    // function mpa(id,btn){
    //     swal({
    //     	title:"MPA", 
    //     	text:"Apakah calon siswa ini masuk MPA?",
    //     	type:"warning",
    //     	showCancelButton:true,
    //         confirmButtonText: "Ya",
    //         cancelButtonText: "Tidak",
    //         closeOnConfirm: false,
    // 	}, function(a){
    // 	    swal({
    //         	title:"Tunggu sebentar", 
    //         	text:"Sedang menyimpan data. Jika terlalu lama refresh browser...",
    //         	type:"info",
    //         	showOkButton:false
    //     	});
    //     	var nilai;
    //     	if($(btn).text=="MPA") nilai=0;
    //     	else nilai=1;
    // 		$.get("<?php echo base_url('admin/aksipendaftar?id=');?>"+id+"&aksi=mpa&nilai="+nilai,function(data){
    //     	    if(a) $(btn).text('MPA').removeClass('btn-teal').addClass('btn-danger');
    //     	    else $(btn).text('MA').removeClass('btn-danger').addClass('btn-teal');
    //     	    swal.close();
    // 		});
    // 	});
    // };
    $('.btn-back').click(function(){
        $('#d2,#d3').hide();
        $('#d1').show();
    });
    var jurusan=[];
    jurusan[1]='IPA';
    jurusan[2]='Bahasa';
    jurusan[3]='IPS';
    jurusan[4]='PK';
</script>












