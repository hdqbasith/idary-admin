<?php
defined('BASEPATH') OR exit('No direct script access allowed');
echo '<table class="table table-bordered"><thead><tr>';
foreach($fullfield as $f){
    echo '<th>'.$f->type.'</th>';
}
echo heading('Masih Pengembangan. Agar loading tidak terlalu lambat, kode wilayah (Desa, kecamatan, dst) tidak diterjemahkan',4);
echo '</tr></thead></thead><tbody></tbody></table>';

?>
<link href="<?php echo base_url()?>assets/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url()?>assets/plugins/datatables/datatables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.colVis.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/fixedcolumns/3.3.1/js/dataTables.fixedColumns.min.js"></script>

<script>
    var agama=["","Islam","Kristen Protestan","Katolik","Hindu","Buddha","Kong Hu Cu"];
    var cita=["-","PNS","TNI/Polri","Guru/Dosen","Dokter","Politikus","Wiraswasta","Seniman/Artis","Ilmuwan","Agamawan"];
    var hobi=["-","Olahraga","Kesenian","Membaca","Menulis","Jalan-Jalan","-"];
    var jarak=["-","Kurang dari 5 Km","Antara 5 - 10 Km","Antara 11 - 20 Km","Antara 21 - 30 Km","Lebih dari 30 Km",];
    var stt=["-","Tinggal dengan Orangtua/Wali","Ikut Saudara/Kerabat","Asrama Madrasah","Kontrak/Kost","Asrama Pesantren","Panti Asuhan","Rumah Singgah","Lainnya"];
    var kerja=["-","Tidak Bekerja","Pensiunan","PNS (Selain poin 05 dan 10)","TNI/Polisi","Guru/Dosen","Pegawai Swasta","Wiraswasta/Wirausaha","Pengacara/Hakim/Jaksa/Notaris","Seniman/Pelukis/Artis/Sejenis","Dokter/Bidan/Perawat","Pilot/Pramugara","Pedagang","Petani/Peternak","Nelayan","Buruh (Tani/Pabrik/Bangunan)","Sopir/Masinis/Kondektur","Politikus","Tidak Tentu"];
    var pdd=["Tidak sekolah formal","SD/Sederajat","SMP/Sederajat","SMA/Sederajat","D1","D2","D3","D4/S1","S2","S3"];
    var gaji=["-","Kurang dari Rp 500.000","Rp 500.000 - 1.000.000","Rp 1.000.001 - 2.000.000","Rp 2.000.001 - 3.000.000","Rp 3.000.001 - 5.000.000","Lebih dari Rp 5.000.000"];
    var statrumah=["-","Milik Sendiri","Rumah Orang Tua","Rumah Saudara/Kerabat","Rumah Dinas","Sewa/Kontrak","Lainnya"];
    var statortu=["-","Masih Hidup","Sudah Meninggal","Tidak Diketahui"];
    var transport=["-","Jalan Kaki","Sepeda","Sepeda Motor","Mobil Pribadi","Antar Jemput Sekolah","Angkutan Umum","Perahu/Sampan","Lainnya"];
    var jurusan=["MPA","IPA","IPS","BHS","PK"];
    var jenskl=["-","SMP","MTs","SMP Terbuka","SLB","Paket B","Pesantren Salafiyah Wustha","SMP di Luar Negeri"];
    var jenasl=["","Negeri","Swasta"];
    
    
    
    var data=<?php echo json_encode($fullsiswa);?>;
    var table='';
    var field=<?php echo json_encode($fullfield);?>;
    
$(document).ready(function() {
    $.each(data,function(i,v){
        table+="<tr>";
        $.each(field,function(i2,v2){
            var vv=v[v2.name];
            if(v2.name=="m_agama_id") vv=agama[v[v2.name]];
            if(v2.name=="m_citacita_id") vv=cita[v[v2.name]];
            if(v2.name=="m_hobi_id") vv=hobi[v[v2.name]];
            if(v2.name=="m_jarak_id") vv=jarak[v[v2.name]];
            if(v2.name=="m_jenis_rumah_id") vv=stt[v[v2.name]];
            if(v2.name.includes("pekerjaan")) vv=kerja[v[v2.name]];
            if(v2.name.includes("pendidikan")) vv=pdd[v[v2.name]];
            if(v2.name=="penghasilan_bulan") vv=gaji[v[v2.name]];
            if(v2.name=="m_status_rumah_id") vv=statrumah[v[v2.name]];
            if(v2.name=="m_kondisi_ayah_kandung_id") vv=statortu[v[v2.name]];
            if(v2.name=="m_kondisi_ibu_kandung_id") vv=statortu[v[v2.name]];
            if(v2.name=="m_transport_id") vv=transport[v[v2.name]];
            if(v2.name=="jurusan") vv=jurusan[v[v2.name]];
            if(v2.name=="m_jenis_sekolah_id") vv=jenskl[v[v2.name]];
            if(v2.name=="m_asal_sekolah_id") vv=jenasl[v[v2.name]];
            
            
            if (vv==undefined) vv='-';
            table+="<td>"+vv+"</td>";
        });
        table+="</tr>";
    });
    $("tbody").html(table);
    $('table').DataTable({
        "pageLength": 50,
        "scrollX": true,
        "scrollY":"450px",
        "dom": 'Bfrtip',
        "buttons": [
            'copy', 'excel', 'pdf','colvis'
        ],
    }).columns.adjust().draw();;
});
</script>