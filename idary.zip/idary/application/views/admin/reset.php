<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$fl = array(
  'class'=> 'col-sm-4 control-label'
);
$fc =array(
    'class'=> 'form-control',
    'type'=>'text',
    'autocomplete'=>'off'
);
echo dvo('panel panel-color panel-teal','d0')
	.dvo('panel-heading')
		.heading('Reset Password', 4, 'class="panel-title" id="judul"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
    	    .dvo('col-md-12')
    	        .form_open(base_url('cekjs'),'name="form" id="form" class="form-horizontal" style="background:white; border-top: 3px solid; margin-top:50px"')
    				.dvo('form-group')
    					.form_label('NISN', 'nisn', $fl)
    					.dvo('col-sm-8')
    						.form_input('nisn', '', $fc)
    					.dvc()
    				.dvc()
                	.form_button('simpan','Reset','btn btn-rounded btn-teal waves-effect waves-light btn-lg btn-block')
                .form_close();
		    echo dvc()
	    .dvc()
    .dvc()
.dvc();
echo JS_SWAL.JS_TOAST;
?>

<script>
    $("#form").on("submit",function(e){
        e.preventDefault();
        var values = $(this).serialize();
        swal({
        	title:"Menyimpan...", 
        	text:"Mohon tunggu sebentar. Jika tidak ada notifikasi sukses, silakan coba lagi",
        	type:"warning",
        	timer: 10000,
        	showConfirmButton:false,
        	closeOnCancel: false
    	});
        $.post("<?php  echo base_url('admin/reset_pass'); ?>",values,function(data){
            swal.close();
            if(data=="sukses") toastr.success('Data berhasil disimpan', 'Sukses!');
            else toastr.warning('NISN tidak terdeteksi', 'Gagal!');
        })
    });
</script>

