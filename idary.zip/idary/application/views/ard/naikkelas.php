<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$fl = array(
    'class'=> 'col-sm-4 control-label'
);
$op['majors']=array('1'=>'IPA','3'=>'BHS','2'=>'IPS','4'=>'PK');
$op['kelas_asal']=null;
$op['kelas_tujuan']=null;
$i=0;
foreach ($list_asal as $v) {
	$i++;
	$op['kelas_asal'][$v['school_class_id']]=$v['category_level_id'].' '.$op['majors'][$v['category_majors_id']].' '.$v['school_class_name'];
}
foreach ($list_tujuan as $v) {
	$i++;
	if($v['category_level_id']>10) $op['kelas_tujuan'][$v['school_class_id']]=$v['category_level_id'].' '.$op['majors'][$v['category_majors_id']].' '.$v['school_class_name'];
}
echo dvo('panel panel-color panel-teal')
	.dvo('panel-heading')
		.heading('Sekolah Asal', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('col-md-6','','border-right: 2px solid lightgrey')
			.form_open(base_url(''),'name="naikkelas" id="naikkelas" class="form-horizontal" style="background:white"')
				.dvo('form-group')
					.form_label('Kelas Asal', 'kelas_asal', $fl)
					.dvo('col-sm-8')
						.form_dropdown('kelas_asal',$op['kelas_asal'], $kelas_asal)
					.dvc()
				.dvc()
				.dvo('form-group')
					.form_label('Kelas Tujuan', 'kelas_tujuan', $fl)
					.dvo('col-sm-8')
						.form_dropdown('kelas_tujuan',$op['kelas_tujuan'], $kelas_tujuan)
					.dvc()
				.dvc()
				.form_button('','Simpan','btn btn-rounded btn-orange waves-effect waves-light btn-lg btn-block')
			.form_close()
		.dvc()
	.dvc()
.dvc()
.dvo('panel panel-color panel-teal')
	.dvo('panel-heading')
		.heading('Salin Jadwal Tahun Lalu', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('col-md-6','','border-right: 2px solid lightgrey')
			.form_button('copyjadwal','Salin','btn btn-rounded btn-teal waves-effect waves-light btn-lg btn-block')
		.dvc()
	.dvc()
.dvc();
echo JS_SWAL.JS_TOAST;
?>

<script type="text/javascript">
    $("form").submit(function(e){
        e.preventDefault();
        swal({
        	title:"Menyimpan...", 
        	text:"Mohon tunggu sebentar. Jika tidak ada notifikasi sukses, silakan coba lagi",
        	type:"warning",
        	timer: 10000,
        	closeOnCancel: false
    	});
    	var values=$(this).serialize();
        $.post("<?php echo base_url("admin/ardnaikkelas"); ?>",values,function(){
            swal.close();
            toastr.success("Data Anda berhasil disimpan","Sukses!");
        });
    })
    $("#copyjadwal").click(function(){
    	$.get("<?php echo base_url("admin/ardcopyngajar"); ?>",function(){
            swal.close();
            toastr.success("Data Anda berhasil disimpan","Sukses!");
        });
    })
	
</script>