<?php
defined('BASEPATH') OR exit('No direct script access allowed');
echo dvo('panel panel-color panel-teal','d1')
	.dvo('panel-heading')
		.heading('Daftar Santri Ponpes '.$this->session->userdata('user_fullname'), 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		        .tableo('list','','width=100%')
    		        .theado()
    		            .tro()
    		                .th('NISN')
    		                .th('Nama')
    		                .th('Kelas')
    		                .th('Verifikasi')
    		                .th('Detail')
    		            .trc()
                    .theadc()
                    .tbodyo()
                    .tbodyc()
		        .tablec()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();

echo JS_SWAL.JS_TOAST;
?>

<link href="<?php echo base_url()?>assets/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url()?>assets/plugins/datatables/datatables.min.js"></script>

<script>
    $(document).ready(function(){
        $("table").DataTable({
            scrollX:true,
            columnDefs: [{
		        "render": function ( data, type, row ) {
		            var btn3='<button id="'+row[0]+'" onclick="verifikasi(this)" class="btn btn-rounded btn-danger"><i class="mdi mdi-close-circle"></i></button>';
		            if(parseInt(row[3])>0) btn3='<button id="'+row[0]+'" onclick="verifikasi(this)" class="btn btn-rounded btn-success"><i class="mdi mdi-checkbox-marked-circle"></i></button>';
		            return btn3;
                },
                "targets": 3
		    },{
		        "render": function ( data, type, row ) {
		            var btn4='<button data-id="'+row[4]+'" onclick="detailsantri($(this).data(\'id\'))" class="btn btn-info"><i class="mdi mdi-eye"></i></button>';
		            return btn4;
                },
                "targets": 4
		    }]
        });
    });
    var santri=<?php echo json_encode($listsantri);?>;
    var table='';
    $.each(santri,function(i,v){
        table+="<tr><td>"+v.nisn+"</td><td>"+v.nama_lengkap+"</td><td>"+v.kelas+"</td><td>"+v.statussantri+"</td><td></td></tr>";
    })
    $("#list tbody").html(table);
    function verifikasi(nisn){
	    swal({
        	title:"Memproses...", 
        	text:"Mohon tunggu sebentar. Jika halaman tidak dialihkan, silakan coba lagi",
        	type:"info",
        	timer: 10000,
        	showConfirmButton:false,
        	closeOnCancel: false,
    	});
        var status=1;
        if($(nisn).hasClass("btn-success")) status=0;
        $.get("<?php echo base_url('pondok/status_santri?nisn='); ?>"+nisn.id+"&status="+status,function(){
            swal.close();
            if(status==1) $(nisn).removeClass('btn-danger').addClass("btn-success").html('<i class="mdi mdi-checkbox-marked-circle">');
            else $(nisn).removeClass('btn-success').addClass("btn-danger").html('<i class="mdi mdi-close-circle"></i>');
            toastr.success('Berhasil mengubah data', 'Sukses!');
        })
    }
    
</script>

