<?php
defined('BASEPATH') OR exit('No direct script access allowed');
setlocale(LC_ALL, 'id-ID', 'id_ID');
$peraturan=array(
    strftime("%A, %d %B %Y", strtotime(date("Y-m-d"))),
    'Mohon presensi santri dicek pada tabel berikut.',
    'Jika presensi santri "Hadir" tapi tidak mengumpuikan tugas, maka akan dianggap tidak hadir.',
    'Daftar hadir harus diisi setiap hari. Jika tidak mengisi presensi hari ini maka semua santri dianggap tidak mengikuti KBM daring.',
    'Silakan klik tombol simpan hanya setelah selesai mengakses pembelajaran',
    'Santri yang berada di rumah harap ditandai merah karena akan merugikan santri tersebut jika dia mengakses pembelajaran dari rumah'
);
$fl = array(
  'class'=> 'col-sm-4 control-label'
);
$list=null;
$bulan=array(
    '1'=>'Januari',
    '2'=>'Februari',
    '3'=>'Maret',
    '4'=>'April',
    '5'=>'Mei',
    '6'=>'Juni',
    '7'=>'Juli',
    '8'=>'Agustus',
    '9'=>'September',
    '10'=>'Oktober',
    '11'=>'November',
    '12'=>'Desember'
    );
foreach ($listmapel as $l) $list[$l['id']]=$l['tema'];
echo dvo('panel panel-color panel-teal','d0')
	.dvo('panel-heading')
		.heading('Rekap Presensi', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
    	        .form_open(base_url('pondok/presensi'),'method="get" name="form0" id="form0" class="form-horizontal"')
    				.dvo('form-group')
    					.form_label('Bulan', 'bulan', $fl)
    					.dvo('col-sm-8')
    						.form_dropdown('bulan', $bulan,date('m'))
    					.dvc()
    				.dvc()
                	.form_button('simpan','Lihat Rekap Presensi','btn btn-rounded btn-teal waves-effect waves-light btn-lg btn-block')
                .form_close()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();
echo dvo('panel panel-color panel-teal','d1')
	.dvo('panel-heading')
		.heading('Presensi Santri Ponpes '.$this->session->userdata('user_fullname'), 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		        .ul($peraturan)
		        .tableo('list','','width=100%')
    		        .theado()
    		            .tro()
    		                .th('NISN')
    		                .th('Nama')
    		                .th('Kelas')
    		                .th('Ikut KBM hari ini?')
    		            .trc()
                    .theadc()
                    .tbodyo()
                    .tbodyc()
		        .tablec()
		        
    	        .form_open(base_url('cekjs'),'name="form" id="form" class="form-horizontal" style="background:white; border-top: 3px solid; margin-top:50px"')
    				.dvo('form-group')
    					.form_label('Materi', 'materi', $fl)
    					.dvo('col-sm-8')
    						.form_dropdown('materi', $list)
    					.dvc()
    				.dvc()
                	.form_button('simpan','Kirim Presensi Hari ini','btn btn-rounded btn-teal waves-effect waves-light btn-lg btn-block')
                .form_close()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();

echo JS_SWAL.JS_TOAST;
?>

<link href="<?php echo base_url()?>assets/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url()?>assets/plugins/datatables/datatables.min.js"></script>

<script>
    $(document).ready(function(){
        $("table").DataTable({
            scrollX:true,
            columnDefs: [{
		        "render": function ( data, type, row ) {
		            var btn3='<button id="'+row[0]+'" onclick="verifikasi(this)" class="btn btn-rounded btn-danger"><i class="mdi mdi-close-circle"></i></button>';
		            if(parseInt(row[3])==1) btn3='<button id="'+row[0]+'" onclick="verifikasi(this)" class="btn btn-rounded btn-success"><i class="mdi mdi-checkbox-marked-circle"></i></button>';
		            return btn3;
                },
                "targets": 3
		    }]
        });
    });
    var santri=<?php echo json_encode($listsantri);?>;
    var table='';
    $.each(santri,function(i,v){
        table+="<tr><td>"+v.nisn+"</td><td>"+v.nama_lengkap+"</td><td>"+v.kelas+"</td><td>"+v.statussantri+"</td></tr>";
    })
    $("#list tbody").html(table);
    function verifikasi(nisn){
	    swal({
        	title:"Memproses...", 
        	text:"Mohon tunggu sebentar. Jika halaman tidak dialihkan, silakan coba lagi",
        	type:"info",
        	timer: 10000,
        	showConfirmButton:false,
        	closeOnCancel: false,
    	});
        var status=1;
        if($(nisn).hasClass("btn-success")) status=2;
        $.get("<?php echo base_url('pondok/status_santri?nisn='); ?>"+nisn.id+"&status="+status,function(){
            swal.close();
            if(status==1) $(nisn).removeClass('btn-danger').addClass("btn-success").html('<i class="mdi mdi-checkbox-marked-circle">');
            else $(nisn).removeClass('btn-success').addClass("btn-danger").html('<i class="mdi mdi-close-circle"></i>');
            toastr.success('Berhasil mengubah data', 'Sukses!');
        })
    }
    $("#form").submit(function(e){
        e.preventDefault();
        present();
    })
    function present(){
	    swal({
        	title:"Memproses...", 
        	text:"Mohon tunggu sebentar. Jika halaman tidak dialihkan, silakan coba lagi",
        	type:"info",
        	timer: 10000,
        	showConfirmButton:false,
        	closeOnCancel: false,
    	});
    	var materi=$("#materi").val();
        $.get("<?php echo base_url('pondok/present?materi='); ?>"+materi,function(){
            swal.close();
            toastr.success('Presensi sudah terkirim', 'Sukses!');
        });
    }
</script>

