<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$bln=array(
    '1'=>'Januari',
    '2'=>'Februari',
    '3'=>'Maret',
    '4'=>'April',
    '5'=>'Mei',
    '6'=>'Juni',
    '7'=>'Juli',
    '8'=>'Agustus',
    '9'=>'September',
    '10'=>'Oktober',
    '11'=>'November',
    '12'=>'Desember'
    );
echo dvo('panel panel-color panel-teal','d1')
	.dvo('panel-heading')
		.heading('Presensi KBM Daring', 4, 'class="panel-title"')
	.dvc()
	.dvo('panel-body')
		.dvo('row')
		    .dvo('col-md-12')
		        .'pondok : '
		        .'<br/>bulan : '.strftime("%B", strtotime(date("Y-m-d")))
		        .tableo('list','','width=100%')
    		        .theado()
    		            .tro()
    		                .th('Kelas')
    		                .th('Nama');
    		                for($i=1;$i<=31;$i++){
    		                    echo th($i);
    		                }
    		            echo trc()
                    .theadc()
                    .tbodyo()
                    .tbodyc()
		        .tablec()
		    .dvc()
	    .dvc()
    .dvc()
.dvc();
echo JS_SWAL;
?>

<link href="<?php echo base_url()?>assets/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url()?>assets/plugins/datatables/datatables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.html5.min.js"></script>

<script>
    $(document).ready(function(){
        $("table").DataTable({
            dom: 'Bfrtip',
            scrollX:true,
            buttons: [
            'copy', 'excel', 'pdf'],
        });
    });
    var presensi=<?php echo json_encode($presensi);?>;
    var absen={};
    var table='';
    $.each(presensi,function(i,v){
        absen[v.nisn]=[];
    })
    $.each(presensi,function(i,v){
        absen[v.nisn]["absen"]=v.kelas;
        absen[v.nisn]["nama_lengkap"]=v.nama_lengkap;
        absen[v.nisn][v.notif_date]=1;
    })
    // alert(JSON.stringify(absen));
    $.each(absen,function(i,v){
        table+="<tr><td>"+v.absen+"</td><td>"+v.nama_lengkap+"</td>";
        for(var j=1;j<=31;j++){
            if(v[j]==undefined) v[j]="";
            else v[j]="&#10003;";
            table+="<td>"+v[j]+"</td>";
        }
        table+="</tr>";
    })
    // alert(JSON.stringify(absen));
    $("#list tbody").html(table);
    
    function swall(){
	    swal({
        	title:"Mengalihkan...", 
        	text:"Mohon tunggu sebentar. Jika halaman tidak dialihkan, silakan coba lagi",
        	type:"info",
        	timer: 2000,
        	showConfirmButton:false,
        	closeOnCancel: false,
    	});
    }
</script>