<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
        </div><!-- end container -->
    </div><!-- end navbar -->
</div>
<!-- Top Bar End -->


<!-- ========== Left Sidebar Start ========== -->
<div class="left side-menu">
    <div class="sidebar-inner slimscrollleft">

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- User detail -->
            <div class="user-details">
                <div class="overlay"></div>
                <div class="text-center" >
                    <h4><i style="color:white;">"Jangan lupa Bismillah"</i></h4>
                </div>
            </div>
            <!-- end user detail -->

            <ul>
            	<li class="menu-title">Menu</li>
<?php
foreach ($sidemenus as $value){
    if($value['menu_parent']==0){
        echo
            '<li class="has_sub">
                <a href="';
                if($value['menu_link']==null)
                    echo 'javascript:void(0);';
                    else echo base_url($value['menu_link']);
                echo '" class="waves-effect"><i class="'.$value['menu_icon'].'"></i><span> '.$value['menu_name'].' </span>';
                if($value['menu_link']==null) echo '<span class="menu-arrow"></span>';
                echo '</a>';
                    $n=1;
                    foreach ($sidemenus as $value2){
                        if($value2['menu_parent']==$value['menu_id']){
                            if($n==1) echo '<ul class="list-unstyled">';
                    echo '<li><a href="'.base_url($value2['menu_link']).'"><i class="'.$value2['menu_icon'].'"></i>'.$value2['menu_name'].'</a></li>';
                    $n=2;
                        }};
                        if($n==2) echo '</ul>';
            echo '</li>';
}};
?>

            </ul>
        </div>
        <!-- Sidebar -->
        <div class="clearfix"></div>

        <div class="help-box">
            <h5 class="text-muted m-t-0">Butuh Bantuan?</h5>
            <p class=""><span class="text-dark"><b>Hubungi:</b></span> <br/> Admin Madrasah</p>
            <p class="m-b-0"><span class="text-dark"><b>No. WA:</b></span> <br/> +62 1234567890</p>
        </div>

    </div>
    <!-- Sidebar -left -->

</div>
<!-- Left Sidebar End -->



<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">


            <div class="row">
				<div class="col-xs-12">
					<div class="page-title-box">
                        <h4 class="page-title">Siswa</h4>
                        <ol class="breadcrumb p-0 m-0">
                            <!--<li>-->
                            <!--    <a href="<?php //echo base_url();?>">Idary Admin</a>-->
                            <!--</li>-->
                            <!--<li>-->
                            <!--    <a href="<?php //echo base_url('student');?>">Student</a>-->
                            <!--</li>-->
                            <li class="active" id="judul_hlm">
                                Beranda
                            </li>
                        </ol>
                        <div class="clearfix"></div>
                    </div>
				</div>
			</div>
            <!-- end row -->

