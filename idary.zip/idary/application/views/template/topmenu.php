
<!-- Right(Notification) -->
<ul class="nav navbar-nav navbar-right">
    <!--<li>-->
    <!--    <a href="#" class="right-menu-item dropdown-toggle" data-toggle="dropdown">-->
    <!--        <i class="mdi mdi-bell"></i>-->
    <!--        <span class="badge up bg-primary">4</span>-->
    <!--    </a>-->

    <!--    <ul class="dropdown-menu dropdown-menu-right arrow-dropdown-menu arrow-menu-right dropdown-lg user-list notify-list">-->
    <!--        <li>-->
    <!--            <h5>Notifications</h5>-->
    <!--        </li>-->
    <!--        <li>-->
    <!--            <a href="#" class="user-list-item">-->
    <!--                <div class="icon bg-info">-->
    <!--                    <i class="mdi mdi-account"></i>-->
    <!--                </div>-->
    <!--                <div class="user-desc">-->
    <!--                    <span class="name">New Signup</span>-->
    <!--                    <span class="time">5 hours ago</span>-->
    <!--                </div>-->
    <!--            </a>-->
    <!--        </li>-->
    <!--        <li>-->
    <!--            <a href="#" class="user-list-item">-->
    <!--                <div class="icon bg-danger">-->
    <!--                    <i class="mdi mdi-comment"></i>-->
    <!--                </div>-->
    <!--                <div class="user-desc">-->
    <!--                    <span class="name">New Message received</span>-->
    <!--                    <span class="time">1 day ago</span>-->
    <!--                </div>-->
    <!--            </a>-->
    <!--        </li>-->
    <!--        <li>-->
    <!--            <a href="#" class="user-list-item">-->
    <!--                <div class="icon bg-warning">-->
    <!--                    <i class="mdi mdi-settings"></i>-->
    <!--                </div>-->
    <!--                <div class="user-desc">-->
    <!--                    <span class="name">Settings</span>-->
    <!--                    <span class="time">1 day ago</span>-->
    <!--                </div>-->
    <!--            </a>-->
    <!--        </li>-->
    <!--        <li class="all-msgs text-center">-->
    <!--            <p class="m-0"><a href="#">See all Notification</a></p>-->
    <!--        </li>-->
    <!--    </ul>-->
    <!--</li>-->

    <!--<li>-->
    <!--    <a href="#" class="right-menu-item dropdown-toggle" data-toggle="dropdown">-->
    <!--        <i class="mdi mdi-email"></i>-->
    <!--        <span class="badge up bg-danger">8</span>-->
    <!--    </a>-->

    <!--    <ul class="dropdown-menu dropdown-menu-right arrow-dropdown-menu arrow-menu-right dropdown-lg user-list notify-list">-->
    <!--        <li>-->
    <!--            <h5>Messages</h5>-->
    <!--        </li>-->
    <!--        <li>-->
    <!--            <a href="#" class="user-list-item">-->
    <!--                <div class="avatar">-->
    <!--                    <img src="<?php echo base_url();?>assets/images/users/avatar-2.jpg" alt="">-->
    <!--                </div>-->
    <!--                <div class="user-desc">-->
    <!--                    <span class="name">Patricia Beach</span>-->
    <!--                    <span class="desc">There are new settings available</span>-->
    <!--                    <span class="time">2 hours ago</span>-->
    <!--                </div>-->
    <!--            </a>-->
    <!--        </li>-->
    <!--        <li>-->
    <!--            <a href="#" class="user-list-item">-->
    <!--                <div class="avatar">-->
    <!--                    <img src="<?php echo base_url();?>assets/images/users/avatar-3.jpg" alt="">-->
    <!--                </div>-->
    <!--                <div class="user-desc">-->
    <!--                    <span class="name">Connie Lucas</span>-->
    <!--                    <span class="desc">There are new settings available</span>-->
    <!--                    <span class="time">2 hours ago</span>-->
    <!--                </div>-->
    <!--            </a>-->
    <!--        </li>-->
    <!--        <li>-->
    <!--            <a href="#" class="user-list-item">-->
    <!--                <div class="avatar">-->
    <!--                    <img src="<?php echo base_url();?>assets/images/users/avatar-4.jpg" alt="">-->
    <!--                </div>-->
    <!--                <div class="user-desc">-->
    <!--                    <span class="name">Margaret Becker</span>-->
    <!--                    <span class="desc">There are new settings available</span>-->
    <!--                    <span class="time">2 hours ago</span>-->
    <!--                </div>-->
    <!--            </a>-->
    <!--        </li>-->
    <!--        <li class="all-msgs text-center">-->
    <!--            <p class="m-0"><a href="#">See all Messages</a></p>-->
    <!--        </li>-->
    <!--    </ul>-->
    <!--</li>-->

    <!--<li>-->
    <!--    <a href="javascript:void(0);" class="right-bar-toggle right-menu-item">-->
    <!--        <i class="mdi mdi-settings"></i>-->
    <!--    </a>-->
    <!--</li>-->

    <li class="dropdown user-box">
        <a href="" class="dropdown-toggle waves-effect waves-light user-link" data-toggle="dropdown" aria-expanded="true">
            <img src="<?php echo base_url();?>assets/images/users/avatar-1.jpg" alt="user-img" class="img-circle user-img">
        </a>

        <ul class="dropdown-menu dropdown-menu-right arrow-dropdown-menu arrow-menu-right user-list notify-list">
            <li>
                <h5>مرحبا أهلا وسهلا</h5>
            </li>
            <li><a href="<?php echo base_url('logout'); ?>"><i class="ti-power-off m-r-5"></i> Logout</a></li>
        </ul>
    </li>

</ul> <!-- end navbar-right -->