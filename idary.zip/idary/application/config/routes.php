<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['(:any)']="home/$1";
$route['fungsi/(:any)']="home/fungsi/$1";
$route['(:any)/(:any)']="$1/home/$2";
$route['(:any)/(:any)/(:any)']="$1/home/$2/$3";
