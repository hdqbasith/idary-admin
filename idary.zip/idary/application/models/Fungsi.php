<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Fungsi extends CI_Model{
    function __construct(){
        parent::__construct();
        $this->dbrevo = $this->load->database('revo', TRUE);
    }
//----------------------------------- TEMPLATE
	public function sidemenu($level)
	{
		$where = array (
		    'user_level' => $level,
		    'menu_active' => '1',
		);
		$query=$this->dbrevo->select('*')->from('template__menu')->where($where)->order_by('menu_order')->get();
		$result=$query->result_array();
		return $result;
	}
//----------------------------------
	public function sesi()
	{
		echo 'ok'.$this->session->userdata('level');
	}
//----------------------------------- END
//
//----------------------------------- LOGIN/SIGNUP/LOGOUT
	public function ceknisn($username)
	{
		$query=$this->dbrevo->select('username')->from('user')->where('username=', $username)->get();
		return $query->result_array();
	}
	public function cekuser($username)
	{
		$query=$this->dbrevo->select('username, password, nama, level')->from('user')->where('username=', $username)->get();
	    return $query->result_array();
	}
//----------------------------------- END

//----------------------------------- PPDB
	public function simpanppdb(){
	    $nisn=$this->session->userdata('username');
	    $level=$this->session->userdata('level');
	    if($nisn==null){
	        redirect(site_url());
	    }
	    $data=array('nisn'=>ucwords(strtolower($this->input->post('nisn'))), 'nik'=>ucwords(strtolower($this->input->post('nik'))), 'namasiswa'=>ucwords(strtolower($this->input->post('namasiswa'))), 'kksiswa'=>ucwords(strtolower($this->input->post('kksiswa'))), 'arabsiswa'=>ucwords(strtolower($this->input->post('arabsiswa'))), 'ttlsiswa'=>ucwords(strtolower($this->input->post('ttlsiswa'))), 'tglsiswa'=>ucwords(strtolower($this->input->post('tglsiswa'))), 'emailsiswa'=>ucwords(strtolower($this->input->post('emailsiswa'))), 'hpsiswa'=>ucwords(strtolower($this->input->post('hpsiswa'))), 'jrssiswa'=>ucwords(strtolower($this->input->post('jrssiswa'))), 'jrssiswa2'=>ucwords(strtolower($this->input->post('jrssiswa2'))), 'namaayah'=>ucwords(strtolower($this->input->post('namaayah'))), 'nikayah'=>ucwords(strtolower($this->input->post('nikayah'))), 'ttlayah'=>ucwords(strtolower($this->input->post('ttlayah'))), 'tglayah'=>ucwords(strtolower($this->input->post('tglayah'))), 'pddayah'=>ucwords(strtolower($this->input->post('pddayah'))), 'kerjaayah'=>ucwords(strtolower($this->input->post('kerjaayah'))), 'nhasilayah'=>ucwords(strtolower($this->input->post('nhasilayah'))), 'hpayah'=>ucwords(strtolower($this->input->post('hpayah'))), 'statusayah'=>ucwords(strtolower($this->input->post('statusayah'))), 'namaibu'=>ucwords(strtolower($this->input->post('namaibu'))), 'nikibu'=>ucwords(strtolower($this->input->post('nikibu'))), 'ttlibu'=>ucwords(strtolower($this->input->post('ttlibu'))), 'tglibu'=>ucwords(strtolower($this->input->post('tglibu'))), 'pddibu'=>ucwords(strtolower($this->input->post('pddibu'))), 'kerjaibu'=>ucwords(strtolower($this->input->post('kerjaibu'))), 'nhasilibu'=>ucwords(strtolower($this->input->post('nhasilibu'))), 'hpibu'=>ucwords(strtolower($this->input->post('hpibu'))), 'statusibu'=>ucwords(strtolower($this->input->post('statusibu'))), 'hubwali'=>ucwords(strtolower($this->input->post('hubwali'))), 'namawali'=>ucwords(strtolower($this->input->post('namawali'))), 'nikwali'=>ucwords(strtolower($this->input->post('nikwali'))), 'ttlwali'=>ucwords(strtolower($this->input->post('ttlwali'))), 'tglwali'=>ucwords(strtolower($this->input->post('tglwali'))), 'pddwali'=>ucwords(strtolower($this->input->post('pddwali'))), 'kerjawali'=>ucwords(strtolower($this->input->post('kerjawali'))), 'nhasilwali'=>ucwords(strtolower($this->input->post('nhasilwali'))), 'hpwali'=>ucwords(strtolower($this->input->post('hpwali'))), 'namadrr'=>ucwords(strtolower($this->input->post('namadrr'))), 'hpdrr'=>ucwords(strtolower($this->input->post('hpdrr'))), 'provsiswa'=>ucwords(strtolower($this->input->post('provsiswa'))), 'kabsiswa'=>ucwords(strtolower($this->input->post('kabsiswa'))), 'kecsiswa'=>ucwords(strtolower($this->input->post('kecsiswa'))), 'desasiswa'=>ucwords(strtolower($this->input->post('desasiswa'))), 'rtsiswa'=>ucwords(strtolower($this->input->post('rtsiswa'))), 'rwsiswa'=>ucwords(strtolower($this->input->post('rwsiswa'))), 'possiswa'=>ucwords(strtolower($this->input->post('possiswa'))), 'kossiswa'=>ucwords(strtolower($this->input->post('kossiswa'))), 'almlengkap'=>ucwords(strtolower($this->input->post('almlengkap'))), 'anakke'=>ucwords(strtolower($this->input->post('anakke'))), 'jmlsdr'=>ucwords(strtolower($this->input->post('jmlsdr'))), 'jmlkdg'=>ucwords(strtolower($this->input->post('jmlkdg'))), 'jmltiri'=>ucwords(strtolower($this->input->post('jmltiri'))), 'aslsb'=>ucwords(strtolower($this->input->post('aslsb'))), 'almsb'=>ucwords(strtolower($this->input->post('almsb'))), 'nissb'=>ucwords(strtolower($this->input->post('nissb'))), 'jensb'=>ucwords(strtolower($this->input->post('jensb'))), 'statsb'=>ucwords(strtolower($this->input->post('statsb'))), 'thlulussb'=>ucwords(strtolower($this->input->post('thlulussb'))), 'unindo'=>ucwords(strtolower($this->input->post('unindo'))), 'unmtk'=>ucwords(strtolower($this->input->post('unmtk'))), 'uning'=>ucwords(strtolower($this->input->post('uning'))), 'unipa'=>ucwords(strtolower($this->input->post('unipa'))), 'namapondok'=>ucwords(strtolower($this->input->post('namapondok'))), 'pimpondok'=>ucwords(strtolower($this->input->post('pimpondok'))), 'almpondok'=>ucwords(strtolower($this->input->post('almpondok'))), 'hppondok'=>ucwords(strtolower($this->input->post('hppondok'))));
	    if ($level==NULL) {
			$this->db->insert('ppdb',$data);
			$query=$this->db->select('id')->from('ppdb')->where('nisn=', $nisn)->get();
    		$result = $query->result_array();
	        foreach ($result as $value){
			    $this->db->set('reg','340'.sprintf('%03d', $value['id']))->where('id',$value['id'])->update('ppdb');
	        }
		    echo "simpan";
		}
		else {
			$this->db->where('nisn',$nisn);
			$this->db->update('ppdb',$data);
		    echo "update";
		}
	}
	public function listpendaftar(){
		$query=$this->db->select('*')->from('ppdb')->get();
		$result = $query->result_array();
		
		echo '{"data" : [';
		$n=1;
		foreach ($result as $value) {
		    $id=$value['id'];
			if($n>1)
				echo ",";
			$no = $n++;
			echo '["'.$id.'", "'.$no.'", "'.$value['reg'].'", "'.$value['namasiswa'].'", "'.$value['nisn'].'", "'.$value['namaayah'].'", "'.$value['aktif'].'", "'.''.'"]';
		}
		echo ']}';
	    
	}
	public function password()
	{
		$query=$this->db->select('password')->from('user')->where('username=', $this->session->userdata('username'))->get();
		return $query->result();
	}
	public function detailppdb($nisn)
	{
		$query=$this->db->select('*')->from('ppdb')->where('nisn=', $nisn)->get();
		return $query->result();
	}
	public function kuitansi($id)
	{
		$query=$this->db->select('namasiswa, namawali, almlengkap')->from('ppdb')->where('id=', $id)->get();
		return $query->result();
	}
	public function bayar(){
	    $data=$this->input->post('isi');
	    $id=trim($this->input->post('id'),'sw');
		$this->db->set('bayar', $data)->where('id', $id)->update('ppdb');
	}
	public function cekberkas($id){
		$query=$this->db->select('akta, kk, raport, skhun, ijazah, foto')->from('ppdb')->where('id=', $id)->get();
		return $query->result();
	}
	public function berkas(){
		$id=$this->input->post('id');
		$berkas=$this->input->post('berkas');
		$nilai=$this->input->post('nilai');
		$this->db->set($berkas, $nilai)->where('id', $id)->update('ppdb');
	}
//----------------------------------- PPDB

//----------------------------------- Siswa Baru
	public function cekmigrasi(){
		$query=$this->db->select('username, nama, namasiswa')->from('user')->join('ppdb', 'user.username=ppdb.nisn', 'left')->get();
		$result = $query->result_array();
		
		echo '{"data" : [';
		$n=1;
		foreach ($result as $value) {
			if($n>1)
				echo ",";
			$no = $n++;
			echo '["'.$no.'", "'.$value['username'].'", "'.$value['nama'].'", "'.$value['namasiswa'].'", "'.''.'"]';
		}
		echo ']}';
	    
	}
	public function migpri(){
		$query=$this->db->select('username, reg, nisn, nik, kksiswa, nama, arabsiswa, ttlsiswa, tglsiswa, emailsiswa, hpsiswa, provsiswa, kabsiswa, kecsiswa, desasiswa, rtsiswa, rwsiswa, possiswa, kossiswa, almlengkap, namapondok, pimpondok, almpondok, hppondok, ket')->from('user')->join('ppdb', 'user.username=ppdb.nisn', 'left')->get();
		$result = $query->result_array();
		echo '{"data" : [';
		$n=1;
		foreach ($result as $value) {
			if($n>1)
				echo ",";
			$no = $n++;
			echo '["'.$value['reg'].'", "'.$value['nisn'].'", "'.$value['nik'].'", "'.$value['kksiswa'].'", "'.$value['nama'].'","'.$value['arabsiswa'].'", "'.$value['ttlsiswa'].'", "'.$value['tglsiswa'].'", "'.$value['emailsiswa'].'", "'.$value['hpsiswa'].'", "'.$value['provsiswa'].'", "'.$value['kabsiswa'].'", "'.$value['kecsiswa'].'", "'.$value['desasiswa'].'", "'.$value['rtsiswa'].'", "'.$value['rwsiswa'].'", "'.$value['possiswa'].'", "'.$value['kossiswa'].'", "'.$value['almlengkap'].'", "'.$value['namapondok'].'", "'.$value['pimpondok'].'", "'.$value['almpondok'].'", "'.$value['hppondok'].'", "'.$value['ket'].'"]';
		}
		echo ']}';
	}

//----------------------------------- END

//----------------------------------- Guru
	public function datasiswa(){
		$query=$this->db->select('username, nama, desasiswa, kecsiswa, kabsiswa, namapondok, prlsiswa')->from('user')->join('siswa_pribadi', 'user.username=siswa_pribadi.nisn', 'left')->join('siswa_kelas', 'user.username=siswa_kelas.nisn', 'left')->where('level',8)->order_by('prlsiswa','asc')->get();
		$result = $query->result_array();
		
		echo '{"data" : [';
		$n=1;
		foreach ($result as $value) {
			if($n>1)
				echo ",";
			$no = $n++;
			echo '["'.$no.'", "'.$value['prlsiswa'].'", "'.$value['nama'].'", "'.$value['desasiswa'].' '.$value['kecsiswa'].' '.$value['kabsiswa'].'", "'.$value['namapondok'].'", "'.$value['username'].'"]';
		}
		echo ']}';
	    
	}
	public function cekuuid(){
	    $data = array(
            'nama' => 'contact@codexworld.com',
            'username' => '8888888888'
        );
        
        //set id column value as UUID
        $this->db->set('password', 'UUID()', FALSE);
        
        //insert all together
        $this->db->insert('admin',$data);
	}
	public function listprov($parent){
	    return $this->db->select('code,name')->from('wilayah')->where('parent',$parent)->get()->result_array();
	}
	public function listpondok($id){
	    if($id==null) return $this->db->select('*')->from('pondok')->get()->result_array();
	    else return $this->db->select('*')->from('pondok')->where('id',$id)->get()->row_array();
	}

}

?>