<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Fstudent extends CI_Model{
    function __construct(){
        parent::__construct();
        $this->dbrevo = $this->load->database('revo', TRUE);
    }
	public function getnisn()
	{
        $nisn['nisn']=$this->session->userdata('username');
        return $nisn;
	}
	public function cekver()
	{
	    $nisn=$this->getnisn();
        $data=$this->dbrevo->select('kelas,jurusan,absen')->from('student__biodata')->where($nisn)->get()->row_array();
        return $data;
	}
    public function verifikasi($data=null)
	{
	    if($data==null){
    	    $nisn=$this->getnisn();
    	    $q=$this->dbrevo->select('nisn,nama_lengkap,kelas,jurusan,absen')->from('student__biodata')->where($nisn)->get()->row_array();
    	    return $q;
	    }else{
    	    $q=$this->verifikasi();
    	    $d['nisn']=$data['nisn'];
    	    $d['nisn_lama']=$data['nisn_lama'];
    	    $d['nama_lengkap']=$data['nama_lengkap'];
    	    $d['kelas']=$data['kelas'];
    	    $d['jurusan']=$data['jurusan'];
    	    $d['absen']=$data['absen'];
    	    $d['updated']=date('Y-m-d H:i:s');
            $this->dbrevo->where('username',$d['nisn_lama'])->update('user',array('username'=>$d['nisn'],'password'=>md5($data['pass_baru']),'nama'=>$d['nama_lengkap']));
            unset($d['nisn_lama']);
    	    if($q==null) {
    	        $this->dbrevo->insert('student__biodata',$d);
    	    }
    	    else{
    	        $this->dbrevo->where('nisn',$d['nisn'])->update('student__biodata',$d);
    	    }
	    }
	}
    public function daftar_mapel($data=null)
	{
	    $w['jenis']=$data;
	    $w['date']=date('Y-m-d H:i:s');
	    if($this->session->userdata('user_level')<8) $w['date']=date('Y-m-d 07:i:s');
	    $q=$this->dbrevo->select('*')->from('student__mapel')->where('jenis',$w['jenis'])->order_by('kelas')->get()->result();
	    return $q;
	}
    public function videoyt($data=null)
	{
	    $db='student__mapel';
	    $db2='user__notification';
	    if(isset($data['id'])){
	        $q=$this->dbrevo->select('*')->from($db)->where($data)->get()->row_array();
	        $r=$this->dbrevo->select('notif_status,notif_content')->from($db2)->where('notif_for',$this->session->userdata('username'))->where('notif_title',$data['id'])->get()->row_array();
	        $q['persen']=$r['notif_status'];
	        $q['notif_content']=$r['notif_content'];
	        return $q;
	    }else{
	        $w=array('notif_for'=>$data['notif_for'],'notif_title'=>$data['notif_title']);
	        $q=$this->dbrevo->select('*')->from($db2)->where($w)->get()->row_array();
	        if($q==null){
	            $this->dbrevo->insert($db2,$data);
	        }else{
	            $this->dbrevo->where($w)->update($db2,$data);
	        }
	    }
	}
    public function audio($data=null)
	{
	    $db='student__mapel';
	    $db2='user__notification';
	    if(isset($data['id'])){
	        $q=$this->dbrevo->select('*')->from($db)->where($data)->get()->row_array();
	        $r=$this->dbrevo->select('notif_status,notif_content')->from($db2)->where('notif_for',$this->session->userdata('username'))->where('notif_title',$data['id'])->get()->row_array();
	        $q['persen']=$r['notif_status'];
	        $q['notif_content']=$r['notif_content'];
	        return $q;
	    }else{
	        $w=array('notif_for'=>$data['notif_for'],'notif_title'=>$data['notif_title']);
	        $q=$this->dbrevo->select('*')->from($db2)->where($w)->get()->row_array();
	        if($q==null){
	            $this->dbrevo->insert($db2,$data);
	        }else{
	            $this->dbrevo->where($w)->update($db2,$data);
	        }
	    }
	}
	
	public function soal_tes($mapel)
	{
	    $result= $this->dbrevo->select('*')->from('student__soal_tes')->where('mapel',$mapel)->get()->result_array();
        shuffle($result);
	    $data=null;
	    $i=1;
	    foreach ($result as $r){
	        $data[$i]=$r;
	        $i++;
	    };
	    return $data;
	}
	public function jawaban_tes($data,$aksi,$data2)
	{
	    if($aksi=='mulai'){
	        $mulai=$this->dbrevo->select('waktu_mulai,jawaban')->from('student__jawaban_tes')->where('mapel',$data['mapel'])->where('nisn',$data['nisn'])->get()->row_array();
    	    if($mulai==null){
    	        $this->dbrevo->insert('student__jawaban_tes',$data);
    	        return $data['waktu_mulai'];
    	    } elseif($mulai['jawaban']==null){
    	        return $mulai['waktu_mulai'];
    	    } else return 'gagal';
	    } else if($aksi=='selesai'){
	        $this->dbrevo->where('nisn',$data['nisn'])->where('mapel',$data['mapel'])->update('student__jawaban_tes',$data);
    	    $cek=$this->dbrevo->select('*')->from('user__notification')->where('notif_for',$data2['notif_for'])->where('notif_title',$data['notif_title'])->get()->row_array();
    	    if($cek==null){
    	        $this->dbrevo->insert('user__notification',$data2);
    	    } else{
    	        $this->dbrevo->where('notif_for',$data2['notif_for'])->where('notif_title',$data['notif_title'])->update('user__notification',$data2);
    	    }
	        return 'selesai';
	    }
	}
	public function ikut_tes($mapel)
	{
	    $query=$this->dbrevo->select('mapel,nilai')->from('student__jawaban_tes')->where('mapel',$mapel)->where('nisn',$this->session->userdata('username'))->get()->row_array();
	    return $query;
	}
	
	
	
	
	
	
	//===================DATABASE SISWA=======================
	
    public function simpanfull($data)
	{
	    if($this->dbrevo->select('nisn')->from('student__biodata')->where('nisn',$data['nisn'])->get()->row_array()==null) {
	        $this->dbrevo->insert('student__biodata',$data);
	    }
	    else {
	        $this->dbrevo->where('nisn',$data['nisn'])->update('student__biodata',$data);
	    }
	    echo 'sukses';
	}
    public function detail_ppdb($data)
	{
	    return $this->db->select('*')->from('student__ppdb')->where('nisn',$data)->get()->row_array();
	}
    public function detail_student($data)
	{
	    return $this->dbrevo->select('*')->from('student__biodata')->where('nisn',$data)->get()->row_array();
	}
	public function listprov($parent){
	    return $this->db->select('code,name')->from('wilayah')->where('parent',$parent)->get()->result_array();
	}
	public function listpondok($id){
	    if($id==null) return $this->dbrevo->select('*')->from('pondok__biodata')->order_by('id ASC')->get()->result_array();
	    else return $this->dbrevo->select('*')->from('pondok__biodata')->where('id',$id)->get()->row_array();
	}
	public function ceklengkap($data)
	{
	    $query=$this->dbrevo->select('nama_lengkap, nisn, nik, tempat_lahir, tanggal_lahir, m_hobi_id, m_citacita_id, jml_saudara, m_asal_sekolah_id, tahun_ajaran, nama_sekolah_asal, alamat_sekolah_asal, m_jenis_rumah_id, alamat_siswa, propinsi_siswa, kabupaten_siswa, kecamatan_siswa, kelurahan_siswa, kode_pos_siswa, m_jarak_id, m_transport_id, nomor_kk, nama_kepala_keluarga, nama_ayah_kandung, tahun_lahir_ayah_kandung, m_kondisi_ayah_kandung_id, nik_ayah_kandung, m_pendidikan_ayah_kandung_id, m_pekerjaan_ayah_kandung_id, nama_ibu_kandung, tahun_lahir_ibu_kandung, m_kondisi_ibu_kandung_id, nik_ibu_kandung, m_pendidikan_ibu_kandung_id, m_pekerjaan_ibu_kandung_id, nama_wali, tahun_lahir_wali, nik_wali, m_pendidikan_wali_id, m_pekerjaan_wali_id, penghasilan_bulan, m_status_rumah_id, alamat_ortu, propinsi_ortu, kabupaten_ortu, kecamatan_ortu, kelurahan_ortu, kode_pos_ortu, rt, rw, hp_siswa, hp_ayah, hp_ibu, email')->from('student__biodata')->where('nisn',$data['nisn'])->get()->row_array();
	    return $query;
	}
	public function presensi($data)
	{
	    $this->dbrevo->select('user__notification.*,nama_lengkap,student__biodata.kelas,absen,pelajaran,guru,nama,tema')->from('user__notification')->where('notif_for',$data['nisn']);
	    $this->dbrevo->join('student__biodata','student__biodata.nisn=user__notification.notif_for');
	    $this->dbrevo->join('student__mapel','student__mapel.id=user__notification.notif_title');
	    $this->dbrevo->join('pondok__biodata','pondok__biodata.id=nama_pondok');
	    $query=$this->dbrevo->get()->result_array();
	    return $query;
	}

}
?>