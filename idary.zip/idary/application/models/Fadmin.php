<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//     ###    ###     ### ###    ###    ###   #
//    #  #    #  #    #  #  #     #     # #   #
//   #####    #  #    #  #  #     #     #  #  #
//   #   #    #  #    #  #  #     #     #   # #
//   #   #    ###     #  #  #    ###    #   ###

class Fadmin extends CI_Model{
    function __construct(){
        parent::__construct();
        $this->dbrevo = $this->load->database('revo', TRUE);
        $this->table1='student__ppdb';
        $this->table2='user__setting';
        $this->table3='student__mapel_tes';
        $this->table4='student__soal_tes';
        $this->table5='student__jawaban_tes';
    }
    
    
    //################ FUNGSI DASAR #####################
    public function cek_data($table,$col,$val)
	{
	    return $this->dbrevo->select($col)->from($table)->where($col,$val)->get()->row_array();
	}
    public function get_detail($table,$cond)
	{
	    return $this->dbrevo->select('*')->from($table)->where($cond)->get()->row_array();
	}
    public function get_data($table,$cond)
	{
	    return $this->dbrevo->select('*')->from($table)->where($cond)->get()->result_array();
	}
	
	
    //################ FUNGSI PPDB #####################
    // 1
    public function ppdb_bayar_reg($data)
    {
        $this->dbrevo->where('nisn',$data['nisn'])->update($this->table1,$data);
        //==============pantau siapa yang mengedit ==================
        $dataaksi['notif_for']=$this->session->userdata('username');
        $dataaksi['notif_title']='Bayar PPDB';
        $dataaksi['notif_status']=$data['bayar'];
        $this->dbrevo->insert('admin__notification',$dataaksi);
    }
	// 2
    function detailpendaftar($nisn){
        $query = $this->dbrevo->where('id',$nisn)->select('*')->from('student__ppdb')->get()->row_array();
        return $query;
    }
    // 3
    public function simpanppdb($data)
    {
        $cek=$this->cek_data($this->table1,'nisn',$data['nisn']);
        if($cek!=null) {
            $this->dbrevo->update('student__ppdb',$data);
            echo 'sukses';
        }
        else echo 'gagal';
    }
	
	
	
//===============================================================
//                  FUNGSI SELECT
//===============================================================
    function getfield($f){
        $query = $this->dbrevo->field_data($f);
        $q2 = $this->dbrevo->select('*')->from('template__var')->get()->result_array();
        $data=null;
        foreach ($q2 as $q3){
            $data[$q3['kode']]=$q3['nama'];
        }
        foreach($query as $q){
            $q->type=$data[$q->name];
        }
	    return $query;
    }
    function fulldata($f,$o=null){
        $query = $this->dbrevo->select('*')->from($f)->order_by($o)->get()->result_array();
	    return $query;
    }
    function fulldata2($f,$o=null){
        $sel=$f.'.'.'*,';
        // $sel.='nama_agama AS m_agama_id, nama_cita AS m_citacita_id, nama_hobi AS m_hobi_id, nama_jarak AS m_jarak_id, nama_jenis_rumah AS m_jenis_rumah_id,';
        // $sel.='prov.name AS propinsi_siswa, kab.name AS kabupaten_siswa, kec.name AS kecamatan_siswa, desa.name AS kelurahan_siswa, ';
        // $sel.='ka.nama_pekerjaan AS m_pekerjaan_ayah_kandung_id';
        // $sel.='ka.nama_pekerjaan AS m_pekerjaan_ayah_kandung_id, ki.nama_pekerjaan AS m_pekerjaan_ibu_kandung_id, kw.nama_pekerjaan AS m_pekerjaan_wali_id,';
        $this->dbrevo->select($sel)->from($f);
        // $this->dbrevo->join('m__agama','id_agama=m_agama_id');
        // $this->dbrevo->join('m__cita','id_cita=m_citacita_id');
        // $this->dbrevo->join('m__hobi','id_hobi=m_hobi_id');
        // $this->dbrevo->join('m__jarak_rumah','id_jarak=m_jarak_id');
        // $this->dbrevo->join('m__jenis_rumah','id_jenis_rumah=m_jenis_rumah_id');
        // $this->dbrevo->join('m__wilayah prov','prov.code=propinsi_siswa','left');
        // $this->dbrevo->join('m__wilayah kab','kab.code=kabupaten_siswa','left');
        // $this->dbrevo->join('m__wilayah kec','kec.code=kecamatan_siswa','left');
        // $this->dbrevo->join('m__wilayah desa','desa.code=kelurahan_siswa');
        // $this->dbrevo->join('m__pekerjaan ka','ka.id_pekerjaan=m_pekerjaan_ayah_kandung_id');
        // $this->dbrevo->join('m__pekerjaan ki','ki.id_pekerjaan=m_pekerjaan_ibu_kandung_id');
        // $this->dbrevo->join('m__pekerjaan kw','kw.id_pekerjaan=m_pekerjaan_wali_id');
        $query=$this->dbrevo->get()->result_array();
	    return $query;
    }
    function listmenu(){
        $query=$this->dbrevo->select('*')->from('template__menu')->order_by('user_level asc, menu_order asc')->get();
	    return $query->result_array();
    }
    function listpendaftar(){
        $query = $this->db->select('student__ppdb.id,student__ppdb.nisn,namasiswa,aslsb,almlengkap,hpsiswa,hp_ayah,bayar,kelasmts,mpa')->from('student__ppdb')->where('bayar',1)->where('mpa',null)->join('biodata__student','student__ppdb.nisn=biodata__student.nisn','left')->get()->result_array();
	    return $query;
    }
    function listsiswa(){
        $query = $this->dbrevo->select('nisn,nama_lengkap,kelas,absen,jurusan')->from('student__biodata')->get()->result_array();
	    return $query;
    }
    function edit_kelas($data){
        if(!isset($data['kelas'])){
            $query = $this->dbrevo->select('nisn,nama_lengkap,kelas,jurusan,absen')->from('student__biodata')->where('nisn',$data['nisn'])->get()->row_array();
    	    return $query;
        }
        else {
            $this->dbrevo->where('nisn',$data['nisn'])->update('student__biodata',$data);
            return 'sukses';
        }
    }
    function presensi_daring($data){
        $query=$this->dbrevo->select('nisn,nama_lengkap,absen,DAY(notif_date) as notif_date')->from('student__biodata')->join('user__notification','nisn=notif_for','both')->where('kelas',$data['kelas'])->like('notif_date','-'.$data['bulan'].'-')->get()->result_array();
        return $query;
    }
    function ver_susulan($data=null,$approve=null){
        if($data==null){
            $query=$this->dbrevo->select('student__susulan.*,nama_lengkap,student__biodata.kelas,pelajaran')->from('student__susulan')->join('student__biodata','student__susulan.nisn=student__biodata.nisn','left')->join('student__mapel_tes','mapel=kode')->get()->result_array();
            return $query;
        }
        else {
            $this->dbrevo->where($data)->update('student__susulan',$approve);
        }
        
    }
    function hasilppdb($data=null,$approve=null){
        if($data==null){
            $query=$this->dbrevo->select('nisn,nama_lengkap,nama_sekolah_asal,alamat_siswa,nama_ayah_kandung,level')->from('student__biodata')->join('user','username=nisn')->get()->result_array();
            return $query;
        }
        else {
            $this->dbrevo->where($data)->update('user',$approve);
        }
        
    }
    
//===============================================================
//                  FUNGSI INSERT/UPDATE
//===============================================================
    function reset_pass($data){
        $q=$this->dbrevo->select('username')->from('user')->where($data)->get()->result_array();
        if($q==null) return 'gagal';
        else {
            $this->dbrevo->where($data)->update('user',array('password'=>md5('ungguliptek')));
            return 'sukses';
        }
    }
    function simpan_sidemenu($data,$action){
        if($action=='update'){
			$this->dbrevo->where('menu_id',$data['menu_id']);
			$this->dbrevo->update('template__menu',$data);
		    echo "update";
        } else if($action=='insert'){
			$this->dbrevo->insert('template__menu',$data);
			echo "insert";
        }
    }
    function aksipendaftar($id,$aksi,$nilai){
        if($aksi=='hapus') {
            //==============backup data ppdb lalu hapus===================
            $backup=$this->db->select('*')->from('student__ppdb')->where('id',$id)->get()->row_array();
            unset($backup['id']);
            $this->db->where('id',$id)->insert('student__ppdb_backup',$backup);
            $this->db->where('id',$id)->delete('student__ppdb');
            //==============backup data user lalu hapus===================
            $nisn=$backup['nisn'];
            $backup2=$this->db->select('*')->from('user')->where('username',$nisn)->get()->row_array();
            unset($backup2['id']);
            $this->db->where('username',$nisn)->insert('user__backup',$backup2);
            $this->db->where('username',$nisn)->delete('user');
            //==============pantau siapa yang menghapus ==================
            $dataaksi['admin_name']=$this->session->userdata['username'];
            $dataaksi['target_nisn']=$backup['nisn'];
            $dataaksi['aksi']=$aksi;
            $this->db->insert('user__aksiadmin',$dataaksi);
        }
        if($aksi=='bayar') {
            $data['bayar']=$nilai;
            $this->db->where('id',$id)->update('student__ppdb',$data);
            //==============pantau siapa yang mengedit ==================
            $dataaksi['admin_name']=$this->session->userdata['username'];
            $dataaksi['target_nisn']='id ppdb: '.$id;
            $dataaksi['aksi']=$aksi;
            $this->db->insert('user__aksiadmin',$dataaksi);
        }
        if($aksi=='mpa') {
            $data['mpa']=$nilai;
            $this->db->where('id',$id)->update('student__ppdb',$data);
            //==============pantau siapa yang mengedit ==================
            $dataaksi['admin_name']=$this->session->userdata['username'];
            $dataaksi['target_nisn']='id ppdb: '.$id;
            $dataaksi['aksi']=$aksi;
            $this->db->insert('user__aksiadmin',$dataaksi);
        }
    }

//===============================================================
//                  FUNGSI UPDATE
//===============================================================



//===============================================================
//                  FUNGSI DELETE
//===============================================================
    function del_sidemenu($menu_id){
        $query = $this->dbrevo->delete('template__menu', array('menu_id' => $menu_id));
        echo "delete";
    }

//===============================================================
//                  FUNGSI UMPTS
//===============================================================

    function lihat($data){
        $query=$this->db->select('nama,absen,kelas,mapel')->from('umpts')->where($data)->get();
        return $query->result();
    }
    function kirim($data){
        $this->db->insert('umpts',$data);
        echo 'ok';
    }
    // function gantijawaban($nilai=null){
    //     if($nilai==null) return $this->dbrevo->select('nisn,jawaban')->from('student__jawaban_tes')->where('mapel','BArab_XI_U')->get()->result_array();
    //     else {
    //         foreach ($nilai as $key => $value) {
    //             $n=array('nilai'=>$value);
    //             $this->dbrevo->where('mapel','BArab_XI_U')->where('nisn',$key)->update('student__jawaban_tes',$n);
    //         }
    //     }
    // }
    
    
    //===========================================================

    
    
    //===========================================================
}