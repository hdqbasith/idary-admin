<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Fapplicant extends CI_Model{
        //    FF     F  F     FF   F  F
        //   F     F F  F    F  F  FF F
        //   F    FFFF  F    F  F  F FF
        //    FF  F  F  FFF   FF   F  F
    function __construct(){
        parent::__construct();
        $this->dbrevo = $this->load->database('revo', TRUE);
        $this->nisn=$this->session->userdata('username');
        $this->table1='student__ppdb';
        $this->table2='user__setting';
        $this->table3='student__mapel_tes';
        $this->table4='student__soal_tes';
        $this->table5='student__jawaban_tes';
    }
    //################ FUNGSI DASAR #####################
    public function cek_data($table,$col,$val)
	{
	    return $this->dbrevo->select($col)->from($table)->where($col,$val)->get()->row_array();
	}
    public function get_detail($table,$cond)
	{
	    return $this->dbrevo->select('*')->from($table)->where($cond)->get()->row_array();
	}
    public function get_data($table,$cond)
	{
	    return $this->dbrevo->select('*')->from($table)->where($cond)->get()->result_array();
	}
    
    //################ FUNGSI UTAMA #####################
    // 1
    public function simpanppdb($data)
	{
	    $cek=$this->cek_data($this->table1,'nisn',$data['nisn']);
	    if($cek==null) {
	        $this->dbrevo->insert('student__ppdb',$data);
	        $u['username']=$data['nisn'];
	        $u['password']=$data['password'];
	        $u['nama']=$data['namasiswa'];
	        $u['level']=9;
	        $this->dbrevo->insert('user',$u);
	        echo 'sukses';
	    }
	    else echo 'gagal';
	}
	// 2
    public function kartu_tes_ppdb()
	{
	    $data['tes_lisan']=$this->get_detail($this->table2,array('setting_key'=>'tes_lisan'));
	    $data['tes_tulis']=$this->get_detail($this->table2,array('setting_key'=>'tes_tulis'));
	    $data['wa_admin']=$this->get_detail($this->table2,array('setting_key'=>'wa_admin'));
	    $data['nama_madrasah']=$this->get_detail($this->table2,array('setting_key'=>'nama_madrasah'));
	    $data['ta']=$this->get_detail($this->table2,array('setting_key'=>'tahun_ajaran'));
	    $data['reg_code']=$this->get_detail($this->table2,array('setting_key'=>'reg_code'));
	    $data['petunjuk']=$this->get_detail($this->table2,array('setting_key'=>'testcard_info'));
	    return $data;
	}
	// 3
    public function detail_ppdb($data)
	{
	    return $this->dbrevo->select('*')->from('student__ppdb')->where('nisn',$data)->get()->row_array();
	}
	// 4
    public function detail_student($data)
	{
	    return $this->dbrevo->select('*')->from('student__biodata')->where('nisn',$data)->get()->row_array();
	}
	// 5
    public function banned($data)
	{
	    $banned['ket']=$data['banned'];
	    $this->dbrevo->where('nisn',$data['nisn'])->update('student__ppdb',$banned);
	}
	// 6
    public function gantinisn($data)
	{
	    $db='user__notification';
	    $w=array('notif_title'=>'gantinisn','notif_for'=>$data['nisn_lama']);
	    $q=$this->dbrevo->select('*')->from($db)->where($w)->get()->row_array();
        $w['notif_content']=$data['nisn_baru'];
        $w['notif_status']='pending';
        $w['notif_date']=date('now');
	    if($q==null){
	        $this->dbrevo->insert($db,$w);
	    }else{
	        $this->dbrevo->update($db,$w);
	    }
	    echo 'sukses';
	}
	// 7
    public function sim_cbtppdb()
	{
	    $data['mapel']=$this->get_detail($this->table2,array('setting_key'=>'ppdb_cbtsim_mapel'))['setting_value'];
	    $data['header']=$this->get_detail($this->table2,array('setting_key'=>'ppdb_cbtsim_header'));
	    $data['ikut_tes']=$this->get_detail($this->table5,array('nisn'=>$this->nisn,'mapel'=>$data['mapel']));
	    $data['token']=$this->get_detail($this->table3,array('kode'=>$data['mapel']));
	    $data['show_result']=$this->get_detail($this->table2,array('setting_key'=>'ppdb_cbtsim_show_result'));
	    $data['dummy_video']=$this->get_detail($this->table2,array('setting_key'=>'ppdb_cbtsim_dummyVideo'));
	    return $data;
	}
	// 8
    public function seleksippdb()
	{
	    $data['mapel']=$this->get_detail($this->table2,array('setting_key'=>'ppdb_test_mapel'))['setting_value'];
	    $data['header']=$this->get_detail($this->table2,array('setting_key'=>'ppdb_test_header'));
	    $data['ikut_tes']=$this->get_detail($this->table5,array('nisn'=>$this->nisn,'mapel'=>$data['mapel']));
	    $data['token']=$this->get_detail($this->table3,array('kode'=>$data['mapel']));
	    $data['show_result']=$this->get_detail($this->table2,array('setting_key'=>'ppdb_test_show_result'));
	    $data['dummy_video']=$this->get_detail($this->table2,array('setting_key'=>'ppdb_test_dummyVideo'));
	    return $data;
	}
	
	
	//============================SOAL SELEKSI PPDB======================================
    public function get_soal()
	{
	    $result= $this->dbrevo->select('*')->from('student__soal_ppdb')->where('mapel','TPA1')->get()->result_array();
	    shuffle($result);
	    $data=null;
	    $i=1;
	    foreach ($result as $r){
	        $data[$i]=$r;
	        $i++;
	    };
	    $result= $this->dbrevo->select('*')->from('student__soal_ppdb')->where('mapel','MIA1')->get()->result_array();
	    shuffle($result);
	    foreach ($result as $r){
	        $data[$i]=$r;
	        $i++;
	    };
	    $result= $this->dbrevo->select('*')->from('student__soal_ppdb')->where('mapel','IIS1')->get()->result_array();
	    shuffle($result);
	    foreach ($result as $r){
	        $data[$i]=$r;
	        $i++;
	    };
	    $result= $this->dbrevo->select('*')->from('student__soal_ppdb')->where('mapel','IBB1')->get()->result_array();
	    shuffle($result);
	    foreach ($result as $r){
	        $data[$i]=$r;
	        $i++;
	    };
	    $result= $this->dbrevo->select('*')->from('student__soal_ppdb')->where('mapel','IIK1')->get()->result_array();
	    shuffle($result);
	    foreach ($result as $r){
	        $data[$i]=$r;
	        $i++;
	    };
	    return $data;
	}
	public function jawaban_ppdb($data,$aksi)
	{
	    if($aksi=='mulai'){
	        $mulai=$this->dbrevo->select('waktu_mulai,jawaban')->from('student__jawaban_ppdb')->where('nisn',$data['nisn'])->get()->row_array();
    	    if($mulai==null){
    	        $this->dbrevo->insert('student__jawaban_ppdb',$data);
    	        return $data['waktu_mulai'];
    	    } elseif($mulai['jawaban']==null){
    	        return $mulai['waktu_mulai'];
    	    } else return 'gagal';
	    } else if($aksi=='selesai'){
	        $this->dbrevo->where('nisn',$data['nisn'])->update('student__jawaban_ppdb',$data);
	        return 'selesai';
	    }
	}
	public function cekdatalengkap($data)
	{
	    $query=$this->dbrevo->select('nama_lengkap, nisn, nik, tempat_lahir, tanggal_lahir, m_hobi_id, m_citacita_id, jml_saudara, m_asal_sekolah_id, tahun_ajaran, npsn_sekolah_asal, nama_sekolah_asal, alamat_sekolah_asal, m_jenis_rumah_id, alamat_siswa, propinsi_siswa, kabupaten_siswa, kecamatan_siswa, kelurahan_siswa, kode_pos_siswa, m_jarak_id, m_transport_id, nomor_kk, nama_kepala_keluarga, nama_ayah_kandung, tahun_lahir_ayah_kandung, m_kondisi_ayah_kandung_id, nik_ayah_kandung, m_pendidikan_ayah_kandung_id, m_pekerjaan_ayah_kandung_id, nama_ibu_kandung, tahun_lahir_ibu_kandung, m_kondisi_ibu_kandung_id, nik_ibu_kandung, m_pendidikan_ibu_kandung_id, m_pekerjaan_ibu_kandung_id, nama_wali, tahun_lahir_wali, nik_wali, m_pendidikan_wali_id, m_pekerjaan_wali_id, penghasilan_bulan, m_status_rumah_id, alamat_ortu, propinsi_ortu, kabupaten_ortu, kecamatan_ortu, kelurahan_ortu, kode_pos_ortu, rt, rw, hp_siswa, hp_ayah, hp_ibu, email')->from('student__biodata')->where('nisn',$data['nisn'])->get()->row_array();
	    return $query;
	}
	
	//============================PAT 2020======================================
	public function cekpass()
	{
	    return $this->dbrevo->select('password')->from('user')->where('username',$this->session->userdata('username'))->get()->row_array();
	}
	public function simpan_profilpat($data)
	{
	    $nisn=$this->session->userdata('username');
	    $data2['password']=$data['password'];
	    $data2['username']=$data['nisn'];
	    $data2['nama']=$data['nama'];
	    $this->dbrevo->where('username',$nisn)->update('user',$data2);
	    unset($data['password']);
	    if($this->dbrevo->select('nisn')->from('student__profilpat2020')->where('nisn',$nisn)->get()->result_array()==null){
    	    $this->dbrevo->insert('student__profilpat2020',$data);
	    } else $this->dbrevo->where('nisn',$nisn)->update('student__profilpat2020',$data);
	}
	public function pat2020($mapel)
	{
	    $result= $this->dbrevo->select('*')->from('student__soal_ppdb')->where('mapel',$mapel)->get()->result_array();
	    $s=1;
	    if($result[0]['mapel']!='Hds_XIAE') $s=0;
	    else if($result[0]['mapel']!='Hds_X') $s=0;
	    if($s==1){
	        shuffle($result);
	    }
	    $data=null;
	    $i=1;
	    foreach ($result as $r){
	        $data[$i]=$r;
	        $i++;
	    };
	    return $data;
	}
	public function jawaban_pat2020($data,$aksi)
	{
	    if($aksi=='mulai'){
	        $mulai=$this->dbrevo->select('mulai,jawaban')->from('student__jawabanpat2020')->where('mapel',$data['mapel'])->where('nisn',$data['nisn'])->get()->row_array();
    	    if($mulai==null){
    	        $this->dbrevo->insert('student__jawabanpat2020',$data);
    	        return $data['mulai'];
    	    } elseif($mulai['jawaban']==null){
    	        return $mulai['mulai'];
    	    } else return 'gagal';
	    } else if($aksi=='selesai'){
	        $this->dbrevo->where('nisn',$data['nisn'])->where('mapel',$data['mapel'])->update('student__jawabanpat2020',$data);
	        return 'selesai';
	    }
	}
	
	
	
	
	
	//========================KHATAMAN=========================
	
	public function listsiswa()
	{
	    return $this->dbrevo->select('*')->from('student__khataman')->get()->result();
	}
	public function tambahsiswa($data)
	{
	    $this->dbrevo->insert('student__khataman',$data);
	}
	public function aksikhataman($aksi,$id)
	{
	    if($aksi=='tambahjuz') $this->dbrevo->where('id',$id)->set('juz', 'juz+1', FALSE)->update('student__khataman');
	    elseif($aksi=='kurangjuz') $this->dbrevo->where('id',$id)->set('juz', 'juz-1', FALSE)->update('student__khataman');
	    elseif($aksi=='tambahkhatam') $this->dbrevo->where('id',$id)->set('khatam', 'khatam+1', FALSE)->update('student__khataman');
	    elseif($aksi=='kurangkhatam') $this->dbrevo->where('id',$id)->set('khatam', 'khatam-1', FALSE)->update('student__khataman');
	    return 'ok';
	}
	
	
	//======================MATSAMA============================

	public function matsama_login($data)
	{
	    $cek=$this->dbrevo->select('*')->from('student__matsama')->where('nisn',$data['nisn'])->where('var',$data['var'])->get()->row();
	    if($cek==null) $this->dbrevo->insert('student__matsama',$data);
	}
	public function matsama_jawab($data)
	{
	    $cek=$this->dbrevo->select('*')->from('student__matsama')->where('nisn',$data['nisn'])->where('var',$data['var'])->get()->row();
	    if($cek==null) $this->dbrevo->insert('student__matsama',$data);
	    else $this->dbrevo->where('nisn',$data['nisn'])->where('var',$data['var'])->update('student__matsama',$data);
	}
	
	public function jawabjur($data,$aksi)
	{
	    if($aksi=='mulai'){
	        $mulai=$this->dbrevo->select('waktu_mulai,jawaban')->from('student__jawaban_ppdb')->where('mapel',$data['mapel'])->where('nisn',$data['nisn'])->get()->row_array();
    	    if($mulai==null){
    	        $this->dbrevo->insert('student__jawaban_ppdb',$data);
    	        return $data['waktu_mulai'];
    	    } elseif($mulai['jawaban']==null){
    	        return $mulai['waktu_mulai'];
    	    } else return 'gagal';
	    } else if($aksi=='selesai'){
	        $this->dbrevo->where('nisn',$data['nisn'])->where('mapel',$data['mapel'])->update('student__jawaban_ppdb',$data);
	        return 'selesai';
	    }
	}
}
?>