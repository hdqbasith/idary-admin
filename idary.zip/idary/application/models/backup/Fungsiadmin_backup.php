<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Fungsiadmin extends CI_Model{
    function __construct(){
        parent::__construct();
    }
    function listmenu(){
        $query=$this->db->select('*')->from('template__menu')->order_by('user_level asc, menu_order asc')->get();
	    return $query->result_array();
    }
    function fieldmenu(){
        $query = $this->db->field_data('template__menu');
	    return $query;
    }
    function simpan_sidemenu($data,$action){
        if($action=='update'){
			$this->db->where('menu_id',$data['menu_id']);
			$this->db->update('template__menu',$data);
		    echo "update";
        } else if($action=='insert'){
			$this->db->insert('template__menu',$data);
			echo "insert";
        }
    }
    function del_sidemenu($menu_id){
        $query = $this->db->delete('template__menu', array('menu_id' => $menu_id));
        echo "delete";
    }
    
}