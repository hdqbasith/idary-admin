<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Fstudent extends CI_Model{
    function __construct(){
        parent::__construct();
        $this->dbrevo = $this->load->database('revo', TRUE);
    }
    
    public function simpanppdb($data)
	{
	    if($this->db->select('nisn')->from('student__ppdb')->where('nisn',$data['nisn'])->get()->row_array()==null) {
	        $this->db->insert('student__ppdb',$data);
	        $u['username']=$data['nisn'];
	        $u['password']=$data['password'];
	        $u['nama']=$data['namasiswa'];
	        $u['level']=9;
	        $this->db->insert('user',$u);
	        echo 'sukses';
	    }
	    else echo 'gagal';
	}
    public function simpanfull($data)
	{
	    if($this->db->select('nisn')->from('biodata__student')->where('nisn',$data['nisn'])->get()->row_array()==null) {
	        $this->db->insert('biodata__student',$data);
	    }
	    else {
	        $this->db->where('nisn',$data['nisn'])->update('biodata__student',$data);
	    }
	    echo 'sukses';
	}
    public function detail_ppdb($data)
	{
	    return $this->db->select('*')->from('student__ppdb')->where('nisn',$data)->get()->row_array();
	}
    public function detail_student($data)
	{
	    return $this->db->select('*')->from('biodata__student')->where('nisn',$data)->get()->row_array();
	}
    public function banned($data)
	{
	    $banned['ket']=$data['banned'];
	    $this->db->where('nisn',$data['nisn'])->update('student__ppdb',$banned);
	}
    public function gantinisn($data)
	{
	    $db='user__notification';
	    $w=array('notif_title'=>'gantinisn','notif_for'=>$data['nisn_lama']);
	    $q=$this->db->select('*')->from($db)->where($w)->get()->row_array();
        $w['notif_content']=$data['nisn_baru'];
        $w['notif_status']='pending';
        $w['notif_date']=date('now');
	    if($q==null){
	        $this->db->insert($db,$w);
	    }else{
	        $this->db->update($db,$w);
	    }
	    echo 'sukses';
	}
	
	
	//============================SOAL SELEKSI PPDB======================================
    public function get_soal()
	{
	    $result= $this->db->select('*')->from('student__soal_ppdb')->where('mapel','TPA1')->get()->result_array();
	    shuffle($result);
	    $data=null;
	    $i=1;
	    foreach ($result as $r){
	        $data[$i]=$r;
	        $i++;
	    };
	    $result= $this->db->select('*')->from('student__soal_ppdb')->where('mapel','MIA1')->get()->result_array();
	    shuffle($result);
	    foreach ($result as $r){
	        $data[$i]=$r;
	        $i++;
	    };
	    $result= $this->db->select('*')->from('student__soal_ppdb')->where('mapel','IIS1')->get()->result_array();
	    shuffle($result);
	    foreach ($result as $r){
	        $data[$i]=$r;
	        $i++;
	    };
	    $result= $this->db->select('*')->from('student__soal_ppdb')->where('mapel','IBB1')->get()->result_array();
	    shuffle($result);
	    foreach ($result as $r){
	        $data[$i]=$r;
	        $i++;
	    };
	    $result= $this->db->select('*')->from('student__soal_ppdb')->where('mapel','IIK1')->get()->result_array();
	    shuffle($result);
	    foreach ($result as $r){
	        $data[$i]=$r;
	        $i++;
	    };
	    return $data;
	}
	public function jawaban_ppdb($data,$aksi)
	{
	    if($aksi=='mulai'){
	        $mulai=$this->db->select('waktu_mulai,jawaban')->from('student__jawaban_ppdb')->where('nisn',$data['nisn'])->get()->row_array();
    	    if($mulai==null){
    	        $this->db->insert('student__jawaban_ppdb',$data);
    	        return $data['waktu_mulai'];
    	    } elseif($mulai['jawaban']==null){
    	        return $mulai['waktu_mulai'];
    	    } else return 'gagal';
	    } else if($aksi=='selesai'){
	        $this->db->where('nisn',$data['nisn'])->update('student__jawaban_ppdb',$data);
	        return 'selesai';
	    }
	}
	public function cekdatalengkap($data)
	{
	    $query=$this->db->select('nama_lengkap, nisn, nik, tempat_lahir, tanggal_lahir, m_hobi_id, m_citacita_id, jml_saudara, m_asal_sekolah_id, tahun_ajaran, npsn_sekolah_asal, nama_sekolah_asal, alamat_sekolah_asal, m_jenis_rumah_id, alamat_siswa, propinsi_siswa, kabupaten_siswa, kecamatan_siswa, kelurahan_siswa, kode_pos_siswa, m_jarak_id, m_transport_id, nomor_kk, nama_kepala_keluarga, nama_ayah_kandung, tahun_lahir_ayah_kandung, m_kondisi_ayah_kandung_id, nik_ayah_kandung, m_pendidikan_ayah_kandung_id, m_pekerjaan_ayah_kandung_id, nama_ibu_kandung, tahun_lahir_ibu_kandung, m_kondisi_ibu_kandung_id, nik_ibu_kandung, m_pendidikan_ibu_kandung_id, m_pekerjaan_ibu_kandung_id, nama_wali, tahun_lahir_wali, nik_wali, m_pendidikan_wali_id, m_pekerjaan_wali_id, penghasilan_bulan, m_status_rumah_id, alamat_ortu, propinsi_ortu, kabupaten_ortu, kecamatan_ortu, kelurahan_ortu, kode_pos_ortu, rt, rw, hp_siswa, hp_ayah, hp_ibu, email')->from('biodata__student')->where('nisn',$data['nisn'])->get()->row_array();
	    return $query;
	}
	
	//============================PAT 2020======================================
	public function cekpass()
	{
	    return $this->db->select('password')->from('user')->where('username',$this->session->userdata('username'))->get()->row_array();
	}
	public function simpan_profilpat($data)
	{
	    $nisn=$this->session->userdata('username');
	    $data2['password']=$data['password'];
	    $data2['username']=$data['nisn'];
	    $data2['nama']=$data['nama'];
	    $this->db->where('username',$nisn)->update('user',$data2);
	    unset($data['password']);
	    if($this->db->select('nisn')->from('student__profilpat2020')->where('nisn',$nisn)->get()->result_array()==null){
    	    $this->db->insert('student__profilpat2020',$data);
	    } else $this->db->where('nisn',$nisn)->update('student__profilpat2020',$data);
	}
	public function pat2020($mapel)
	{
	    $result= $this->db->select('*')->from('student__soal_ppdb')->where('mapel',$mapel)->get()->result_array();
	    $s=1;
	    if($result[0]['mapel']!='Hds_XIAE') $s=0;
	    else if($result[0]['mapel']!='Hds_X') $s=0;
	    if($s==1){
	        shuffle($result);
	    }
	    $data=null;
	    $i=1;
	    foreach ($result as $r){
	        $data[$i]=$r;
	        $i++;
	    };
	    return $data;
	}
	public function jawaban_pat2020($data,$aksi)
	{
	    if($aksi=='mulai'){
	        $mulai=$this->db->select('mulai,jawaban')->from('student__jawabanpat2020')->where('mapel',$data['mapel'])->where('nisn',$data['nisn'])->get()->row_array();
    	    if($mulai==null){
    	        $this->db->insert('student__jawabanpat2020',$data);
    	        return $data['mulai'];
    	    } elseif($mulai['jawaban']==null){
    	        return $mulai['mulai'];
    	    } else return 'gagal';
	    } else if($aksi=='selesai'){
	        $this->db->where('nisn',$data['nisn'])->where('mapel',$data['mapel'])->update('student__jawabanpat2020',$data);
	        return 'selesai';
	    }
	}
	
	
	
	
	
	//========================KHATAMAN=========================
	
	public function listsiswa()
	{
	    return $this->db->select('*')->from('student__khataman')->get()->result();
	}
	public function tambahsiswa($data)
	{
	    $this->db->insert('student__khataman',$data);
	}
	public function aksikhataman($aksi,$id)
	{
	    if($aksi=='tambahjuz') $this->db->where('id',$id)->set('juz', 'juz+1', FALSE)->update('student__khataman');
	    elseif($aksi=='kurangjuz') $this->db->where('id',$id)->set('juz', 'juz-1', FALSE)->update('student__khataman');
	    elseif($aksi=='tambahkhatam') $this->db->where('id',$id)->set('khatam', 'khatam+1', FALSE)->update('student__khataman');
	    elseif($aksi=='kurangkhatam') $this->db->where('id',$id)->set('khatam', 'khatam-1', FALSE)->update('student__khataman');
	    return 'ok';
	}
	
	
	//======================MATSAMA============================

	public function matsama_login($data)
	{
	    $cek=$this->db->select('*')->from('student__matsama')->where('nisn',$data['nisn'])->where('var',$data['var'])->get()->row();
	    if($cek==null) $this->db->insert('student__matsama',$data);
	}
	public function matsama_jawab($data)
	{
	    $cek=$this->db->select('*')->from('student__matsama')->where('nisn',$data['nisn'])->where('var',$data['var'])->get()->row();
	    if($cek==null) $this->db->insert('student__matsama',$data);
	    else $this->db->where('nisn',$data['nisn'])->where('var',$data['var'])->update('student__matsama',$data);
	}
	
	public function jawabjur($data,$aksi)
	{
	    if($aksi=='mulai'){
	        $mulai=$this->db->select('waktu_mulai,jawaban')->from('student__jawaban_ppdb')->where('mapel',$data['mapel'])->where('nisn',$data['nisn'])->get()->row_array();
    	    if($mulai==null){
    	        $this->db->insert('student__jawaban_ppdb',$data);
    	        return $data['waktu_mulai'];
    	    } elseif($mulai['jawaban']==null){
    	        return $mulai['waktu_mulai'];
    	    } else return 'gagal';
	    } else if($aksi=='selesai'){
	        $this->db->where('nisn',$data['nisn'])->where('mapel',$data['mapel'])->update('student__jawaban_ppdb',$data);
	        return 'selesai';
	    }
	}
}
?>